-- phpMyAdmin SQL Dump
-- version 4.5.4.1deb2ubuntu2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jan 17, 2018 at 08:22 AM
-- Server version: 5.7.20-0ubuntu0.16.04.1
-- PHP Version: 7.1.12-1+ubuntu16.04.1+deb.sury.org+1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `paduafinancialgroup_com_au`
--

-- --------------------------------------------------------

--
-- Table structure for table `banners`
--

CREATE TABLE `banners` (
  `ID` int(11) NOT NULL,
  `PhotoID` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `banners`
--

INSERT INTO `banners` (`ID`, `PhotoID`) VALUES
(15, 18),
(16, 19);

-- --------------------------------------------------------

--
-- Table structure for table `banners_Live`
--

CREATE TABLE `banners_Live` (
  `ID` int(11) NOT NULL,
  `PhotoID` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `banners_Live`
--

INSERT INTO `banners_Live` (`ID`, `PhotoID`) VALUES
(15, 18),
(16, 19);

-- --------------------------------------------------------

--
-- Table structure for table `banners_Versions`
--

CREATE TABLE `banners_Versions` (
  `ID` int(11) NOT NULL,
  `RecordID` int(11) NOT NULL DEFAULT '0',
  `Version` int(11) NOT NULL DEFAULT '0',
  `PhotoID` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `banners_Versions`
--

INSERT INTO `banners_Versions` (`ID`, `RecordID`, `Version`, `PhotoID`) VALUES
(1, 15, 1, 0),
(2, 15, 2, 18),
(3, 16, 1, 0),
(4, 16, 2, 19);

-- --------------------------------------------------------

--
-- Table structure for table `Blog`
--

CREATE TABLE `Blog` (
  `ID` int(11) NOT NULL,
  `PostsPerPage` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Blog`
--

INSERT INTO `Blog` (`ID`, `PostsPerPage`) VALUES
(19, 10);

-- --------------------------------------------------------

--
-- Table structure for table `BlogCategory`
--

CREATE TABLE `BlogCategory` (
  `ID` int(11) NOT NULL,
  `ClassName` enum('Axllent\\Weblog\\Model\\BlogCategory') CHARACTER SET utf8 DEFAULT 'Axllent\\Weblog\\Model\\BlogCategory',
  `LastEdited` datetime DEFAULT NULL,
  `Created` datetime DEFAULT NULL,
  `Title` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `URLSegment` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `BlogID` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `BlogCategory`
--

INSERT INTO `BlogCategory` (`ID`, `ClassName`, `LastEdited`, `Created`, `Title`, `URLSegment`, `BlogID`) VALUES
(1, 'Axllent\\Weblog\\Model\\BlogCategory', '2018-01-16 09:50:14', '2018-01-16 09:50:14', 'Technology', 'technology', 19),
(2, 'Axllent\\Weblog\\Model\\BlogCategory', '2018-01-16 09:50:26', '2018-01-16 09:50:26', 'Paraplanning', 'paraplanning', 19);

-- --------------------------------------------------------

--
-- Table structure for table `BlogPost`
--

CREATE TABLE `BlogPost` (
  `ID` int(11) NOT NULL,
  `PublishDate` datetime DEFAULT NULL,
  `Summary` mediumtext CHARACTER SET utf8,
  `FeaturedImageID` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `BlogPost`
--

INSERT INTO `BlogPost` (`ID`, `PublishDate`, `Summary`, `FeaturedImageID`) VALUES
(20, '2018-01-16 00:00:00', 'Suspendisse consectetur fringilla luctus', 21),
(21, '2017-11-30 00:00:00', 'Suspendisse consectetur fringilla luctus', 0),
(22, '2018-01-16 10:34:16', NULL, 0);

-- --------------------------------------------------------

--
-- Table structure for table `BlogPost_Categories`
--

CREATE TABLE `BlogPost_Categories` (
  `ID` int(11) NOT NULL,
  `BlogPostID` int(11) NOT NULL DEFAULT '0',
  `BlogCategoryID` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `BlogPost_Categories`
--

INSERT INTO `BlogPost_Categories` (`ID`, `BlogPostID`, `BlogCategoryID`) VALUES
(1, 20, 1),
(2, 21, 2),
(3, 22, 2),
(4, 22, 1);

-- --------------------------------------------------------

--
-- Table structure for table `BlogPost_Live`
--

CREATE TABLE `BlogPost_Live` (
  `ID` int(11) NOT NULL,
  `PublishDate` datetime DEFAULT NULL,
  `Summary` mediumtext CHARACTER SET utf8,
  `FeaturedImageID` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `BlogPost_Live`
--

INSERT INTO `BlogPost_Live` (`ID`, `PublishDate`, `Summary`, `FeaturedImageID`) VALUES
(20, '2018-01-16 00:00:00', 'Suspendisse consectetur fringilla luctus', 21),
(21, '2017-11-30 00:00:00', 'Suspendisse consectetur fringilla luctus', 0),
(22, '2018-01-16 10:34:16', NULL, 0);

-- --------------------------------------------------------

--
-- Table structure for table `BlogPost_Versions`
--

CREATE TABLE `BlogPost_Versions` (
  `ID` int(11) NOT NULL,
  `RecordID` int(11) NOT NULL DEFAULT '0',
  `Version` int(11) NOT NULL DEFAULT '0',
  `PublishDate` datetime DEFAULT NULL,
  `Summary` mediumtext CHARACTER SET utf8,
  `FeaturedImageID` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `BlogPost_Versions`
--

INSERT INTO `BlogPost_Versions` (`ID`, `RecordID`, `Version`, `PublishDate`, `Summary`, `FeaturedImageID`) VALUES
(1, 20, 1, NULL, NULL, 0),
(2, 20, 2, '2018-01-16 00:00:00', 'Suspendisse consectetur fringilla luctus', 21),
(3, 21, 1, NULL, NULL, 0),
(4, 21, 2, '2018-11-30 00:00:00', 'Suspendisse consectetur fringilla luctus\r\n\r\n', 0),
(5, 21, 3, '2018-11-30 00:00:00', 'Suspendisse consectetur fringilla luctus', 0),
(6, 21, 4, '2017-11-30 00:00:00', 'Suspendisse consectetur fringilla luctus', 0),
(7, 22, 1, NULL, NULL, 0),
(8, 21, 5, '2017-11-30 00:00:00', 'Suspendisse consectetur fringilla luctus', 0),
(9, 20, 3, '2018-01-16 00:00:00', 'Suspendisse consectetur fringilla luctus', 21),
(10, 22, 2, NULL, NULL, 0),
(11, 22, 3, '2018-01-16 10:34:16', NULL, 0);

-- --------------------------------------------------------

--
-- Table structure for table `Blog_Live`
--

CREATE TABLE `Blog_Live` (
  `ID` int(11) NOT NULL,
  `PostsPerPage` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Blog_Live`
--

INSERT INTO `Blog_Live` (`ID`, `PostsPerPage`) VALUES
(19, 10);

-- --------------------------------------------------------

--
-- Table structure for table `Blog_Versions`
--

CREATE TABLE `Blog_Versions` (
  `ID` int(11) NOT NULL,
  `RecordID` int(11) NOT NULL DEFAULT '0',
  `Version` int(11) NOT NULL DEFAULT '0',
  `PostsPerPage` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Blog_Versions`
--

INSERT INTO `Blog_Versions` (`ID`, `RecordID`, `Version`, `PostsPerPage`) VALUES
(1, 19, 1, 10),
(2, 19, 2, 10),
(3, 19, 3, 10),
(4, 19, 4, 10);

-- --------------------------------------------------------

--
-- Table structure for table `ChangeSet`
--

CREATE TABLE `ChangeSet` (
  `ID` int(11) NOT NULL,
  `ClassName` enum('SilverStripe\\Versioned\\ChangeSet') CHARACTER SET utf8 DEFAULT 'SilverStripe\\Versioned\\ChangeSet',
  `LastEdited` datetime DEFAULT NULL,
  `Created` datetime DEFAULT NULL,
  `Name` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `State` enum('open','published','reverted') CHARACTER SET utf8 DEFAULT 'open',
  `IsInferred` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `Description` mediumtext CHARACTER SET utf8,
  `PublishDate` datetime DEFAULT NULL,
  `LastSynced` datetime DEFAULT NULL,
  `OwnerID` int(11) NOT NULL DEFAULT '0',
  `PublisherID` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ChangeSet`
--

INSERT INTO `ChangeSet` (`ID`, `ClassName`, `LastEdited`, `Created`, `Name`, `State`, `IsInferred`, `Description`, `PublishDate`, `LastSynced`, `OwnerID`, `PublisherID`) VALUES
(1, 'SilverStripe\\Versioned\\ChangeSet', '2018-01-12 06:10:50', '2018-01-12 06:10:49', 'Generated by publish of \'Testimonials\' at Jan 12, 2018, 6:10:49 AM', 'published', 1, NULL, '2018-01-12 06:10:50', '2018-01-12 06:10:50', 0, 1),
(2, 'SilverStripe\\Versioned\\ChangeSet', '2018-01-12 06:12:31', '2018-01-12 06:12:31', 'Generated by publish of \'First View\' at Jan 12, 2018, 6:12:31 AM', 'published', 1, NULL, '2018-01-12 06:12:31', '2018-01-12 06:12:31', 0, 1),
(3, 'SilverStripe\\Versioned\\ChangeSet', '2018-01-12 06:15:29', '2018-01-12 06:15:28', 'Generated by publish of \'First View\' at Jan 12, 2018, 6:15:28 AM', 'published', 1, NULL, '2018-01-12 06:15:29', '2018-01-12 06:15:28', 0, 1),
(4, 'SilverStripe\\Versioned\\ChangeSet', '2018-01-12 06:15:50', '2018-01-12 06:15:50', 'Generated by publish of \'First View\' at Jan 12, 2018, 6:15:50 AM', 'published', 1, NULL, '2018-01-12 06:15:50', '2018-01-12 06:15:50', 0, 1),
(5, 'SilverStripe\\Versioned\\ChangeSet', '2018-01-12 06:16:41', '2018-01-12 06:16:41', 'Generated by publish of \'Second View\' at Jan 12, 2018, 6:16:41 AM', 'published', 1, NULL, '2018-01-12 06:16:41', '2018-01-12 06:16:41', 0, 1),
(6, 'SilverStripe\\Versioned\\ChangeSet', '2018-01-12 06:17:23', '2018-01-12 06:17:22', 'Generated by publish of \'Third View\' at Jan 12, 2018, 6:17:22 AM', 'published', 1, NULL, '2018-01-12 06:17:23', '2018-01-12 06:17:22', 0, 1),
(7, 'SilverStripe\\Versioned\\ChangeSet', '2018-01-12 06:40:04', '2018-01-12 06:40:04', 'Generated by publish of \'Store the file in a BLOB field\' at Jan 12, 2018, 6:40:04 AM', 'published', 1, NULL, '2018-01-12 06:40:04', '2018-01-12 06:40:04', 0, 1),
(8, 'SilverStripe\\Versioned\\ChangeSet', '2018-01-12 06:42:01', '2018-01-12 06:42:01', 'Generated by publish of \'Store the file in a BLOB field\' at Jan 12, 2018, 6:42:01 AM', 'published', 1, NULL, '2018-01-12 06:42:01', '2018-01-12 06:42:01', 0, 1),
(9, 'SilverStripe\\Versioned\\ChangeSet', '2018-01-12 06:42:04', '2018-01-12 06:42:03', 'Generated by publish of \'First View\' at Jan 12, 2018, 6:42:03 AM', 'published', 1, NULL, '2018-01-12 06:42:04', '2018-01-12 06:42:04', 0, 1),
(10, 'SilverStripe\\Versioned\\ChangeSet', '2018-01-12 06:42:06', '2018-01-12 06:42:06', 'Generated by publish of \'Second View\' at Jan 12, 2018, 6:42:06 AM', 'published', 1, NULL, '2018-01-12 06:42:06', '2018-01-12 06:42:06', 0, 1),
(11, 'SilverStripe\\Versioned\\ChangeSet', '2018-01-12 06:42:09', '2018-01-12 06:42:09', 'Generated by publish of \'Third View\' at Jan 12, 2018, 6:42:09 AM', 'published', 1, NULL, '2018-01-12 06:42:09', '2018-01-12 06:42:09', 0, 1),
(12, 'SilverStripe\\Versioned\\ChangeSet', '2018-01-12 06:50:47', '2018-01-12 06:50:47', 'Generated by publish of \'Optimise your time\' at Jan 12, 2018, 6:50:47 AM', 'published', 1, NULL, '2018-01-12 06:50:47', '2018-01-12 06:50:47', 0, 1),
(13, 'SilverStripe\\Versioned\\ChangeSet', '2018-01-12 06:51:58', '2018-01-12 06:51:58', 'Generated by publish of \'Improve your margins\' at Jan 12, 2018, 6:51:58 AM', 'published', 1, NULL, '2018-01-12 06:51:58', '2018-01-12 06:51:58', 0, 1),
(14, 'SilverStripe\\Versioned\\ChangeSet', '2018-01-12 06:52:23', '2018-01-12 06:52:23', 'Generated by publish of \'Scale your business\' at Jan 12, 2018, 6:52:23 AM', 'published', 1, NULL, '2018-01-12 06:52:23', '2018-01-12 06:52:23', 0, 1),
(15, 'SilverStripe\\Versioned\\ChangeSet', '2018-01-12 06:52:48', '2018-01-12 06:52:48', 'Generated by publish of \'Local, expert, qualified\' at Jan 12, 2018, 6:52:48 AM', 'published', 1, NULL, '2018-01-12 06:52:48', '2018-01-12 06:52:48', 0, 1),
(16, 'SilverStripe\\Versioned\\ChangeSet', '2018-01-12 07:15:06', '2018-01-12 07:15:06', 'Generated by publish of \'Optimise your time\' at Jan 12, 2018, 7:15:06 AM', 'published', 1, NULL, '2018-01-12 07:15:06', '2018-01-12 07:15:06', 0, 1),
(17, 'SilverStripe\\Versioned\\ChangeSet', '2018-01-12 07:15:27', '2018-01-12 07:15:27', 'Generated by publish of \'Improve your margins\' at Jan 12, 2018, 7:15:27 AM', 'published', 1, NULL, '2018-01-12 07:15:27', '2018-01-12 07:15:27', 0, 1),
(18, 'SilverStripe\\Versioned\\ChangeSet', '2018-01-12 07:15:35', '2018-01-12 07:15:35', 'Generated by publish of \'Scale your business\' at Jan 12, 2018, 7:15:35 AM', 'published', 1, NULL, '2018-01-12 07:15:35', '2018-01-12 07:15:35', 0, 1),
(19, 'SilverStripe\\Versioned\\ChangeSet', '2018-01-12 07:15:43', '2018-01-12 07:15:43', 'Generated by publish of \'Local, expert, qualified\' at Jan 12, 2018, 7:15:43 AM', 'published', 1, NULL, '2018-01-12 07:15:43', '2018-01-12 07:15:43', 0, 1),
(20, 'SilverStripe\\Versioned\\ChangeSet', '2018-01-12 07:15:52', '2018-01-12 07:15:52', 'Generated by publish of \'Optimise your time\' at Jan 12, 2018, 7:15:52 AM', 'published', 1, NULL, '2018-01-12 07:15:52', '2018-01-12 07:15:52', 0, 1),
(21, 'SilverStripe\\Versioned\\ChangeSet', '2018-01-12 07:16:00', '2018-01-12 07:16:00', 'Generated by publish of \'Improve your margins\' at Jan 12, 2018, 7:16:00 AM', 'published', 1, NULL, '2018-01-12 07:16:00', '2018-01-12 07:16:00', 0, 1),
(22, 'SilverStripe\\Versioned\\ChangeSet', '2018-01-12 07:16:08', '2018-01-12 07:16:07', 'Generated by publish of \'Scale your business\' at Jan 12, 2018, 7:16:07 AM', 'published', 1, NULL, '2018-01-12 07:16:08', '2018-01-12 07:16:08', 0, 1),
(23, 'SilverStripe\\Versioned\\ChangeSet', '2018-01-12 07:16:14', '2018-01-12 07:16:14', 'Generated by publish of \'Local, expert, qualified\' at Jan 12, 2018, 7:16:14 AM', 'published', 1, NULL, '2018-01-12 07:16:14', '2018-01-12 07:16:14', 0, 1),
(24, 'SilverStripe\\Versioned\\ChangeSet', '2018-01-12 07:20:27', '2018-01-12 07:20:26', 'Generated by publish of \'Store the file in a BLOB field\' at Jan 12, 2018, 7:20:26 AM', 'published', 1, NULL, '2018-01-12 07:20:27', '2018-01-12 07:20:27', 0, 1),
(25, 'SilverStripe\\Versioned\\ChangeSet', '2018-01-12 07:20:41', '2018-01-12 07:20:41', 'Generated by publish of \'First View\' at Jan 12, 2018, 7:20:41 AM', 'published', 1, NULL, '2018-01-12 07:20:41', '2018-01-12 07:20:41', 0, 1),
(26, 'SilverStripe\\Versioned\\ChangeSet', '2018-01-12 07:20:51', '2018-01-12 07:20:51', 'Generated by publish of \'Second View\' at Jan 12, 2018, 7:20:51 AM', 'published', 1, NULL, '2018-01-12 07:20:51', '2018-01-12 07:20:51', 0, 1),
(27, 'SilverStripe\\Versioned\\ChangeSet', '2018-01-12 07:20:58', '2018-01-12 07:20:58', 'Generated by publish of \'Third View\' at Jan 12, 2018, 7:20:58 AM', 'published', 1, NULL, '2018-01-12 07:20:58', '2018-01-12 07:20:58', 0, 1),
(28, 'SilverStripe\\Versioned\\ChangeSet', '2018-01-12 07:21:06', '2018-01-12 07:21:05', 'Generated by publish of \'Store the file in a BLOB field\' at Jan 12, 2018, 7:21:05 AM', 'published', 1, NULL, '2018-01-12 07:21:06', '2018-01-12 07:21:05', 0, 1),
(29, 'SilverStripe\\Versioned\\ChangeSet', '2018-01-12 07:21:15', '2018-01-12 07:21:15', 'Generated by publish of \'First View\' at Jan 12, 2018, 7:21:15 AM', 'published', 1, NULL, '2018-01-12 07:21:15', '2018-01-12 07:21:15', 0, 1),
(30, 'SilverStripe\\Versioned\\ChangeSet', '2018-01-12 07:21:24', '2018-01-12 07:21:24', 'Generated by publish of \'Second View\' at Jan 12, 2018, 7:21:24 AM', 'published', 1, NULL, '2018-01-12 07:21:24', '2018-01-12 07:21:24', 0, 1),
(31, 'SilverStripe\\Versioned\\ChangeSet', '2018-01-12 07:21:34', '2018-01-12 07:21:33', 'Generated by publish of \'Third View\' at Jan 12, 2018, 7:21:33 AM', 'published', 1, NULL, '2018-01-12 07:21:34', '2018-01-12 07:21:34', 0, 1),
(32, 'SilverStripe\\Versioned\\ChangeSet', '2018-01-12 07:23:51', '2018-01-12 07:23:51', 'Generated by publish of \'Banner 1\' at Jan 12, 2018, 7:23:51 AM', 'published', 1, NULL, '2018-01-12 07:23:51', '2018-01-12 07:23:51', 0, 1),
(33, 'SilverStripe\\Versioned\\ChangeSet', '2018-01-12 07:24:21', '2018-01-12 07:24:21', 'Generated by publish of \'Banner 2\' at Jan 12, 2018, 7:24:21 AM', 'published', 1, NULL, '2018-01-12 07:24:21', '2018-01-12 07:24:21', 0, 1),
(34, 'SilverStripe\\Versioned\\ChangeSet', '2018-01-12 07:41:27', '2018-01-12 07:41:27', 'Generated by publish of \'PARAPLANNING\' at Jan 12, 2018, 7:41:27 AM', 'published', 1, NULL, '2018-01-12 07:41:27', '2018-01-12 07:41:27', 0, 1),
(35, 'SilverStripe\\Versioned\\ChangeSet', '2018-01-12 07:41:45', '2018-01-12 07:41:45', 'Generated by publish of \'PARAPLANNING\' at Jan 12, 2018, 7:41:45 AM', 'published', 1, NULL, '2018-01-12 07:41:45', '2018-01-12 07:41:45', 0, 1),
(36, 'SilverStripe\\Versioned\\ChangeSet', '2018-01-16 09:49:52', '2018-01-16 09:49:51', 'Generated by publish of \'Our blog\' at Jan 16, 2018, 9:49:51 AM', 'published', 1, NULL, '2018-01-16 09:49:52', '2018-01-16 09:49:52', 0, 1),
(37, 'SilverStripe\\Versioned\\ChangeSet', '2018-01-16 09:51:24', '2018-01-16 09:51:23', 'Generated by publish of \'Suspendisse consectetur fringilla luctus\' at Jan 16, 2018, 9:51:23 AM', 'published', 1, NULL, '2018-01-16 09:51:24', '2018-01-16 09:51:24', 0, 1),
(38, 'SilverStripe\\Versioned\\ChangeSet', '2018-01-16 09:59:26', '2018-01-16 09:59:26', 'Generated by publish of \'Suspendisse consectetur fringilla luctus\' at Jan 16, 2018, 9:59:26 AM', 'published', 1, NULL, '2018-01-16 09:59:26', '2018-01-16 09:59:26', 0, 1),
(39, 'SilverStripe\\Versioned\\ChangeSet', '2018-01-16 10:32:36', '2018-01-16 10:32:36', 'Generated by publish of \'Suspendisse consectetur fringilla luctus\' at Jan 16, 2018, 10:32:36 AM', 'published', 1, NULL, '2018-01-16 10:32:36', '2018-01-16 10:32:36', 0, 1),
(40, 'SilverStripe\\Versioned\\ChangeSet', '2018-01-16 10:32:42', '2018-01-16 10:32:42', 'Generated by publish of \'Suspendisse consectetur fringilla luctus\' at Jan 16, 2018, 10:32:42 AM', 'published', 1, NULL, '2018-01-16 10:32:42', '2018-01-16 10:32:42', 0, 1),
(41, 'SilverStripe\\Versioned\\ChangeSet', '2018-01-16 10:33:12', '2018-01-16 10:33:11', 'Generated by publish of \'Suspendisse consectetur fringilla luctus\' at Jan 16, 2018, 10:33:11 AM', 'published', 1, NULL, '2018-01-16 10:33:12', '2018-01-16 10:33:12', 0, 1),
(42, 'SilverStripe\\Versioned\\ChangeSet', '2018-01-16 10:33:38', '2018-01-16 10:33:38', 'Generated by publish of \'Suspendisse consectetur fringilla luctus 1\' at Jan 16, 2018, 10:33:38 AM', 'published', 1, NULL, '2018-01-16 10:33:38', '2018-01-16 10:33:38', 0, 1),
(43, 'SilverStripe\\Versioned\\ChangeSet', '2018-01-16 10:33:46', '2018-01-16 10:33:46', 'Generated by publish of \'Suspendisse consectetur fringilla luctus 2\' at Jan 16, 2018, 10:33:46 AM', 'published', 1, NULL, '2018-01-16 10:33:46', '2018-01-16 10:33:46', 0, 1),
(44, 'SilverStripe\\Versioned\\ChangeSet', '2018-01-16 10:34:16', '2018-01-16 10:34:16', 'Generated by publish of \'Suspendisse consectetur fringilla luctus 3\' at Jan 16, 2018, 10:34:16 AM', 'published', 1, NULL, '2018-01-16 10:34:16', '2018-01-16 10:34:16', 0, 1),
(45, 'SilverStripe\\Versioned\\ChangeSet', '2018-01-16 13:52:08', '2018-01-16 13:52:08', 'Generated by publish of \'Home\' at Jan 16, 2018, 1:52:08 PM', 'published', 1, NULL, '2018-01-16 13:52:08', '2018-01-16 13:52:08', 0, 1),
(46, 'SilverStripe\\Versioned\\ChangeSet', '2018-01-16 13:52:17', '2018-01-16 13:52:17', 'Generated by publish of \'Home\' at Jan 16, 2018, 1:52:17 PM', 'published', 1, NULL, '2018-01-16 13:52:17', '2018-01-16 13:52:17', 0, 1),
(47, 'SilverStripe\\Versioned\\ChangeSet', '2018-01-16 13:52:36', '2018-01-16 13:52:36', 'Generated by publish of \'Home\' at Jan 16, 2018, 1:52:36 PM', 'published', 1, NULL, '2018-01-16 13:52:36', '2018-01-16 13:52:36', 0, 1),
(48, 'SilverStripe\\Versioned\\ChangeSet', '2018-01-16 13:52:46', '2018-01-16 13:52:46', 'Generated by publish of \'Home\' at Jan 16, 2018, 1:52:46 PM', 'published', 1, NULL, '2018-01-16 13:52:46', '2018-01-16 13:52:46', 0, 1),
(49, 'SilverStripe\\Versioned\\ChangeSet', '2018-01-16 13:53:11', '2018-01-16 13:53:11', 'Generated by publish of \'Home\' at Jan 16, 2018, 1:53:11 PM', 'published', 1, NULL, '2018-01-16 13:53:11', '2018-01-16 13:53:11', 0, 1),
(50, 'SilverStripe\\Versioned\\ChangeSet', '2018-01-16 13:53:19', '2018-01-16 13:53:18', 'Generated by publish of \'Home\' at Jan 16, 2018, 1:53:18 PM', 'published', 1, NULL, '2018-01-16 13:53:19', '2018-01-16 13:53:18', 0, 1),
(51, 'SilverStripe\\Versioned\\ChangeSet', '2018-01-16 13:54:40', '2018-01-16 13:54:40', 'Generated by publish of \'Home\' at Jan 16, 2018, 1:54:40 PM', 'published', 1, NULL, '2018-01-16 13:54:40', '2018-01-16 13:54:40', 0, 1),
(52, 'SilverStripe\\Versioned\\ChangeSet', '2018-01-16 13:54:54', '2018-01-16 13:54:54', 'Generated by publish of \'Home\' at Jan 16, 2018, 1:54:54 PM', 'published', 1, NULL, '2018-01-16 13:54:54', '2018-01-16 13:54:54', 0, 1),
(53, 'SilverStripe\\Versioned\\ChangeSet', '2018-01-16 14:15:52', '2018-01-16 14:15:52', 'Generated by publish of \'OUTSOURCED PARAPLANNING\' at Jan 16, 2018, 2:15:52 PM', 'published', 1, NULL, '2018-01-16 14:15:52', '2018-01-16 14:15:52', 0, 1),
(54, 'SilverStripe\\Versioned\\ChangeSet', '2018-01-16 14:16:26', '2018-01-16 14:16:26', 'Generated by publish of \'OUTSOURCED TRANSITION MANAGEMENT\' at Jan 16, 2018, 2:16:26 PM', 'published', 1, NULL, '2018-01-16 14:16:26', '2018-01-16 14:16:26', 0, 1),
(55, 'SilverStripe\\Versioned\\ChangeSet', '2018-01-16 14:17:19', '2018-01-16 14:17:18', 'Generated by publish of \'OUTSOURCED PARAPLANNING\' at Jan 16, 2018, 2:17:18 PM', 'published', 1, NULL, '2018-01-16 14:17:19', '2018-01-16 14:17:19', 0, 1),
(56, 'SilverStripe\\Versioned\\ChangeSet', '2018-01-16 14:17:54', '2018-01-16 14:17:54', 'Generated by publish of \'OUTSOURCED PARAPLANNING\' at Jan 16, 2018, 2:17:54 PM', 'published', 1, NULL, '2018-01-16 14:17:54', '2018-01-16 14:17:54', 0, 1),
(57, 'SilverStripe\\Versioned\\ChangeSet', '2018-01-16 14:19:10', '2018-01-16 14:19:10', 'Generated by publish of \'OUTSOURCED PARAPLANNING\' at Jan 16, 2018, 2:19:10 PM', 'published', 1, NULL, '2018-01-16 14:19:10', '2018-01-16 14:19:10', 0, 1),
(58, 'SilverStripe\\Versioned\\ChangeSet', '2018-01-16 14:19:20', '2018-01-16 14:19:20', 'Generated by publish of \'OUTSOURCED TRANSITION MANAGEMENT\' at Jan 16, 2018, 2:19:20 PM', 'published', 1, NULL, '2018-01-16 14:19:20', '2018-01-16 14:19:20', 0, 1),
(59, 'SilverStripe\\Versioned\\ChangeSet', '2018-01-16 14:19:33', '2018-01-16 14:19:32', 'Generated by publish of \'OUTSOURCED TRANSITION MANAGEMENT\' at Jan 16, 2018, 2:19:32 PM', 'published', 1, NULL, '2018-01-16 14:19:33', '2018-01-16 14:19:33', 0, 1),
(60, 'SilverStripe\\Versioned\\ChangeSet', '2018-01-16 14:20:29', '2018-01-16 14:20:28', 'Generated by publish of \'Image\' at Jan 16, 2018, 2:20:28 PM', 'published', 1, NULL, '2018-01-16 14:20:29', '2018-01-16 14:20:29', 0, 1),
(61, 'SilverStripe\\Versioned\\ChangeSet', '2018-01-16 14:21:07', '2018-01-16 14:21:07', 'Generated by publish of \'PADUA TECHNOLOGY\' at Jan 16, 2018, 2:21:07 PM', 'published', 1, NULL, '2018-01-16 14:21:07', '2018-01-16 14:21:07', 0, 1),
(62, 'SilverStripe\\Versioned\\ChangeSet', '2018-01-17 06:05:49', '2018-01-17 06:05:49', 'Generated by publish of \'Home Page\' at Jan 17, 2018, 6:05:49 AM', 'published', 1, NULL, '2018-01-17 06:05:49', '2018-01-17 06:05:49', 0, 1),
(63, 'SilverStripe\\Versioned\\ChangeSet', '2018-01-17 06:09:25', '2018-01-17 06:09:25', 'Generated by publish of \'OUTSOURCED PARAPLANNING\' at Jan 17, 2018, 6:09:25 AM', 'published', 1, NULL, '2018-01-17 06:09:25', '2018-01-17 06:09:25', 0, 1),
(64, 'SilverStripe\\Versioned\\ChangeSet', '2018-01-17 07:28:50', '2018-01-17 07:28:50', 'Generated by publish of \'OUTSOURCED PARAPLANNING\' at Jan 17, 2018, 7:28:50 AM', 'published', 1, NULL, '2018-01-17 07:28:50', '2018-01-17 07:28:50', 0, 1),
(65, 'SilverStripe\\Versioned\\ChangeSet', '2018-01-17 07:28:55', '2018-01-17 07:28:55', 'Generated by publish of \'OUTSOURCED TRANSITION MANAGEMENT\' at Jan 17, 2018, 7:28:55 AM', 'published', 1, NULL, '2018-01-17 07:28:55', '2018-01-17 07:28:55', 0, 1),
(66, 'SilverStripe\\Versioned\\ChangeSet', '2018-01-17 07:29:06', '2018-01-17 07:29:06', 'Generated by publish of \'PADUA TECHNOLOGY\' at Jan 17, 2018, 7:29:06 AM', 'published', 1, NULL, '2018-01-17 07:29:06', '2018-01-17 07:29:06', 0, 1),
(67, 'SilverStripe\\Versioned\\ChangeSet', '2018-01-17 07:49:51', '2018-01-17 07:49:51', 'Generated by publish of \' TRANSITION MANAGEMENT\' at Jan 17, 2018, 7:49:51 AM', 'published', 1, NULL, '2018-01-17 07:49:51', '2018-01-17 07:49:51', 0, 1),
(68, 'SilverStripe\\Versioned\\ChangeSet', '2018-01-17 07:49:58', '2018-01-17 07:49:58', 'Generated by publish of \' TRANSITION MANAGEMENT\' at Jan 17, 2018, 7:49:58 AM', 'published', 1, NULL, '2018-01-17 07:49:58', '2018-01-17 07:49:58', 0, 1),
(69, 'SilverStripe\\Versioned\\ChangeSet', '2018-01-17 07:50:37', '2018-01-17 07:50:36', 'Generated by publish of \'TECHNOLOGY\' at Jan 17, 2018, 7:50:36 AM', 'published', 1, NULL, '2018-01-17 07:50:37', '2018-01-17 07:50:36', 0, 1),
(70, 'SilverStripe\\Versioned\\ChangeSet', '2018-01-17 07:50:49', '2018-01-17 07:50:49', 'Generated by publish of \'TECHNOLOGY\' at Jan 17, 2018, 7:50:49 AM', 'published', 1, NULL, '2018-01-17 07:50:49', '2018-01-17 07:50:49', 0, 1),
(71, 'SilverStripe\\Versioned\\ChangeSet', '2018-01-17 07:50:57', '2018-01-17 07:50:57', 'Generated by publish of \'ABOUT\' at Jan 17, 2018, 7:50:57 AM', 'published', 1, NULL, '2018-01-17 07:50:57', '2018-01-17 07:50:57', 0, 1),
(72, 'SilverStripe\\Versioned\\ChangeSet', '2018-01-17 07:51:14', '2018-01-17 07:51:14', 'Generated by publish of \'CAREERS\' at Jan 17, 2018, 7:51:14 AM', 'published', 1, NULL, '2018-01-17 07:51:14', '2018-01-17 07:51:14', 0, 1),
(73, 'SilverStripe\\Versioned\\ChangeSet', '2018-01-17 07:51:47', '2018-01-17 07:51:47', 'Generated by publish of \'Our blog\' at Jan 17, 2018, 7:51:47 AM', 'published', 1, NULL, '2018-01-17 07:51:47', '2018-01-17 07:51:47', 0, 1),
(74, 'SilverStripe\\Versioned\\ChangeSet', '2018-01-17 07:52:01', '2018-01-17 07:52:00', 'Generated by publish of \'Contact Us\' at Jan 17, 2018, 7:52:00 AM', 'published', 1, NULL, '2018-01-17 07:52:01', '2018-01-17 07:52:01', 0, 1),
(75, 'SilverStripe\\Versioned\\ChangeSet', '2018-01-17 07:52:12', '2018-01-17 07:52:12', 'Generated by publish of \'Home\' at Jan 17, 2018, 7:52:12 AM', 'published', 1, NULL, '2018-01-17 07:52:12', '2018-01-17 07:52:12', 0, 1),
(76, 'SilverStripe\\Versioned\\ChangeSet', '2018-01-17 07:52:53', '2018-01-17 07:52:53', 'Generated by publish of \'CAREERS\' at Jan 17, 2018, 7:52:53 AM', 'published', 1, NULL, '2018-01-17 07:52:53', '2018-01-17 07:52:53', 0, 1),
(77, 'SilverStripe\\Versioned\\ChangeSet', '2018-01-17 07:53:10', '2018-01-17 07:53:09', 'Generated by publish of \'CAREERS\' at Jan 17, 2018, 7:53:09 AM', 'published', 1, NULL, '2018-01-17 07:53:10', '2018-01-17 07:53:09', 0, 1),
(78, 'SilverStripe\\Versioned\\ChangeSet', '2018-01-17 07:53:23', '2018-01-17 07:53:23', 'Generated by publish of \'CAREERS NOT USED\' at Jan 17, 2018, 7:53:23 AM', 'published', 1, NULL, '2018-01-17 07:53:23', '2018-01-17 07:53:23', 0, 1),
(79, 'SilverStripe\\Versioned\\ChangeSet', '2018-01-17 07:53:29', '2018-01-17 07:53:29', 'Generated by publish of \'CAREERS NOT USED\' at Jan 17, 2018, 7:53:29 AM', 'published', 1, NULL, '2018-01-17 07:53:29', '2018-01-17 07:53:29', 0, 1),
(80, 'SilverStripe\\Versioned\\ChangeSet', '2018-01-17 08:00:53', '2018-01-17 08:00:53', 'Generated by publish of \'Home\' at Jan 17, 2018, 8:00:53 AM', 'published', 1, NULL, '2018-01-17 08:00:53', '2018-01-17 08:00:53', 0, 1),
(81, 'SilverStripe\\Versioned\\ChangeSet', '2018-01-17 08:05:21', '2018-01-17 08:05:21', 'Generated by publish of \'ABOUT\' at Jan 17, 2018, 8:05:21 AM', 'published', 1, NULL, '2018-01-17 08:05:21', '2018-01-17 08:05:21', 0, 1),
(82, 'SilverStripe\\Versioned\\ChangeSet', '2018-01-17 08:05:41', '2018-01-17 08:05:41', 'Generated by publish of \'Contact Us\' at Jan 17, 2018, 8:05:41 AM', 'published', 1, NULL, '2018-01-17 08:05:41', '2018-01-17 08:05:41', 0, 1),
(83, 'SilverStripe\\Versioned\\ChangeSet', '2018-01-17 08:06:09', '2018-01-17 08:06:09', 'Generated by publish of \'Blog\' at Jan 17, 2018, 8:06:09 AM', 'published', 1, NULL, '2018-01-17 08:06:09', '2018-01-17 08:06:09', 0, 1),
(84, 'SilverStripe\\Versioned\\ChangeSet', '2018-01-17 08:06:28', '2018-01-17 08:06:28', 'Generated by publish of \'Our Privacy Policy\' at Jan 17, 2018, 8:06:28 AM', 'published', 1, NULL, '2018-01-17 08:06:28', '2018-01-17 08:06:28', 0, 1),
(85, 'SilverStripe\\Versioned\\ChangeSet', '2018-01-17 08:07:08', '2018-01-17 08:07:08', 'Generated by publish of \'Contact\' at Jan 17, 2018, 8:07:08 AM', 'published', 1, NULL, '2018-01-17 08:07:08', '2018-01-17 08:07:08', 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `ChangeSetItem`
--

CREATE TABLE `ChangeSetItem` (
  `ID` int(11) NOT NULL,
  `ClassName` enum('SilverStripe\\Versioned\\ChangeSetItem') CHARACTER SET utf8 DEFAULT 'SilverStripe\\Versioned\\ChangeSetItem',
  `LastEdited` datetime DEFAULT NULL,
  `Created` datetime DEFAULT NULL,
  `VersionBefore` int(11) NOT NULL DEFAULT '0',
  `VersionAfter` int(11) NOT NULL DEFAULT '0',
  `Added` enum('explicitly','implicitly') CHARACTER SET utf8 DEFAULT 'implicitly',
  `ChangeSetID` int(11) NOT NULL DEFAULT '0',
  `ObjectID` int(11) NOT NULL DEFAULT '0',
  `ObjectClass` enum('SilverStripe\\Assets\\File','SilverStripe\\SiteConfig\\SiteConfig','SilverStripe\\Versioned\\ChangeSet','SilverStripe\\Versioned\\ChangeSetItem','Axllent\\Weblog\\Model\\BlogCategory','SilverStripe\\CMS\\Model\\SiteTree','SilverStripe\\Security\\Group','SilverStripe\\Security\\LoginAttempt','SilverStripe\\Security\\Member','SilverStripe\\Security\\MemberPassword','SilverStripe\\Security\\Permission','SilverStripe\\Security\\PermissionRole','SilverStripe\\Security\\PermissionRoleCode','SilverStripe\\Security\\RememberLoginHash','SilverStripe\\Assets\\Folder','SilverStripe\\Assets\\Image','HomePage','Page','PaduaHome\\Component\\Banners','PaduaHome\\Component\\HomePageBoxes','PaduaHome\\Component\\Services','PaduaHome\\Component\\Testimonials','SilverStripe\\ErrorPage\\ErrorPage','Axllent\\Weblog\\Model\\Blog','Axllent\\Weblog\\Model\\BlogPost','SilverStripe\\CMS\\Model\\RedirectorPage','SilverStripe\\CMS\\Model\\VirtualPage') CHARACTER SET utf8 DEFAULT 'SilverStripe\\Assets\\File'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ChangeSetItem`
--

INSERT INTO `ChangeSetItem` (`ID`, `ClassName`, `LastEdited`, `Created`, `VersionBefore`, `VersionAfter`, `Added`, `ChangeSetID`, `ObjectID`, `ObjectClass`) VALUES
(2, 'SilverStripe\\Versioned\\ChangeSetItem', '2018-01-12 06:12:31', '2018-01-12 06:12:31', 0, 2, 'explicitly', 2, 7, 'SilverStripe\\CMS\\Model\\SiteTree'),
(3, 'SilverStripe\\Versioned\\ChangeSetItem', '2018-01-12 06:15:29', '2018-01-12 06:15:28', 2, 3, 'explicitly', 3, 7, 'SilverStripe\\CMS\\Model\\SiteTree'),
(4, 'SilverStripe\\Versioned\\ChangeSetItem', '2018-01-12 06:15:29', '2018-01-12 06:15:28', 0, 1, 'implicitly', 3, 2, 'SilverStripe\\Assets\\File'),
(5, 'SilverStripe\\Versioned\\ChangeSetItem', '2018-01-12 06:15:50', '2018-01-12 06:15:50', 3, 4, 'explicitly', 4, 7, 'SilverStripe\\CMS\\Model\\SiteTree'),
(6, 'SilverStripe\\Versioned\\ChangeSetItem', '2018-01-12 06:15:50', '2018-01-12 06:15:50', 1, 1, 'implicitly', 4, 2, 'SilverStripe\\Assets\\File'),
(7, 'SilverStripe\\Versioned\\ChangeSetItem', '2018-01-12 06:16:41', '2018-01-12 06:16:41', 0, 2, 'explicitly', 5, 8, 'SilverStripe\\CMS\\Model\\SiteTree'),
(8, 'SilverStripe\\Versioned\\ChangeSetItem', '2018-01-12 06:16:41', '2018-01-12 06:16:41', 0, 1, 'implicitly', 5, 3, 'SilverStripe\\Assets\\File'),
(9, 'SilverStripe\\Versioned\\ChangeSetItem', '2018-01-12 06:17:23', '2018-01-12 06:17:22', 0, 2, 'explicitly', 6, 9, 'SilverStripe\\CMS\\Model\\SiteTree'),
(10, 'SilverStripe\\Versioned\\ChangeSetItem', '2018-01-12 06:17:23', '2018-01-12 06:17:22', 0, 1, 'implicitly', 6, 4, 'SilverStripe\\Assets\\File'),
(11, 'SilverStripe\\Versioned\\ChangeSetItem', '2018-01-12 06:40:04', '2018-01-12 06:40:04', 0, 2, 'explicitly', 7, 10, 'SilverStripe\\CMS\\Model\\SiteTree'),
(12, 'SilverStripe\\Versioned\\ChangeSetItem', '2018-01-12 06:40:04', '2018-01-12 06:40:04', 0, 1, 'implicitly', 7, 5, 'SilverStripe\\Assets\\File'),
(13, 'SilverStripe\\Versioned\\ChangeSetItem', '2018-01-12 06:42:01', '2018-01-12 06:42:01', 2, 2, 'explicitly', 8, 10, 'SilverStripe\\CMS\\Model\\SiteTree'),
(14, 'SilverStripe\\Versioned\\ChangeSetItem', '2018-01-12 06:42:01', '2018-01-12 06:42:01', 1, 1, 'implicitly', 8, 5, 'SilverStripe\\Assets\\File'),
(15, 'SilverStripe\\Versioned\\ChangeSetItem', '2018-01-12 06:42:04', '2018-01-12 06:42:03', 4, 6, 'explicitly', 9, 7, 'SilverStripe\\CMS\\Model\\SiteTree'),
(16, 'SilverStripe\\Versioned\\ChangeSetItem', '2018-01-12 06:42:04', '2018-01-12 06:42:04', 1, 1, 'implicitly', 9, 2, 'SilverStripe\\Assets\\File'),
(17, 'SilverStripe\\Versioned\\ChangeSetItem', '2018-01-12 06:42:06', '2018-01-12 06:42:06', 2, 4, 'explicitly', 10, 8, 'SilverStripe\\CMS\\Model\\SiteTree'),
(18, 'SilverStripe\\Versioned\\ChangeSetItem', '2018-01-12 06:42:06', '2018-01-12 06:42:06', 1, 1, 'implicitly', 10, 3, 'SilverStripe\\Assets\\File'),
(19, 'SilverStripe\\Versioned\\ChangeSetItem', '2018-01-12 06:42:09', '2018-01-12 06:42:09', 2, 4, 'explicitly', 11, 9, 'SilverStripe\\CMS\\Model\\SiteTree'),
(20, 'SilverStripe\\Versioned\\ChangeSetItem', '2018-01-12 06:42:09', '2018-01-12 06:42:09', 1, 1, 'implicitly', 11, 4, 'SilverStripe\\Assets\\File'),
(21, 'SilverStripe\\Versioned\\ChangeSetItem', '2018-01-12 06:50:47', '2018-01-12 06:50:47', 0, 2, 'explicitly', 12, 11, 'SilverStripe\\CMS\\Model\\SiteTree'),
(23, 'SilverStripe\\Versioned\\ChangeSetItem', '2018-01-12 06:51:58', '2018-01-12 06:51:58', 0, 2, 'explicitly', 13, 12, 'SilverStripe\\CMS\\Model\\SiteTree'),
(24, 'SilverStripe\\Versioned\\ChangeSetItem', '2018-01-12 06:51:58', '2018-01-12 06:51:58', 0, 1, 'implicitly', 13, 7, 'SilverStripe\\Assets\\File'),
(25, 'SilverStripe\\Versioned\\ChangeSetItem', '2018-01-12 06:52:23', '2018-01-12 06:52:23', 0, 2, 'explicitly', 14, 13, 'SilverStripe\\CMS\\Model\\SiteTree'),
(26, 'SilverStripe\\Versioned\\ChangeSetItem', '2018-01-12 06:52:23', '2018-01-12 06:52:23', 0, 1, 'implicitly', 14, 8, 'SilverStripe\\Assets\\File'),
(27, 'SilverStripe\\Versioned\\ChangeSetItem', '2018-01-12 06:52:48', '2018-01-12 06:52:48', 0, 2, 'explicitly', 15, 14, 'SilverStripe\\CMS\\Model\\SiteTree'),
(28, 'SilverStripe\\Versioned\\ChangeSetItem', '2018-01-12 06:52:48', '2018-01-12 06:52:48', 0, 1, 'implicitly', 15, 9, 'SilverStripe\\Assets\\File'),
(29, 'SilverStripe\\Versioned\\ChangeSetItem', '2018-01-12 07:15:06', '2018-01-12 07:15:06', 2, 3, 'explicitly', 16, 11, 'SilverStripe\\CMS\\Model\\SiteTree'),
(30, 'SilverStripe\\Versioned\\ChangeSetItem', '2018-01-12 07:15:27', '2018-01-12 07:15:27', 2, 3, 'explicitly', 17, 12, 'SilverStripe\\CMS\\Model\\SiteTree'),
(31, 'SilverStripe\\Versioned\\ChangeSetItem', '2018-01-12 07:15:35', '2018-01-12 07:15:35', 2, 3, 'explicitly', 18, 13, 'SilverStripe\\CMS\\Model\\SiteTree'),
(32, 'SilverStripe\\Versioned\\ChangeSetItem', '2018-01-12 07:15:43', '2018-01-12 07:15:43', 2, 3, 'explicitly', 19, 14, 'SilverStripe\\CMS\\Model\\SiteTree'),
(33, 'SilverStripe\\Versioned\\ChangeSetItem', '2018-01-12 07:15:52', '2018-01-12 07:15:52', 3, 4, 'explicitly', 20, 11, 'SilverStripe\\CMS\\Model\\SiteTree'),
(34, 'SilverStripe\\Versioned\\ChangeSetItem', '2018-01-12 07:15:52', '2018-01-12 07:15:52', 0, 1, 'implicitly', 20, 10, 'SilverStripe\\Assets\\File'),
(35, 'SilverStripe\\Versioned\\ChangeSetItem', '2018-01-12 07:16:00', '2018-01-12 07:16:00', 3, 4, 'explicitly', 21, 12, 'SilverStripe\\CMS\\Model\\SiteTree'),
(36, 'SilverStripe\\Versioned\\ChangeSetItem', '2018-01-12 07:16:00', '2018-01-12 07:16:00', 0, 1, 'implicitly', 21, 11, 'SilverStripe\\Assets\\File'),
(37, 'SilverStripe\\Versioned\\ChangeSetItem', '2018-01-12 07:16:08', '2018-01-12 07:16:07', 3, 4, 'explicitly', 22, 13, 'SilverStripe\\CMS\\Model\\SiteTree'),
(38, 'SilverStripe\\Versioned\\ChangeSetItem', '2018-01-12 07:16:08', '2018-01-12 07:16:08', 0, 1, 'implicitly', 22, 12, 'SilverStripe\\Assets\\File'),
(39, 'SilverStripe\\Versioned\\ChangeSetItem', '2018-01-12 07:16:14', '2018-01-12 07:16:14', 3, 4, 'explicitly', 23, 14, 'SilverStripe\\CMS\\Model\\SiteTree'),
(40, 'SilverStripe\\Versioned\\ChangeSetItem', '2018-01-12 07:16:14', '2018-01-12 07:16:14', 0, 1, 'implicitly', 23, 13, 'SilverStripe\\Assets\\File'),
(41, 'SilverStripe\\Versioned\\ChangeSetItem', '2018-01-12 07:20:27', '2018-01-12 07:20:27', 2, 3, 'explicitly', 24, 10, 'SilverStripe\\CMS\\Model\\SiteTree'),
(42, 'SilverStripe\\Versioned\\ChangeSetItem', '2018-01-12 07:20:41', '2018-01-12 07:20:41', 6, 7, 'explicitly', 25, 7, 'SilverStripe\\CMS\\Model\\SiteTree'),
(43, 'SilverStripe\\Versioned\\ChangeSetItem', '2018-01-12 07:20:51', '2018-01-12 07:20:51', 4, 5, 'explicitly', 26, 8, 'SilverStripe\\CMS\\Model\\SiteTree'),
(44, 'SilverStripe\\Versioned\\ChangeSetItem', '2018-01-12 07:20:58', '2018-01-12 07:20:58', 4, 5, 'explicitly', 27, 9, 'SilverStripe\\CMS\\Model\\SiteTree'),
(45, 'SilverStripe\\Versioned\\ChangeSetItem', '2018-01-12 07:21:06', '2018-01-12 07:21:05', 3, 4, 'explicitly', 28, 10, 'SilverStripe\\CMS\\Model\\SiteTree'),
(46, 'SilverStripe\\Versioned\\ChangeSetItem', '2018-01-12 07:21:06', '2018-01-12 07:21:05', 0, 1, 'implicitly', 28, 14, 'SilverStripe\\Assets\\File'),
(47, 'SilverStripe\\Versioned\\ChangeSetItem', '2018-01-12 07:21:15', '2018-01-12 07:21:15', 7, 8, 'explicitly', 29, 7, 'SilverStripe\\CMS\\Model\\SiteTree'),
(48, 'SilverStripe\\Versioned\\ChangeSetItem', '2018-01-12 07:21:15', '2018-01-12 07:21:15', 0, 1, 'implicitly', 29, 15, 'SilverStripe\\Assets\\File'),
(49, 'SilverStripe\\Versioned\\ChangeSetItem', '2018-01-12 07:21:24', '2018-01-12 07:21:24', 5, 6, 'explicitly', 30, 8, 'SilverStripe\\CMS\\Model\\SiteTree'),
(50, 'SilverStripe\\Versioned\\ChangeSetItem', '2018-01-12 07:21:24', '2018-01-12 07:21:24', 0, 1, 'implicitly', 30, 16, 'SilverStripe\\Assets\\File'),
(51, 'SilverStripe\\Versioned\\ChangeSetItem', '2018-01-12 07:21:34', '2018-01-12 07:21:33', 5, 6, 'explicitly', 31, 9, 'SilverStripe\\CMS\\Model\\SiteTree'),
(53, 'SilverStripe\\Versioned\\ChangeSetItem', '2018-01-12 07:23:51', '2018-01-12 07:23:51', 0, 2, 'explicitly', 32, 15, 'SilverStripe\\CMS\\Model\\SiteTree'),
(54, 'SilverStripe\\Versioned\\ChangeSetItem', '2018-01-12 07:23:51', '2018-01-12 07:23:51', 0, 1, 'implicitly', 32, 18, 'SilverStripe\\Assets\\File'),
(55, 'SilverStripe\\Versioned\\ChangeSetItem', '2018-01-12 07:24:21', '2018-01-12 07:24:21', 0, 2, 'explicitly', 33, 16, 'SilverStripe\\CMS\\Model\\SiteTree'),
(56, 'SilverStripe\\Versioned\\ChangeSetItem', '2018-01-12 07:24:21', '2018-01-12 07:24:21', 0, 1, 'implicitly', 33, 19, 'SilverStripe\\Assets\\File'),
(57, 'SilverStripe\\Versioned\\ChangeSetItem', '2018-01-12 07:41:27', '2018-01-12 07:41:27', 0, 2, 'explicitly', 34, 18, 'SilverStripe\\CMS\\Model\\SiteTree'),
(58, 'SilverStripe\\Versioned\\ChangeSetItem', '2018-01-12 07:41:45', '2018-01-12 07:41:45', 2, 3, 'explicitly', 35, 18, 'SilverStripe\\CMS\\Model\\SiteTree'),
(59, 'SilverStripe\\Versioned\\ChangeSetItem', '2018-01-16 09:49:52', '2018-01-16 09:49:51', 0, 2, 'explicitly', 36, 19, 'SilverStripe\\CMS\\Model\\SiteTree'),
(60, 'SilverStripe\\Versioned\\ChangeSetItem', '2018-01-16 09:51:24', '2018-01-16 09:51:23', 0, 2, 'explicitly', 37, 20, 'SilverStripe\\CMS\\Model\\SiteTree'),
(61, 'SilverStripe\\Versioned\\ChangeSetItem', '2018-01-16 09:51:24', '2018-01-16 09:51:24', 0, 1, 'implicitly', 37, 21, 'SilverStripe\\Assets\\File'),
(62, 'SilverStripe\\Versioned\\ChangeSetItem', '2018-01-16 09:59:26', '2018-01-16 09:59:26', 2, 2, 'explicitly', 38, 20, 'SilverStripe\\CMS\\Model\\SiteTree'),
(63, 'SilverStripe\\Versioned\\ChangeSetItem', '2018-01-16 09:59:26', '2018-01-16 09:59:26', 1, 1, 'implicitly', 38, 21, 'SilverStripe\\Assets\\File'),
(64, 'SilverStripe\\Versioned\\ChangeSetItem', '2018-01-16 10:32:36', '2018-01-16 10:32:36', 0, 2, 'explicitly', 39, 21, 'SilverStripe\\CMS\\Model\\SiteTree'),
(65, 'SilverStripe\\Versioned\\ChangeSetItem', '2018-01-16 10:32:42', '2018-01-16 10:32:42', 3, 3, 'explicitly', 40, 21, 'SilverStripe\\CMS\\Model\\SiteTree'),
(66, 'SilverStripe\\Versioned\\ChangeSetItem', '2018-01-16 10:33:12', '2018-01-16 10:33:11', 3, 4, 'explicitly', 41, 21, 'SilverStripe\\CMS\\Model\\SiteTree'),
(67, 'SilverStripe\\Versioned\\ChangeSetItem', '2018-01-16 10:33:38', '2018-01-16 10:33:38', 4, 5, 'explicitly', 42, 21, 'SilverStripe\\CMS\\Model\\SiteTree'),
(68, 'SilverStripe\\Versioned\\ChangeSetItem', '2018-01-16 10:33:46', '2018-01-16 10:33:46', 2, 3, 'explicitly', 43, 20, 'SilverStripe\\CMS\\Model\\SiteTree'),
(69, 'SilverStripe\\Versioned\\ChangeSetItem', '2018-01-16 10:33:46', '2018-01-16 10:33:46', 1, 1, 'implicitly', 43, 21, 'SilverStripe\\Assets\\File'),
(70, 'SilverStripe\\Versioned\\ChangeSetItem', '2018-01-16 10:34:16', '2018-01-16 10:34:16', 0, 2, 'explicitly', 44, 22, 'SilverStripe\\CMS\\Model\\SiteTree'),
(71, 'SilverStripe\\Versioned\\ChangeSetItem', '2018-01-16 13:52:08', '2018-01-16 13:52:08', 1, 2, 'explicitly', 45, 1, 'SilverStripe\\CMS\\Model\\SiteTree'),
(72, 'SilverStripe\\Versioned\\ChangeSetItem', '2018-01-16 13:52:17', '2018-01-16 13:52:17', 2, 3, 'explicitly', 46, 1, 'SilverStripe\\CMS\\Model\\SiteTree'),
(73, 'SilverStripe\\Versioned\\ChangeSetItem', '2018-01-16 13:52:36', '2018-01-16 13:52:36', 3, 4, 'explicitly', 47, 1, 'SilverStripe\\CMS\\Model\\SiteTree'),
(74, 'SilverStripe\\Versioned\\ChangeSetItem', '2018-01-16 13:52:46', '2018-01-16 13:52:46', 4, 5, 'explicitly', 48, 1, 'SilverStripe\\CMS\\Model\\SiteTree'),
(79, 'SilverStripe\\Versioned\\ChangeSetItem', '2018-01-16 14:15:52', '2018-01-16 14:15:52', 0, 2, 'explicitly', 53, 24, 'SilverStripe\\CMS\\Model\\SiteTree'),
(80, 'SilverStripe\\Versioned\\ChangeSetItem', '2018-01-16 14:16:26', '2018-01-16 14:16:26', 0, 2, 'explicitly', 54, 25, 'SilverStripe\\CMS\\Model\\SiteTree'),
(81, 'SilverStripe\\Versioned\\ChangeSetItem', '2018-01-16 14:17:19', '2018-01-16 14:17:19', 2, 3, 'explicitly', 55, 24, 'SilverStripe\\CMS\\Model\\SiteTree'),
(82, 'SilverStripe\\Versioned\\ChangeSetItem', '2018-01-16 14:17:54', '2018-01-16 14:17:54', 3, 3, 'explicitly', 56, 24, 'SilverStripe\\CMS\\Model\\SiteTree'),
(83, 'SilverStripe\\Versioned\\ChangeSetItem', '2018-01-16 14:19:10', '2018-01-16 14:19:10', 3, 4, 'explicitly', 57, 24, 'SilverStripe\\CMS\\Model\\SiteTree'),
(84, 'SilverStripe\\Versioned\\ChangeSetItem', '2018-01-16 14:19:20', '2018-01-16 14:19:20', 2, 3, 'explicitly', 58, 25, 'SilverStripe\\CMS\\Model\\SiteTree'),
(85, 'SilverStripe\\Versioned\\ChangeSetItem', '2018-01-16 14:19:33', '2018-01-16 14:19:33', 3, 4, 'explicitly', 59, 25, 'SilverStripe\\CMS\\Model\\SiteTree'),
(86, 'SilverStripe\\Versioned\\ChangeSetItem', '2018-01-16 14:20:29', '2018-01-16 14:20:28', 0, 2, 'explicitly', 60, 26, 'SilverStripe\\CMS\\Model\\SiteTree'),
(87, 'SilverStripe\\Versioned\\ChangeSetItem', '2018-01-16 14:20:29', '2018-01-16 14:20:29', 0, 1, 'implicitly', 60, 22, 'SilverStripe\\Assets\\File'),
(88, 'SilverStripe\\Versioned\\ChangeSetItem', '2018-01-16 14:21:07', '2018-01-16 14:21:07', 0, 2, 'explicitly', 61, 27, 'SilverStripe\\CMS\\Model\\SiteTree'),
(90, 'SilverStripe\\Versioned\\ChangeSetItem', '2018-01-17 06:09:25', '2018-01-17 06:09:25', 4, 5, 'explicitly', 63, 24, 'SilverStripe\\CMS\\Model\\SiteTree'),
(91, 'SilverStripe\\Versioned\\ChangeSetItem', '2018-01-17 07:28:50', '2018-01-17 07:28:50', 5, 5, 'explicitly', 64, 24, 'SilverStripe\\CMS\\Model\\SiteTree'),
(92, 'SilverStripe\\Versioned\\ChangeSetItem', '2018-01-17 07:28:55', '2018-01-17 07:28:55', 4, 5, 'explicitly', 65, 25, 'SilverStripe\\CMS\\Model\\SiteTree'),
(93, 'SilverStripe\\Versioned\\ChangeSetItem', '2018-01-17 07:29:06', '2018-01-17 07:29:06', 2, 3, 'explicitly', 66, 27, 'SilverStripe\\CMS\\Model\\SiteTree'),
(94, 'SilverStripe\\Versioned\\ChangeSetItem', '2018-01-17 07:49:51', '2018-01-17 07:49:51', 0, 2, 'explicitly', 67, 29, 'SilverStripe\\CMS\\Model\\SiteTree'),
(95, 'SilverStripe\\Versioned\\ChangeSetItem', '2018-01-17 07:49:58', '2018-01-17 07:49:58', 2, 3, 'explicitly', 68, 29, 'SilverStripe\\CMS\\Model\\SiteTree'),
(96, 'SilverStripe\\Versioned\\ChangeSetItem', '2018-01-17 07:50:37', '2018-01-17 07:50:36', 0, 2, 'explicitly', 69, 30, 'SilverStripe\\CMS\\Model\\SiteTree'),
(97, 'SilverStripe\\Versioned\\ChangeSetItem', '2018-01-17 07:50:49', '2018-01-17 07:50:49', 2, 5, 'explicitly', 70, 30, 'SilverStripe\\CMS\\Model\\SiteTree'),
(98, 'SilverStripe\\Versioned\\ChangeSetItem', '2018-01-17 07:50:57', '2018-01-17 07:50:57', 1, 2, 'explicitly', 71, 2, 'SilverStripe\\CMS\\Model\\SiteTree'),
(99, 'SilverStripe\\Versioned\\ChangeSetItem', '2018-01-17 07:51:14', '2018-01-17 07:51:14', 0, 2, 'explicitly', 72, 31, 'SilverStripe\\CMS\\Model\\SiteTree'),
(100, 'SilverStripe\\Versioned\\ChangeSetItem', '2018-01-17 07:51:47', '2018-01-17 07:51:47', 2, 3, 'explicitly', 73, 19, 'SilverStripe\\CMS\\Model\\SiteTree'),
(101, 'SilverStripe\\Versioned\\ChangeSetItem', '2018-01-17 07:52:01', '2018-01-17 07:52:01', 1, 2, 'explicitly', 74, 3, 'SilverStripe\\CMS\\Model\\SiteTree'),
(102, 'SilverStripe\\Versioned\\ChangeSetItem', '2018-01-17 07:52:12', '2018-01-17 07:52:12', 5, 6, 'explicitly', 75, 1, 'SilverStripe\\CMS\\Model\\SiteTree'),
(103, 'SilverStripe\\Versioned\\ChangeSetItem', '2018-01-17 07:52:53', '2018-01-17 07:52:53', 0, 2, 'explicitly', 76, 32, 'SilverStripe\\CMS\\Model\\SiteTree'),
(104, 'SilverStripe\\Versioned\\ChangeSetItem', '2018-01-17 07:53:10', '2018-01-17 07:53:09', 2, 6, 'explicitly', 77, 31, 'SilverStripe\\CMS\\Model\\SiteTree'),
(105, 'SilverStripe\\Versioned\\ChangeSetItem', '2018-01-17 07:53:23', '2018-01-17 07:53:23', 2, 3, 'explicitly', 78, 32, 'SilverStripe\\CMS\\Model\\SiteTree'),
(106, 'SilverStripe\\Versioned\\ChangeSetItem', '2018-01-17 07:53:29', '2018-01-17 07:53:29', 3, 4, 'explicitly', 79, 32, 'SilverStripe\\CMS\\Model\\SiteTree'),
(107, 'SilverStripe\\Versioned\\ChangeSetItem', '2018-01-17 08:00:53', '2018-01-17 08:00:53', 6, 7, 'explicitly', 80, 1, 'SilverStripe\\CMS\\Model\\SiteTree'),
(108, 'SilverStripe\\Versioned\\ChangeSetItem', '2018-01-17 08:05:21', '2018-01-17 08:05:21', 2, 3, 'explicitly', 81, 2, 'SilverStripe\\CMS\\Model\\SiteTree'),
(109, 'SilverStripe\\Versioned\\ChangeSetItem', '2018-01-17 08:05:41', '2018-01-17 08:05:41', 2, 3, 'explicitly', 82, 3, 'SilverStripe\\CMS\\Model\\SiteTree'),
(110, 'SilverStripe\\Versioned\\ChangeSetItem', '2018-01-17 08:06:09', '2018-01-17 08:06:09', 3, 4, 'explicitly', 83, 19, 'SilverStripe\\CMS\\Model\\SiteTree'),
(111, 'SilverStripe\\Versioned\\ChangeSetItem', '2018-01-17 08:06:28', '2018-01-17 08:06:28', 4, 5, 'explicitly', 84, 32, 'SilverStripe\\CMS\\Model\\SiteTree'),
(112, 'SilverStripe\\Versioned\\ChangeSetItem', '2018-01-17 08:07:08', '2018-01-17 08:07:08', 3, 4, 'explicitly', 85, 3, 'SilverStripe\\CMS\\Model\\SiteTree');

-- --------------------------------------------------------

--
-- Table structure for table `ChangeSetItem_ReferencedBy`
--

CREATE TABLE `ChangeSetItem_ReferencedBy` (
  `ID` int(11) NOT NULL,
  `ChangeSetItemID` int(11) NOT NULL DEFAULT '0',
  `ChildID` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ChangeSetItem_ReferencedBy`
--

INSERT INTO `ChangeSetItem_ReferencedBy` (`ID`, `ChangeSetItemID`, `ChildID`) VALUES
(1, 4, 3),
(2, 6, 5),
(3, 8, 7),
(4, 10, 9),
(5, 12, 11),
(6, 14, 13),
(7, 16, 15),
(8, 18, 17),
(9, 20, 19),
(10, 22, 21),
(11, 24, 23),
(12, 26, 25),
(13, 28, 27),
(14, 34, 33),
(15, 36, 35),
(16, 38, 37),
(17, 40, 39),
(18, 46, 45),
(19, 48, 47),
(20, 50, 49),
(21, 52, 51),
(22, 54, 53),
(23, 56, 55),
(24, 61, 60),
(25, 63, 62),
(26, 69, 68),
(27, 87, 86);

-- --------------------------------------------------------

--
-- Table structure for table `ErrorPage`
--

CREATE TABLE `ErrorPage` (
  `ID` int(11) NOT NULL,
  `ErrorCode` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ErrorPage`
--

INSERT INTO `ErrorPage` (`ID`, `ErrorCode`) VALUES
(4, 404),
(5, 500);

-- --------------------------------------------------------

--
-- Table structure for table `ErrorPage_Live`
--

CREATE TABLE `ErrorPage_Live` (
  `ID` int(11) NOT NULL,
  `ErrorCode` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ErrorPage_Live`
--

INSERT INTO `ErrorPage_Live` (`ID`, `ErrorCode`) VALUES
(4, 404),
(5, 500);

-- --------------------------------------------------------

--
-- Table structure for table `ErrorPage_Versions`
--

CREATE TABLE `ErrorPage_Versions` (
  `ID` int(11) NOT NULL,
  `RecordID` int(11) NOT NULL DEFAULT '0',
  `Version` int(11) NOT NULL DEFAULT '0',
  `ErrorCode` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ErrorPage_Versions`
--

INSERT INTO `ErrorPage_Versions` (`ID`, `RecordID`, `Version`, `ErrorCode`) VALUES
(1, 4, 1, 404),
(2, 5, 1, 500);

-- --------------------------------------------------------

--
-- Table structure for table `File`
--

CREATE TABLE `File` (
  `ID` int(11) NOT NULL,
  `ClassName` enum('SilverStripe\\Assets\\File','SilverStripe\\Assets\\Folder','SilverStripe\\Assets\\Image') CHARACTER SET utf8 DEFAULT 'SilverStripe\\Assets\\File',
  `LastEdited` datetime DEFAULT NULL,
  `Created` datetime DEFAULT NULL,
  `Name` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `Title` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `ShowInSearch` tinyint(1) UNSIGNED NOT NULL DEFAULT '1',
  `CanViewType` enum('Anyone','LoggedInUsers','OnlyTheseUsers','Inherit') CHARACTER SET utf8 DEFAULT 'Inherit',
  `CanEditType` enum('LoggedInUsers','OnlyTheseUsers','Inherit') CHARACTER SET utf8 DEFAULT 'Inherit',
  `Version` int(11) NOT NULL DEFAULT '0',
  `ParentID` int(11) NOT NULL DEFAULT '0',
  `OwnerID` int(11) NOT NULL DEFAULT '0',
  `FileHash` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `FileFilename` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `FileVariant` varchar(255) CHARACTER SET utf8 DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `File`
--

INSERT INTO `File` (`ID`, `ClassName`, `LastEdited`, `Created`, `Name`, `Title`, `ShowInSearch`, `CanViewType`, `CanEditType`, `Version`, `ParentID`, `OwnerID`, `FileHash`, `FileFilename`, `FileVariant`) VALUES
(1, 'SilverStripe\\Assets\\Folder', '2018-01-12 06:11:00', '2018-01-12 06:11:00', 'Uploads', 'Uploads', 1, 'Inherit', 'Inherit', 1, 0, 1, NULL, NULL, NULL),
(2, 'SilverStripe\\Assets\\Image', '2018-01-12 06:15:29', '2018-01-12 06:15:27', 'small-testimonial-1.jpg', 'small testimonial 1', 1, 'Inherit', 'Inherit', 1, 1, 1, 'd473a97c0449abe0f455bb2db22f2e101850e88a', 'Uploads/small-testimonial-1.jpg', NULL),
(3, 'SilverStripe\\Assets\\Image', '2018-01-12 06:16:41', '2018-01-12 06:16:39', 'images-4.jpg', 'images 4', 1, 'Inherit', 'Inherit', 1, 1, 1, 'dcf9882aed0cee41050a800b269304396d03acd3', 'Uploads/images-4.jpg', NULL),
(4, 'SilverStripe\\Assets\\Image', '2018-01-12 06:17:23', '2018-01-12 06:17:21', 'AAEAAQAAAAAAAAfPAAAAJDI4ZGQ5MTFkLWUyNjgtNGViNS1hNjIzLTAxMTk3ZjQzNjQ2YQ.jpg', 'AAEAAQAAAAAAAAfPAAAAJDI4ZGQ5MTFkLWUyNjgtNGViNS1hNjIzLTAxMTk3ZjQzNjQ2YQ', 1, 'Inherit', 'Inherit', 1, 1, 1, '3caa1a72b5f4b1854047e4cd4b3288b469e04ba1', 'Uploads/AAEAAQAAAAAAAAfPAAAAJDI4ZGQ5MTFkLWUyNjgtNGViNS1hNjIzLTAxMTk3ZjQzNjQ2YQ.jpg', NULL),
(5, 'SilverStripe\\Assets\\Image', '2018-01-12 06:40:04', '2018-01-12 06:40:02', 'images-3.jpg', 'images 3', 1, 'Inherit', 'Inherit', 1, 1, 1, '9edeb2c107418c846eacf440acf7ba716326426c', 'Uploads/images-3.jpg', NULL),
(6, 'SilverStripe\\Assets\\Image', '2018-01-12 06:50:47', '2018-01-12 06:50:45', 'icon-cogs.png', 'icon cogs', 1, 'Inherit', 'Inherit', 1, 1, 1, '46da0f7bdab5eae2027e4155c02da5bc2f3a1447', 'Uploads/icon-cogs.png', NULL),
(7, 'SilverStripe\\Assets\\Image', '2018-01-12 06:51:58', '2018-01-12 06:51:56', 'icon-cogs-1.png', 'icon cogs 1', 1, 'Inherit', 'Inherit', 1, 1, 1, '7f81d44769c579fa24d34a3e7d9229b05c0c5991', 'Uploads/icon-cogs-1.png', NULL),
(8, 'SilverStripe\\Assets\\Image', '2018-01-12 06:52:23', '2018-01-12 06:52:21', 'icon-growth.png', 'icon growth', 1, 'Inherit', 'Inherit', 1, 1, 1, '055fded738dc908fc1c74ac3f3452a93485a54b6', 'Uploads/icon-growth.png', NULL),
(9, 'SilverStripe\\Assets\\Image', '2018-01-12 06:52:48', '2018-01-12 06:52:47', 'icon-group.png', 'icon group', 1, 'Inherit', 'Inherit', 1, 1, 1, '60f46ae370a5913bd22990dc0d15a2b1ea57d9cf', 'Uploads/icon-group.png', NULL),
(10, 'SilverStripe\\Assets\\Image', '2018-01-12 07:15:52', '2018-01-12 07:15:51', 'icon-cogs-v2.png', 'icon cogs v2', 1, 'Inherit', 'Inherit', 1, 1, 1, '46da0f7bdab5eae2027e4155c02da5bc2f3a1447', 'Uploads/icon-cogs-v2.png', NULL),
(11, 'SilverStripe\\Assets\\Image', '2018-01-12 07:16:00', '2018-01-12 07:15:58', 'icon-cogs-1-v2.png', 'icon cogs 1 v2', 1, 'Inherit', 'Inherit', 1, 1, 1, '7f81d44769c579fa24d34a3e7d9229b05c0c5991', 'Uploads/icon-cogs-1-v2.png', NULL),
(12, 'SilverStripe\\Assets\\Image', '2018-01-12 07:16:08', '2018-01-12 07:16:06', 'icon-growth-v2.png', 'icon growth v2', 1, 'Inherit', 'Inherit', 1, 1, 1, '055fded738dc908fc1c74ac3f3452a93485a54b6', 'Uploads/icon-growth-v2.png', NULL),
(13, 'SilverStripe\\Assets\\Image', '2018-01-12 07:16:14', '2018-01-12 07:16:13', 'icon-group-v2.png', 'icon group v2', 1, 'Inherit', 'Inherit', 1, 1, 1, '60f46ae370a5913bd22990dc0d15a2b1ea57d9cf', 'Uploads/icon-group-v2.png', NULL),
(14, 'SilverStripe\\Assets\\Image', '2018-01-12 07:21:06', '2018-01-12 07:21:04', 'download.jpg', 'download', 1, 'Inherit', 'Inherit', 1, 1, 1, 'ba727c2ce0a0f01ebd4d7df7e8282be59cff53f5', 'Uploads/download.jpg', NULL),
(15, 'SilverStripe\\Assets\\Image', '2018-01-12 07:21:15', '2018-01-12 07:21:13', 'AAEAAQAAAAAAAAfPAAAAJDI4ZGQ5MTFkLWUyNjgtNGViNS1hNjIzLTAxMTk3ZjQzNjQ2YQ-v2.jpg', 'AAEAAQAAAAAAAAfPAAAAJDI4ZGQ5MTFkLWUyNjgtNGViNS1hNjIzLTAxMTk3ZjQzNjQ2YQ v2', 1, 'Inherit', 'Inherit', 1, 1, 1, '3caa1a72b5f4b1854047e4cd4b3288b469e04ba1', 'Uploads/AAEAAQAAAAAAAAfPAAAAJDI4ZGQ5MTFkLWUyNjgtNGViNS1hNjIzLTAxMTk3ZjQzNjQ2YQ-v2.jpg', NULL),
(16, 'SilverStripe\\Assets\\Image', '2018-01-12 07:21:24', '2018-01-12 07:21:23', 'images.jpg', 'images', 1, 'Inherit', 'Inherit', 1, 1, 1, 'c2b6992b810dd63659cb959ae5ed6ed29ecd4980', 'Uploads/images.jpg', NULL),
(17, 'SilverStripe\\Assets\\Image', '2018-01-12 07:21:34', '2018-01-12 07:21:32', 'images-3-v2.jpg', 'images 3 v2', 1, 'Inherit', 'Inherit', 1, 1, 1, '9edeb2c107418c846eacf440acf7ba716326426c', 'Uploads/images-3-v2.jpg', NULL),
(18, 'SilverStripe\\Assets\\Image', '2018-01-12 07:23:51', '2018-01-12 07:23:49', 'banner.jpg', 'banner', 1, 'Inherit', 'Inherit', 1, 1, 1, 'b2b64424b6e474a3753fb4ef5f3ca3069d246bed', 'Uploads/banner.jpg', NULL),
(19, 'SilverStripe\\Assets\\Image', '2018-01-12 07:24:21', '2018-01-12 07:24:19', 'banner-v2.jpg', 'banner v2', 1, 'Inherit', 'Inherit', 1, 1, 1, 'b2b64424b6e474a3753fb4ef5f3ca3069d246bed', 'Uploads/banner-v2.jpg', NULL),
(20, 'SilverStripe\\Assets\\Folder', '2018-01-16 09:50:53', '2018-01-16 09:50:53', 'Blog', 'Blog', 1, 'Inherit', 'Inherit', 1, 0, 1, NULL, NULL, NULL),
(21, 'SilverStripe\\Assets\\Image', '2018-01-16 09:51:24', '2018-01-16 09:51:02', 'SilverStripe-Settings.png', 'SilverStripe Settings', 1, 'Inherit', 'Inherit', 1, 20, 1, '372821b3acb89efeb2df42a7eca7aaeb65d79629', 'Blog/SilverStripe-Settings.png', NULL),
(22, 'SilverStripe\\Assets\\Image', '2018-01-16 14:20:29', '2018-01-16 14:20:27', 'boxes.jpg', 'boxes', 1, 'Inherit', 'Inherit', 1, 1, 1, 'b837eda379fec883f5519dd53cd4c323e6e29c8d', 'Uploads/boxes.jpg', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `File_EditorGroups`
--

CREATE TABLE `File_EditorGroups` (
  `ID` int(11) NOT NULL,
  `FileID` int(11) NOT NULL DEFAULT '0',
  `GroupID` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `File_Live`
--

CREATE TABLE `File_Live` (
  `ID` int(11) NOT NULL,
  `ClassName` enum('SilverStripe\\Assets\\File','SilverStripe\\Assets\\Folder','SilverStripe\\Assets\\Image') CHARACTER SET utf8 DEFAULT 'SilverStripe\\Assets\\File',
  `LastEdited` datetime DEFAULT NULL,
  `Created` datetime DEFAULT NULL,
  `Name` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `Title` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `ShowInSearch` tinyint(1) UNSIGNED NOT NULL DEFAULT '1',
  `CanViewType` enum('Anyone','LoggedInUsers','OnlyTheseUsers','Inherit') CHARACTER SET utf8 DEFAULT 'Inherit',
  `CanEditType` enum('LoggedInUsers','OnlyTheseUsers','Inherit') CHARACTER SET utf8 DEFAULT 'Inherit',
  `Version` int(11) NOT NULL DEFAULT '0',
  `ParentID` int(11) NOT NULL DEFAULT '0',
  `OwnerID` int(11) NOT NULL DEFAULT '0',
  `FileHash` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `FileFilename` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `FileVariant` varchar(255) CHARACTER SET utf8 DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `File_Live`
--

INSERT INTO `File_Live` (`ID`, `ClassName`, `LastEdited`, `Created`, `Name`, `Title`, `ShowInSearch`, `CanViewType`, `CanEditType`, `Version`, `ParentID`, `OwnerID`, `FileHash`, `FileFilename`, `FileVariant`) VALUES
(1, 'SilverStripe\\Assets\\Folder', '2018-01-12 06:11:00', '2018-01-12 06:11:00', 'Uploads', 'Uploads', 1, 'Inherit', 'Inherit', 1, 0, 1, NULL, NULL, NULL),
(2, 'SilverStripe\\Assets\\Image', '2018-01-12 06:15:29', '2018-01-12 06:15:27', 'small-testimonial-1.jpg', 'small testimonial 1', 1, 'Inherit', 'Inherit', 1, 1, 1, 'd473a97c0449abe0f455bb2db22f2e101850e88a', 'Uploads/small-testimonial-1.jpg', NULL),
(3, 'SilverStripe\\Assets\\Image', '2018-01-12 06:16:41', '2018-01-12 06:16:39', 'images-4.jpg', 'images 4', 1, 'Inherit', 'Inherit', 1, 1, 1, 'dcf9882aed0cee41050a800b269304396d03acd3', 'Uploads/images-4.jpg', NULL),
(4, 'SilverStripe\\Assets\\Image', '2018-01-12 06:17:23', '2018-01-12 06:17:21', 'AAEAAQAAAAAAAAfPAAAAJDI4ZGQ5MTFkLWUyNjgtNGViNS1hNjIzLTAxMTk3ZjQzNjQ2YQ.jpg', 'AAEAAQAAAAAAAAfPAAAAJDI4ZGQ5MTFkLWUyNjgtNGViNS1hNjIzLTAxMTk3ZjQzNjQ2YQ', 1, 'Inherit', 'Inherit', 1, 1, 1, '3caa1a72b5f4b1854047e4cd4b3288b469e04ba1', 'Uploads/AAEAAQAAAAAAAAfPAAAAJDI4ZGQ5MTFkLWUyNjgtNGViNS1hNjIzLTAxMTk3ZjQzNjQ2YQ.jpg', NULL),
(5, 'SilverStripe\\Assets\\Image', '2018-01-12 06:40:04', '2018-01-12 06:40:02', 'images-3.jpg', 'images 3', 1, 'Inherit', 'Inherit', 1, 1, 1, '9edeb2c107418c846eacf440acf7ba716326426c', 'Uploads/images-3.jpg', NULL),
(6, 'SilverStripe\\Assets\\Image', '2018-01-12 06:50:47', '2018-01-12 06:50:45', 'icon-cogs.png', 'icon cogs', 1, 'Inherit', 'Inherit', 1, 1, 1, '46da0f7bdab5eae2027e4155c02da5bc2f3a1447', 'Uploads/icon-cogs.png', NULL),
(7, 'SilverStripe\\Assets\\Image', '2018-01-12 06:51:58', '2018-01-12 06:51:56', 'icon-cogs-1.png', 'icon cogs 1', 1, 'Inherit', 'Inherit', 1, 1, 1, '7f81d44769c579fa24d34a3e7d9229b05c0c5991', 'Uploads/icon-cogs-1.png', NULL),
(8, 'SilverStripe\\Assets\\Image', '2018-01-12 06:52:23', '2018-01-12 06:52:21', 'icon-growth.png', 'icon growth', 1, 'Inherit', 'Inherit', 1, 1, 1, '055fded738dc908fc1c74ac3f3452a93485a54b6', 'Uploads/icon-growth.png', NULL),
(9, 'SilverStripe\\Assets\\Image', '2018-01-12 06:52:48', '2018-01-12 06:52:47', 'icon-group.png', 'icon group', 1, 'Inherit', 'Inherit', 1, 1, 1, '60f46ae370a5913bd22990dc0d15a2b1ea57d9cf', 'Uploads/icon-group.png', NULL),
(10, 'SilverStripe\\Assets\\Image', '2018-01-12 07:15:52', '2018-01-12 07:15:51', 'icon-cogs-v2.png', 'icon cogs v2', 1, 'Inherit', 'Inherit', 1, 1, 1, '46da0f7bdab5eae2027e4155c02da5bc2f3a1447', 'Uploads/icon-cogs-v2.png', NULL),
(11, 'SilverStripe\\Assets\\Image', '2018-01-12 07:16:00', '2018-01-12 07:15:58', 'icon-cogs-1-v2.png', 'icon cogs 1 v2', 1, 'Inherit', 'Inherit', 1, 1, 1, '7f81d44769c579fa24d34a3e7d9229b05c0c5991', 'Uploads/icon-cogs-1-v2.png', NULL),
(12, 'SilverStripe\\Assets\\Image', '2018-01-12 07:16:08', '2018-01-12 07:16:06', 'icon-growth-v2.png', 'icon growth v2', 1, 'Inherit', 'Inherit', 1, 1, 1, '055fded738dc908fc1c74ac3f3452a93485a54b6', 'Uploads/icon-growth-v2.png', NULL),
(13, 'SilverStripe\\Assets\\Image', '2018-01-12 07:16:14', '2018-01-12 07:16:13', 'icon-group-v2.png', 'icon group v2', 1, 'Inherit', 'Inherit', 1, 1, 1, '60f46ae370a5913bd22990dc0d15a2b1ea57d9cf', 'Uploads/icon-group-v2.png', NULL),
(14, 'SilverStripe\\Assets\\Image', '2018-01-12 07:21:06', '2018-01-12 07:21:04', 'download.jpg', 'download', 1, 'Inherit', 'Inherit', 1, 1, 1, 'ba727c2ce0a0f01ebd4d7df7e8282be59cff53f5', 'Uploads/download.jpg', NULL),
(15, 'SilverStripe\\Assets\\Image', '2018-01-12 07:21:15', '2018-01-12 07:21:13', 'AAEAAQAAAAAAAAfPAAAAJDI4ZGQ5MTFkLWUyNjgtNGViNS1hNjIzLTAxMTk3ZjQzNjQ2YQ-v2.jpg', 'AAEAAQAAAAAAAAfPAAAAJDI4ZGQ5MTFkLWUyNjgtNGViNS1hNjIzLTAxMTk3ZjQzNjQ2YQ v2', 1, 'Inherit', 'Inherit', 1, 1, 1, '3caa1a72b5f4b1854047e4cd4b3288b469e04ba1', 'Uploads/AAEAAQAAAAAAAAfPAAAAJDI4ZGQ5MTFkLWUyNjgtNGViNS1hNjIzLTAxMTk3ZjQzNjQ2YQ-v2.jpg', NULL),
(16, 'SilverStripe\\Assets\\Image', '2018-01-12 07:21:24', '2018-01-12 07:21:23', 'images.jpg', 'images', 1, 'Inherit', 'Inherit', 1, 1, 1, 'c2b6992b810dd63659cb959ae5ed6ed29ecd4980', 'Uploads/images.jpg', NULL),
(17, 'SilverStripe\\Assets\\Image', '2018-01-12 07:21:34', '2018-01-12 07:21:32', 'images-3-v2.jpg', 'images 3 v2', 1, 'Inherit', 'Inherit', 1, 1, 1, '9edeb2c107418c846eacf440acf7ba716326426c', 'Uploads/images-3-v2.jpg', NULL),
(18, 'SilverStripe\\Assets\\Image', '2018-01-12 07:23:51', '2018-01-12 07:23:49', 'banner.jpg', 'banner', 1, 'Inherit', 'Inherit', 1, 1, 1, 'b2b64424b6e474a3753fb4ef5f3ca3069d246bed', 'Uploads/banner.jpg', NULL),
(19, 'SilverStripe\\Assets\\Image', '2018-01-12 07:24:21', '2018-01-12 07:24:19', 'banner-v2.jpg', 'banner v2', 1, 'Inherit', 'Inherit', 1, 1, 1, 'b2b64424b6e474a3753fb4ef5f3ca3069d246bed', 'Uploads/banner-v2.jpg', NULL),
(20, 'SilverStripe\\Assets\\Folder', '2018-01-16 09:50:53', '2018-01-16 09:50:53', 'Blog', 'Blog', 1, 'Inherit', 'Inherit', 1, 0, 1, NULL, NULL, NULL),
(21, 'SilverStripe\\Assets\\Image', '2018-01-16 09:51:24', '2018-01-16 09:51:02', 'SilverStripe-Settings.png', 'SilverStripe Settings', 1, 'Inherit', 'Inherit', 1, 20, 1, '372821b3acb89efeb2df42a7eca7aaeb65d79629', 'Blog/SilverStripe-Settings.png', NULL),
(22, 'SilverStripe\\Assets\\Image', '2018-01-16 14:20:29', '2018-01-16 14:20:27', 'boxes.jpg', 'boxes', 1, 'Inherit', 'Inherit', 1, 1, 1, 'b837eda379fec883f5519dd53cd4c323e6e29c8d', 'Uploads/boxes.jpg', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `File_Versions`
--

CREATE TABLE `File_Versions` (
  `ID` int(11) NOT NULL,
  `RecordID` int(11) NOT NULL DEFAULT '0',
  `Version` int(11) NOT NULL DEFAULT '0',
  `WasPublished` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `AuthorID` int(11) NOT NULL DEFAULT '0',
  `PublisherID` int(11) NOT NULL DEFAULT '0',
  `ClassName` enum('SilverStripe\\Assets\\File','SilverStripe\\Assets\\Folder','SilverStripe\\Assets\\Image') CHARACTER SET utf8 DEFAULT 'SilverStripe\\Assets\\File',
  `LastEdited` datetime DEFAULT NULL,
  `Created` datetime DEFAULT NULL,
  `Name` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `Title` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `ShowInSearch` tinyint(1) UNSIGNED NOT NULL DEFAULT '1',
  `CanViewType` enum('Anyone','LoggedInUsers','OnlyTheseUsers','Inherit') CHARACTER SET utf8 DEFAULT 'Inherit',
  `CanEditType` enum('LoggedInUsers','OnlyTheseUsers','Inherit') CHARACTER SET utf8 DEFAULT 'Inherit',
  `ParentID` int(11) NOT NULL DEFAULT '0',
  `OwnerID` int(11) NOT NULL DEFAULT '0',
  `FileHash` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `FileFilename` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `FileVariant` varchar(255) CHARACTER SET utf8 DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `File_Versions`
--

INSERT INTO `File_Versions` (`ID`, `RecordID`, `Version`, `WasPublished`, `AuthorID`, `PublisherID`, `ClassName`, `LastEdited`, `Created`, `Name`, `Title`, `ShowInSearch`, `CanViewType`, `CanEditType`, `ParentID`, `OwnerID`, `FileHash`, `FileFilename`, `FileVariant`) VALUES
(1, 1, 1, 1, 1, 1, 'SilverStripe\\Assets\\Folder', '2018-01-12 06:11:00', '2018-01-12 06:11:00', 'Uploads', 'Uploads', 1, 'Inherit', 'Inherit', 0, 1, NULL, NULL, NULL),
(2, 2, 1, 1, 1, 1, 'SilverStripe\\Assets\\Image', '2018-01-12 06:15:27', '2018-01-12 06:15:27', 'small-testimonial-1.jpg', 'small testimonial 1', 1, 'Inherit', 'Inherit', 1, 1, 'd473a97c0449abe0f455bb2db22f2e101850e88a', 'Uploads/small-testimonial-1.jpg', NULL),
(3, 3, 1, 1, 1, 1, 'SilverStripe\\Assets\\Image', '2018-01-12 06:16:39', '2018-01-12 06:16:39', 'images-4.jpg', 'images 4', 1, 'Inherit', 'Inherit', 1, 1, 'dcf9882aed0cee41050a800b269304396d03acd3', 'Uploads/images-4.jpg', NULL),
(4, 4, 1, 1, 1, 1, 'SilverStripe\\Assets\\Image', '2018-01-12 06:17:21', '2018-01-12 06:17:21', 'AAEAAQAAAAAAAAfPAAAAJDI4ZGQ5MTFkLWUyNjgtNGViNS1hNjIzLTAxMTk3ZjQzNjQ2YQ.jpg', 'AAEAAQAAAAAAAAfPAAAAJDI4ZGQ5MTFkLWUyNjgtNGViNS1hNjIzLTAxMTk3ZjQzNjQ2YQ', 1, 'Inherit', 'Inherit', 1, 1, '3caa1a72b5f4b1854047e4cd4b3288b469e04ba1', 'Uploads/AAEAAQAAAAAAAAfPAAAAJDI4ZGQ5MTFkLWUyNjgtNGViNS1hNjIzLTAxMTk3ZjQzNjQ2YQ.jpg', NULL),
(5, 5, 1, 1, 1, 1, 'SilverStripe\\Assets\\Image', '2018-01-12 06:40:02', '2018-01-12 06:40:02', 'images-3.jpg', 'images 3', 1, 'Inherit', 'Inherit', 1, 1, '9edeb2c107418c846eacf440acf7ba716326426c', 'Uploads/images-3.jpg', NULL),
(6, 6, 1, 1, 1, 1, 'SilverStripe\\Assets\\Image', '2018-01-12 06:50:45', '2018-01-12 06:50:45', 'icon-cogs.png', 'icon cogs', 1, 'Inherit', 'Inherit', 1, 1, '46da0f7bdab5eae2027e4155c02da5bc2f3a1447', 'Uploads/icon-cogs.png', NULL),
(7, 7, 1, 1, 1, 1, 'SilverStripe\\Assets\\Image', '2018-01-12 06:51:56', '2018-01-12 06:51:56', 'icon-cogs-1.png', 'icon cogs 1', 1, 'Inherit', 'Inherit', 1, 1, '7f81d44769c579fa24d34a3e7d9229b05c0c5991', 'Uploads/icon-cogs-1.png', NULL),
(8, 8, 1, 1, 1, 1, 'SilverStripe\\Assets\\Image', '2018-01-12 06:52:21', '2018-01-12 06:52:21', 'icon-growth.png', 'icon growth', 1, 'Inherit', 'Inherit', 1, 1, '055fded738dc908fc1c74ac3f3452a93485a54b6', 'Uploads/icon-growth.png', NULL),
(9, 9, 1, 1, 1, 1, 'SilverStripe\\Assets\\Image', '2018-01-12 06:52:47', '2018-01-12 06:52:47', 'icon-group.png', 'icon group', 1, 'Inherit', 'Inherit', 1, 1, '60f46ae370a5913bd22990dc0d15a2b1ea57d9cf', 'Uploads/icon-group.png', NULL),
(10, 10, 1, 1, 1, 1, 'SilverStripe\\Assets\\Image', '2018-01-12 07:15:51', '2018-01-12 07:15:51', 'icon-cogs-v2.png', 'icon cogs v2', 1, 'Inherit', 'Inherit', 1, 1, '46da0f7bdab5eae2027e4155c02da5bc2f3a1447', 'Uploads/icon-cogs-v2.png', NULL),
(11, 11, 1, 1, 1, 1, 'SilverStripe\\Assets\\Image', '2018-01-12 07:15:58', '2018-01-12 07:15:58', 'icon-cogs-1-v2.png', 'icon cogs 1 v2', 1, 'Inherit', 'Inherit', 1, 1, '7f81d44769c579fa24d34a3e7d9229b05c0c5991', 'Uploads/icon-cogs-1-v2.png', NULL),
(12, 12, 1, 1, 1, 1, 'SilverStripe\\Assets\\Image', '2018-01-12 07:16:06', '2018-01-12 07:16:06', 'icon-growth-v2.png', 'icon growth v2', 1, 'Inherit', 'Inherit', 1, 1, '055fded738dc908fc1c74ac3f3452a93485a54b6', 'Uploads/icon-growth-v2.png', NULL),
(13, 13, 1, 1, 1, 1, 'SilverStripe\\Assets\\Image', '2018-01-12 07:16:13', '2018-01-12 07:16:13', 'icon-group-v2.png', 'icon group v2', 1, 'Inherit', 'Inherit', 1, 1, '60f46ae370a5913bd22990dc0d15a2b1ea57d9cf', 'Uploads/icon-group-v2.png', NULL),
(14, 14, 1, 1, 1, 1, 'SilverStripe\\Assets\\Image', '2018-01-12 07:21:04', '2018-01-12 07:21:04', 'download.jpg', 'download', 1, 'Inherit', 'Inherit', 1, 1, 'ba727c2ce0a0f01ebd4d7df7e8282be59cff53f5', 'Uploads/download.jpg', NULL),
(15, 15, 1, 1, 1, 1, 'SilverStripe\\Assets\\Image', '2018-01-12 07:21:13', '2018-01-12 07:21:13', 'AAEAAQAAAAAAAAfPAAAAJDI4ZGQ5MTFkLWUyNjgtNGViNS1hNjIzLTAxMTk3ZjQzNjQ2YQ-v2.jpg', 'AAEAAQAAAAAAAAfPAAAAJDI4ZGQ5MTFkLWUyNjgtNGViNS1hNjIzLTAxMTk3ZjQzNjQ2YQ v2', 1, 'Inherit', 'Inherit', 1, 1, '3caa1a72b5f4b1854047e4cd4b3288b469e04ba1', 'Uploads/AAEAAQAAAAAAAAfPAAAAJDI4ZGQ5MTFkLWUyNjgtNGViNS1hNjIzLTAxMTk3ZjQzNjQ2YQ-v2.jpg', NULL),
(16, 16, 1, 1, 1, 1, 'SilverStripe\\Assets\\Image', '2018-01-12 07:21:23', '2018-01-12 07:21:23', 'images.jpg', 'images', 1, 'Inherit', 'Inherit', 1, 1, 'c2b6992b810dd63659cb959ae5ed6ed29ecd4980', 'Uploads/images.jpg', NULL),
(17, 17, 1, 1, 1, 1, 'SilverStripe\\Assets\\Image', '2018-01-12 07:21:32', '2018-01-12 07:21:32', 'images-3-v2.jpg', 'images 3 v2', 1, 'Inherit', 'Inherit', 1, 1, '9edeb2c107418c846eacf440acf7ba716326426c', 'Uploads/images-3-v2.jpg', NULL),
(18, 18, 1, 1, 1, 1, 'SilverStripe\\Assets\\Image', '2018-01-12 07:23:49', '2018-01-12 07:23:49', 'banner.jpg', 'banner', 1, 'Inherit', 'Inherit', 1, 1, 'b2b64424b6e474a3753fb4ef5f3ca3069d246bed', 'Uploads/banner.jpg', NULL),
(19, 19, 1, 1, 1, 1, 'SilverStripe\\Assets\\Image', '2018-01-12 07:24:19', '2018-01-12 07:24:19', 'banner-v2.jpg', 'banner v2', 1, 'Inherit', 'Inherit', 1, 1, 'b2b64424b6e474a3753fb4ef5f3ca3069d246bed', 'Uploads/banner-v2.jpg', NULL),
(20, 20, 1, 1, 1, 1, 'SilverStripe\\Assets\\Folder', '2018-01-16 09:50:53', '2018-01-16 09:50:53', 'Blog', 'Blog', 1, 'Inherit', 'Inherit', 0, 1, NULL, NULL, NULL),
(21, 21, 1, 1, 1, 1, 'SilverStripe\\Assets\\Image', '2018-01-16 09:51:02', '2018-01-16 09:51:02', 'SilverStripe-Settings.png', 'SilverStripe Settings', 1, 'Inherit', 'Inherit', 20, 1, '372821b3acb89efeb2df42a7eca7aaeb65d79629', 'Blog/SilverStripe-Settings.png', NULL),
(22, 22, 1, 1, 1, 1, 'SilverStripe\\Assets\\Image', '2018-01-16 14:20:27', '2018-01-16 14:20:27', 'boxes.jpg', 'boxes', 1, 'Inherit', 'Inherit', 1, 1, 'b837eda379fec883f5519dd53cd4c323e6e29c8d', 'Uploads/boxes.jpg', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `File_ViewerGroups`
--

CREATE TABLE `File_ViewerGroups` (
  `ID` int(11) NOT NULL,
  `FileID` int(11) NOT NULL DEFAULT '0',
  `GroupID` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `Group`
--

CREATE TABLE `Group` (
  `ID` int(11) NOT NULL,
  `ClassName` enum('SilverStripe\\Security\\Group') CHARACTER SET utf8 DEFAULT 'SilverStripe\\Security\\Group',
  `LastEdited` datetime DEFAULT NULL,
  `Created` datetime DEFAULT NULL,
  `Title` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `Description` mediumtext CHARACTER SET utf8,
  `Code` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `Locked` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `Sort` int(11) NOT NULL DEFAULT '0',
  `HtmlEditorConfig` mediumtext CHARACTER SET utf8,
  `ParentID` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Group`
--

INSERT INTO `Group` (`ID`, `ClassName`, `LastEdited`, `Created`, `Title`, `Description`, `Code`, `Locked`, `Sort`, `HtmlEditorConfig`, `ParentID`) VALUES
(1, 'SilverStripe\\Security\\Group', '2018-01-12 05:56:10', '2018-01-12 05:56:10', 'Content Authors', NULL, 'content-authors', 0, 1, NULL, 0),
(2, 'SilverStripe\\Security\\Group', '2018-01-12 05:56:10', '2018-01-12 05:56:10', 'Administrators', NULL, 'administrators', 0, 0, NULL, 0);

-- --------------------------------------------------------

--
-- Table structure for table `Group_Members`
--

CREATE TABLE `Group_Members` (
  `ID` int(11) NOT NULL,
  `GroupID` int(11) NOT NULL DEFAULT '0',
  `MemberID` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Group_Members`
--

INSERT INTO `Group_Members` (`ID`, `GroupID`, `MemberID`) VALUES
(1, 2, 1);

-- --------------------------------------------------------

--
-- Table structure for table `Group_Roles`
--

CREATE TABLE `Group_Roles` (
  `ID` int(11) NOT NULL,
  `GroupID` int(11) NOT NULL DEFAULT '0',
  `PermissionRoleID` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `homepageboxes`
--

CREATE TABLE `homepageboxes` (
  `ID` int(11) NOT NULL,
  `PhotoID` int(11) NOT NULL DEFAULT '0',
  `read_moreID` int(11) NOT NULL DEFAULT '0',
  `css_classID` int(11) NOT NULL DEFAULT '0',
  `read_more` mediumtext CHARACTER SET utf8,
  `css_class` mediumtext CHARACTER SET utf8
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `homepageboxes`
--

INSERT INTO `homepageboxes` (`ID`, `PhotoID`, `read_moreID`, `css_classID`, `read_more`, `css_class`) VALUES
(24, 0, 0, 0, 'http://localhost/paduafinancialgroup.com.au', 'bg-grey'),
(25, 0, 0, 0, 'http://localhost/paduafinancialgroup.com.au/admin', 'bg-light-sky'),
(26, 22, 0, 0, NULL, NULL),
(27, 0, 0, 0, 'http://localhost/paduafinancialgroup.com.au/', 'bg-grey-50');

-- --------------------------------------------------------

--
-- Table structure for table `homepageboxes_Live`
--

CREATE TABLE `homepageboxes_Live` (
  `ID` int(11) NOT NULL,
  `PhotoID` int(11) NOT NULL DEFAULT '0',
  `read_moreID` int(11) NOT NULL DEFAULT '0',
  `css_classID` int(11) NOT NULL DEFAULT '0',
  `read_more` mediumtext CHARACTER SET utf8,
  `css_class` mediumtext CHARACTER SET utf8
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `homepageboxes_Live`
--

INSERT INTO `homepageboxes_Live` (`ID`, `PhotoID`, `read_moreID`, `css_classID`, `read_more`, `css_class`) VALUES
(24, 0, 0, 0, 'http://localhost/paduafinancialgroup.com.au', 'bg-grey'),
(25, 0, 0, 0, 'http://localhost/paduafinancialgroup.com.au/admin', 'bg-light-sky'),
(26, 22, 0, 0, NULL, NULL),
(27, 0, 0, 0, 'http://localhost/paduafinancialgroup.com.au/', 'bg-grey-50');

-- --------------------------------------------------------

--
-- Table structure for table `homepageboxes_Versions`
--

CREATE TABLE `homepageboxes_Versions` (
  `ID` int(11) NOT NULL,
  `RecordID` int(11) NOT NULL DEFAULT '0',
  `Version` int(11) NOT NULL DEFAULT '0',
  `PhotoID` int(11) NOT NULL DEFAULT '0',
  `read_moreID` int(11) NOT NULL DEFAULT '0',
  `css_classID` int(11) NOT NULL DEFAULT '0',
  `read_more` mediumtext CHARACTER SET utf8,
  `css_class` mediumtext CHARACTER SET utf8
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `homepageboxes_Versions`
--

INSERT INTO `homepageboxes_Versions` (`ID`, `RecordID`, `Version`, `PhotoID`, `read_moreID`, `css_classID`, `read_more`, `css_class`) VALUES
(1, 24, 1, 0, 0, 0, NULL, NULL),
(2, 24, 2, 0, 0, 0, NULL, NULL),
(3, 25, 1, 0, 0, 0, NULL, NULL),
(4, 25, 2, 0, 0, 0, NULL, NULL),
(5, 24, 3, 0, 0, 0, NULL, NULL),
(6, 24, 4, 0, 0, 0, 'http://localhost/paduafinancialgroup.com.au', 'grey'),
(7, 25, 3, 0, 0, 0, 'http://localhost/paduafinancialgroup.com.au/admin', 'brown'),
(8, 25, 4, 0, 0, 0, 'http://localhost/paduafinancialgroup.com.au/admin', 'sky-blue'),
(9, 26, 1, 0, 0, 0, NULL, NULL),
(10, 26, 2, 22, 0, 0, NULL, NULL),
(11, 27, 1, 0, 0, 0, NULL, NULL),
(12, 27, 2, 0, 0, 0, 'http://localhost/paduafinancialgroup.com.au/', 'brown'),
(13, 24, 5, 0, 0, 0, 'http://localhost/paduafinancialgroup.com.au', 'bg-grey'),
(14, 25, 5, 0, 0, 0, 'http://localhost/paduafinancialgroup.com.au/admin', 'bg-light-sky'),
(15, 27, 3, 0, 0, 0, 'http://localhost/paduafinancialgroup.com.au/', 'bg-grey-50');

-- --------------------------------------------------------

--
-- Table structure for table `LoginAttempt`
--

CREATE TABLE `LoginAttempt` (
  `ID` int(11) NOT NULL,
  `ClassName` enum('SilverStripe\\Security\\LoginAttempt') CHARACTER SET utf8 DEFAULT 'SilverStripe\\Security\\LoginAttempt',
  `LastEdited` datetime DEFAULT NULL,
  `Created` datetime DEFAULT NULL,
  `Email` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `EmailHashed` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `Status` enum('Success','Failure') CHARACTER SET utf8 DEFAULT 'Success',
  `IP` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `MemberID` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `Member`
--

CREATE TABLE `Member` (
  `ID` int(11) NOT NULL,
  `ClassName` enum('SilverStripe\\Security\\Member') CHARACTER SET utf8 DEFAULT 'SilverStripe\\Security\\Member',
  `LastEdited` datetime DEFAULT NULL,
  `Created` datetime DEFAULT NULL,
  `FirstName` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `Surname` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `Email` varchar(254) CHARACTER SET utf8 DEFAULT NULL,
  `TempIDHash` varchar(160) CHARACTER SET utf8 DEFAULT NULL,
  `TempIDExpired` datetime DEFAULT NULL,
  `Password` varchar(160) CHARACTER SET utf8 DEFAULT NULL,
  `AutoLoginHash` varchar(160) CHARACTER SET utf8 DEFAULT NULL,
  `AutoLoginExpired` datetime DEFAULT NULL,
  `PasswordEncryption` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `Salt` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `PasswordExpiry` date DEFAULT NULL,
  `LockedOutUntil` datetime DEFAULT NULL,
  `Locale` varchar(6) CHARACTER SET utf8 DEFAULT NULL,
  `FailedLoginCount` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Member`
--

INSERT INTO `Member` (`ID`, `ClassName`, `LastEdited`, `Created`, `FirstName`, `Surname`, `Email`, `TempIDHash`, `TempIDExpired`, `Password`, `AutoLoginHash`, `AutoLoginExpired`, `PasswordEncryption`, `Salt`, `PasswordExpiry`, `LockedOutUntil`, `Locale`, `FailedLoginCount`) VALUES
(1, 'SilverStripe\\Security\\Member', '2018-01-17 07:58:53', '2018-01-12 05:56:11', 'Default Admin', NULL, 'admin', 'b75931ebe0aba5d47c7e84f28c6e5b0de7b29589', '2018-01-20 07:58:53', '$2y$10$3b5339d69d458bbd04e62OjWMbF304oUvWixW/eMjex6HOwCJjlfO', NULL, NULL, 'blowfish', '10$3b5339d69d458bbd04e62d', NULL, NULL, 'en_US', 0);

-- --------------------------------------------------------

--
-- Table structure for table `MemberPassword`
--

CREATE TABLE `MemberPassword` (
  `ID` int(11) NOT NULL,
  `ClassName` enum('SilverStripe\\Security\\MemberPassword') CHARACTER SET utf8 DEFAULT 'SilverStripe\\Security\\MemberPassword',
  `LastEdited` datetime DEFAULT NULL,
  `Created` datetime DEFAULT NULL,
  `Password` varchar(160) CHARACTER SET utf8 DEFAULT NULL,
  `Salt` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `PasswordEncryption` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `MemberID` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `MemberPassword`
--

INSERT INTO `MemberPassword` (`ID`, `ClassName`, `LastEdited`, `Created`, `Password`, `Salt`, `PasswordEncryption`, `MemberID`) VALUES
(1, 'SilverStripe\\Security\\MemberPassword', '2018-01-12 05:56:11', '2018-01-12 05:56:11', '$2y$10$3b5339d69d458bbd04e62OjWMbF304oUvWixW/eMjex6HOwCJjlfO', '10$3b5339d69d458bbd04e62d', 'blowfish', 1);

-- --------------------------------------------------------

--
-- Table structure for table `Page`
--

CREATE TABLE `Page` (
  `ID` int(11) NOT NULL,
  `quicklinks` tinyint(1) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Page`
--

INSERT INTO `Page` (`ID`, `quicklinks`) VALUES
(1, 1),
(2, 1),
(3, 1),
(19, 1),
(32, 1);

-- --------------------------------------------------------

--
-- Table structure for table `Page_Live`
--

CREATE TABLE `Page_Live` (
  `ID` int(11) NOT NULL,
  `quicklinks` tinyint(1) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Page_Live`
--

INSERT INTO `Page_Live` (`ID`, `quicklinks`) VALUES
(1, 1),
(2, 1),
(3, 1),
(19, 1),
(32, 1);

-- --------------------------------------------------------

--
-- Table structure for table `Page_Versions`
--

CREATE TABLE `Page_Versions` (
  `ID` int(11) NOT NULL,
  `RecordID` int(11) NOT NULL DEFAULT '0',
  `Version` int(11) NOT NULL DEFAULT '0',
  `quicklinks` tinyint(1) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Page_Versions`
--

INSERT INTO `Page_Versions` (`ID`, `RecordID`, `Version`, `quicklinks`) VALUES
(1, 1, 7, 1),
(2, 2, 3, 1),
(3, 3, 3, 1),
(4, 19, 4, 1),
(5, 32, 5, 1),
(6, 3, 4, 1);

-- --------------------------------------------------------

--
-- Table structure for table `Permission`
--

CREATE TABLE `Permission` (
  `ID` int(11) NOT NULL,
  `ClassName` enum('SilverStripe\\Security\\Permission') CHARACTER SET utf8 DEFAULT 'SilverStripe\\Security\\Permission',
  `LastEdited` datetime DEFAULT NULL,
  `Created` datetime DEFAULT NULL,
  `Code` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `Arg` int(11) NOT NULL DEFAULT '0',
  `Type` int(11) NOT NULL DEFAULT '1',
  `GroupID` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Permission`
--

INSERT INTO `Permission` (`ID`, `ClassName`, `LastEdited`, `Created`, `Code`, `Arg`, `Type`, `GroupID`) VALUES
(1, 'SilverStripe\\Security\\Permission', '2018-01-12 05:56:10', '2018-01-12 05:56:10', 'CMS_ACCESS_CMSMain', 0, 1, 1),
(2, 'SilverStripe\\Security\\Permission', '2018-01-12 05:56:10', '2018-01-12 05:56:10', 'CMS_ACCESS_AssetAdmin', 0, 1, 1),
(3, 'SilverStripe\\Security\\Permission', '2018-01-12 05:56:10', '2018-01-12 05:56:10', 'CMS_ACCESS_ReportAdmin', 0, 1, 1),
(4, 'SilverStripe\\Security\\Permission', '2018-01-12 05:56:10', '2018-01-12 05:56:10', 'SITETREE_REORGANISE', 0, 1, 1),
(5, 'SilverStripe\\Security\\Permission', '2018-01-12 05:56:10', '2018-01-12 05:56:10', 'ADMIN', 0, 1, 2);

-- --------------------------------------------------------

--
-- Table structure for table `PermissionRole`
--

CREATE TABLE `PermissionRole` (
  `ID` int(11) NOT NULL,
  `ClassName` enum('SilverStripe\\Security\\PermissionRole') CHARACTER SET utf8 DEFAULT 'SilverStripe\\Security\\PermissionRole',
  `LastEdited` datetime DEFAULT NULL,
  `Created` datetime DEFAULT NULL,
  `Title` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `OnlyAdminCanApply` tinyint(1) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `PermissionRoleCode`
--

CREATE TABLE `PermissionRoleCode` (
  `ID` int(11) NOT NULL,
  `ClassName` enum('SilverStripe\\Security\\PermissionRoleCode') CHARACTER SET utf8 DEFAULT 'SilverStripe\\Security\\PermissionRoleCode',
  `LastEdited` datetime DEFAULT NULL,
  `Created` datetime DEFAULT NULL,
  `Code` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `RoleID` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `RedirectorPage`
--

CREATE TABLE `RedirectorPage` (
  `ID` int(11) NOT NULL,
  `RedirectionType` enum('Internal','External') CHARACTER SET utf8 DEFAULT 'Internal',
  `ExternalURL` varchar(2083) CHARACTER SET utf8 DEFAULT NULL,
  `LinkToID` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `RedirectorPage_Live`
--

CREATE TABLE `RedirectorPage_Live` (
  `ID` int(11) NOT NULL,
  `RedirectionType` enum('Internal','External') CHARACTER SET utf8 DEFAULT 'Internal',
  `ExternalURL` varchar(2083) CHARACTER SET utf8 DEFAULT NULL,
  `LinkToID` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `RedirectorPage_Versions`
--

CREATE TABLE `RedirectorPage_Versions` (
  `ID` int(11) NOT NULL,
  `RecordID` int(11) NOT NULL DEFAULT '0',
  `Version` int(11) NOT NULL DEFAULT '0',
  `RedirectionType` enum('Internal','External') CHARACTER SET utf8 DEFAULT 'Internal',
  `ExternalURL` varchar(2083) CHARACTER SET utf8 DEFAULT NULL,
  `LinkToID` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `RememberLoginHash`
--

CREATE TABLE `RememberLoginHash` (
  `ID` int(11) NOT NULL,
  `ClassName` enum('SilverStripe\\Security\\RememberLoginHash') CHARACTER SET utf8 DEFAULT 'SilverStripe\\Security\\RememberLoginHash',
  `LastEdited` datetime DEFAULT NULL,
  `Created` datetime DEFAULT NULL,
  `DeviceID` varchar(40) CHARACTER SET utf8 DEFAULT NULL,
  `Hash` varchar(160) CHARACTER SET utf8 DEFAULT NULL,
  `ExpiryDate` datetime DEFAULT NULL,
  `MemberID` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `services`
--

CREATE TABLE `services` (
  `ID` int(11) NOT NULL,
  `PhotoID` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `services`
--

INSERT INTO `services` (`ID`, `PhotoID`) VALUES
(11, 10),
(12, 11),
(13, 12),
(14, 13);

-- --------------------------------------------------------

--
-- Table structure for table `services_Live`
--

CREATE TABLE `services_Live` (
  `ID` int(11) NOT NULL,
  `PhotoID` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `services_Live`
--

INSERT INTO `services_Live` (`ID`, `PhotoID`) VALUES
(11, 10),
(12, 11),
(13, 12),
(14, 13);

-- --------------------------------------------------------

--
-- Table structure for table `services_Versions`
--

CREATE TABLE `services_Versions` (
  `ID` int(11) NOT NULL,
  `RecordID` int(11) NOT NULL DEFAULT '0',
  `Version` int(11) NOT NULL DEFAULT '0',
  `PhotoID` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `services_Versions`
--

INSERT INTO `services_Versions` (`ID`, `RecordID`, `Version`, `PhotoID`) VALUES
(1, 11, 1, 0),
(2, 11, 2, 6),
(3, 12, 1, 0),
(4, 12, 2, 7),
(5, 13, 1, 0),
(6, 13, 2, 8),
(7, 14, 1, 0),
(8, 14, 2, 9),
(9, 11, 3, 0),
(10, 12, 3, 0),
(11, 13, 3, 0),
(12, 14, 3, 0),
(13, 11, 4, 10),
(14, 12, 4, 11),
(15, 13, 4, 12),
(16, 14, 4, 13);

-- --------------------------------------------------------

--
-- Table structure for table `SiteConfig`
--

CREATE TABLE `SiteConfig` (
  `ID` int(11) NOT NULL,
  `ClassName` enum('SilverStripe\\SiteConfig\\SiteConfig') CHARACTER SET utf8 DEFAULT 'SilverStripe\\SiteConfig\\SiteConfig',
  `LastEdited` datetime DEFAULT NULL,
  `Created` datetime DEFAULT NULL,
  `Title` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `Tagline` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `CanViewType` enum('Anyone','LoggedInUsers','OnlyTheseUsers') CHARACTER SET utf8 DEFAULT 'Anyone',
  `CanEditType` enum('LoggedInUsers','OnlyTheseUsers') CHARACTER SET utf8 DEFAULT 'LoggedInUsers',
  `CanCreateTopLevelType` enum('LoggedInUsers','OnlyTheseUsers') CHARACTER SET utf8 DEFAULT 'LoggedInUsers',
  `address` mediumtext CHARACTER SET utf8,
  `phone` mediumtext CHARACTER SET utf8,
  `email` mediumtext CHARACTER SET utf8,
  `clock` mediumtext CHARACTER SET utf8,
  `linkedin` mediumtext CHARACTER SET utf8,
  `facebook` mediumtext CHARACTER SET utf8,
  `twitter` mediumtext CHARACTER SET utf8,
  `address1` mediumtext CHARACTER SET utf8,
  `our_blog_id` mediumtext CHARACTER SET utf8
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `SiteConfig`
--

INSERT INTO `SiteConfig` (`ID`, `ClassName`, `LastEdited`, `Created`, `Title`, `Tagline`, `CanViewType`, `CanEditType`, `CanCreateTopLevelType`, `address`, `phone`, `email`, `clock`, `linkedin`, `facebook`, `twitter`, `address1`, `our_blog_id`) VALUES
(1, 'SilverStripe\\SiteConfig\\SiteConfig', '2018-01-16 10:20:27', '2018-01-12 05:56:10', 'Padua', 'your tagline here', 'Anyone', 'LoggedInUsers', 'LoggedInUsers', '1/8 Manning St KIAMA,\r\nNSW 2533', '1300 162 892', 'info@paduafinancialgroup.com.au', 'Monday to Friday: 08:30AM – 5:30PM \r\nSaturday to Sunday: Closed', 'http://www.linkedin.com', 'http://www.facebook.com', 'http://www.twitter.com', NULL, '19');

-- --------------------------------------------------------

--
-- Table structure for table `SiteConfig_CreateTopLevelGroups`
--

CREATE TABLE `SiteConfig_CreateTopLevelGroups` (
  `ID` int(11) NOT NULL,
  `SiteConfigID` int(11) NOT NULL DEFAULT '0',
  `GroupID` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `SiteConfig_EditorGroups`
--

CREATE TABLE `SiteConfig_EditorGroups` (
  `ID` int(11) NOT NULL,
  `SiteConfigID` int(11) NOT NULL DEFAULT '0',
  `GroupID` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `SiteConfig_ViewerGroups`
--

CREATE TABLE `SiteConfig_ViewerGroups` (
  `ID` int(11) NOT NULL,
  `SiteConfigID` int(11) NOT NULL DEFAULT '0',
  `GroupID` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `SiteTree`
--

CREATE TABLE `SiteTree` (
  `ID` int(11) NOT NULL,
  `ClassName` enum('SilverStripe\\CMS\\Model\\SiteTree','HomePage','Page','PaduaHome\\Component\\Banners','PaduaHome\\Component\\HomePageBoxes','PaduaHome\\Component\\Services','PaduaHome\\Component\\Testimonials','SilverStripe\\ErrorPage\\ErrorPage','Axllent\\Weblog\\Model\\Blog','Axllent\\Weblog\\Model\\BlogPost','SilverStripe\\CMS\\Model\\RedirectorPage','SilverStripe\\CMS\\Model\\VirtualPage') CHARACTER SET utf8 DEFAULT 'Page',
  `LastEdited` datetime DEFAULT NULL,
  `Created` datetime DEFAULT NULL,
  `URLSegment` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `Title` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `MenuTitle` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `Content` mediumtext CHARACTER SET utf8,
  `MetaDescription` mediumtext CHARACTER SET utf8,
  `ExtraMeta` mediumtext CHARACTER SET utf8,
  `ShowInMenus` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `ShowInSearch` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `Sort` int(11) NOT NULL DEFAULT '0',
  `HasBrokenFile` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `HasBrokenLink` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `ReportClass` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `Version` int(11) NOT NULL DEFAULT '0',
  `CanViewType` enum('Anyone','LoggedInUsers','OnlyTheseUsers','Inherit') CHARACTER SET utf8 DEFAULT 'Inherit',
  `CanEditType` enum('LoggedInUsers','OnlyTheseUsers','Inherit') CHARACTER SET utf8 DEFAULT 'Inherit',
  `ParentID` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `SiteTree`
--

INSERT INTO `SiteTree` (`ID`, `ClassName`, `LastEdited`, `Created`, `URLSegment`, `Title`, `MenuTitle`, `Content`, `MetaDescription`, `ExtraMeta`, `ShowInMenus`, `ShowInSearch`, `Sort`, `HasBrokenFile`, `HasBrokenLink`, `ReportClass`, `Version`, `CanViewType`, `CanEditType`, `ParentID`) VALUES
(1, 'Page', '2018-01-17 08:00:53', '2018-01-12 05:56:10', 'home', 'Home', NULL, '<p>Welcome to SilverStripe! This is the default homepage. You can edit this page by opening <a href="admin/">the CMS</a>.</p><p>You can now access the <a href="http://docs.silverstripe.org">developer documentation</a>, or begin the <a href="http://www.silverstripe.org/learn/lessons">SilverStripe lessons</a>.</p>', NULL, NULL, 0, 1, 1, 0, 0, NULL, 7, 'Inherit', 'Inherit', 0),
(2, 'Page', '2018-01-17 08:05:21', '2018-01-12 05:56:10', 'about-us', 'ABOUT', NULL, '<p>You can fill this page out with your own content, or delete it and create your own pages.</p>', NULL, NULL, 1, 1, 5, 0, 0, NULL, 3, 'Inherit', 'Inherit', 0),
(3, 'Page', '2018-01-17 08:07:08', '2018-01-12 05:56:10', 'contact-us', 'Contact', NULL, '<p>You can fill this page out with your own content, or delete it and create your own pages.</p>', NULL, NULL, 0, 1, 7, 0, 0, NULL, 4, 'Inherit', 'Inherit', 0),
(4, 'SilverStripe\\ErrorPage\\ErrorPage', '2018-01-12 05:56:11', '2018-01-12 05:56:11', 'page-not-found', 'Page not found', NULL, '<p>Sorry, it seems you were trying to access a page that doesn\'t exist.</p><p>Please check the spelling of the URL you were trying to access and try again.</p>', NULL, NULL, 0, 0, 8, 0, 0, NULL, 1, 'Inherit', 'Inherit', 0),
(5, 'SilverStripe\\ErrorPage\\ErrorPage', '2018-01-12 05:56:11', '2018-01-12 05:56:11', 'server-error', 'Server error', NULL, '<p>Sorry, there was a problem with handling your request.</p>', NULL, NULL, 0, 0, 9, 0, 0, NULL, 1, 'Inherit', 'Inherit', 0),
(7, 'PaduaHome\\Component\\Testimonials', '2018-01-12 07:21:15', '2018-01-12 06:11:00', 'first-view', 'First View', NULL, '<p><span>It’s amazing the difference in the quality and efficiency of our paraplanning since we brought on Padua. They are a seamless extension of our business - at a fraction of the cost of doing it all ourselves.</span></p>', NULL, NULL, 1, 1, 2, 0, 0, NULL, 8, 'Inherit', 'Inherit', 1),
(8, 'PaduaHome\\Component\\Testimonials', '2018-01-12 07:21:24', '2018-01-12 06:16:04', 'second-view', 'Second View', NULL, '<div class="col bg-light-sky padding-30">\n<p>Intelligent, secure paraplanning that scales with your practice. Padua’s ROMA Online paraplanning software keeps you in control of the process. Work with our expert Paraplanners to ensure you deliver the highest quality outcomes for your clients. Think of them as an extension of your team.</p>\n<a class="btn bg-blue ss-broken" href="http://localhost/paduafinancialgroup.com.au/"></a></div>', NULL, NULL, 1, 1, 3, 0, 1, NULL, 6, 'Inherit', 'Inherit', 1),
(9, 'PaduaHome\\Component\\Testimonials', '2018-01-12 07:21:34', '2018-01-12 06:16:58', 'third-view', 'Third View', NULL, '<p><span>Intelligent, secure paraplanning that scales with your practice. Padua’s ROMA Online paraplanning software keeps you in control of the process. Work with our expert Paraplanners to ensure you deliver the highest quality outcomes for your clients. Think of them as an extension of your team.</span></p>', NULL, NULL, 1, 1, 4, 0, 0, NULL, 6, 'Inherit', 'Inherit', 1),
(10, 'PaduaHome\\Component\\Testimonials', '2018-01-12 07:21:06', '2018-01-12 06:39:20', 'store-the-file-in-a-blob-field', 'Store the file in a BLOB field', NULL, '<p>Blobs are a special type database field that store arbitrary binary data, which makes them a great candidate for persisting files. Since it allows you to basically upload directly into the record, this approach has none of the syncing issues that you have with a filesystem, which makes it fairly reliable. The downside is that you can very quickly bloat your database, and it presents a poor separation of concerns. Your database can quickly become re-purposed into a de facto file server if you\'re not judicious about how much you\'re using it.</p>', NULL, NULL, 1, 1, 1, 0, 0, NULL, 4, 'Inherit', 'Inherit', 1),
(11, 'PaduaHome\\Component\\Services', '2018-01-12 07:15:52', '2018-01-12 06:49:25', 'optimise-your-time-and-engage-more-with-your-clients', 'Optimise your time', NULL, '<div class="el-group" data-id="b9965e97d5e59a0256fc3bf539014e6d">\n<div id="TextElementb5b25c224c8475c14e1ac9086b9f6eb0" class="ng-element el-text-2 empty-line-hack font-G-a9qp4vvmdw-n4" data-id="ea6b6f35cf31c782c73db3891822aa5d">\n<p>Optimise your&nbsp;time and engage more with your&nbsp;clients.</p>\n</div>\n</div>', NULL, NULL, 1, 1, 5, 0, 0, NULL, 4, 'Inherit', 'Inherit', 1),
(12, 'PaduaHome\\Component\\Services', '2018-01-12 07:16:00', '2018-01-12 06:51:38', 'improve-your-margins', 'Improve your margins', NULL, '<div class="el-group" data-id="3be56dcb3992f09380b6a847b6367da3">\n<div id="TextElementa79a4bb6f72e43aebbea004bcecae07f" class="ng-element el-text-2 empty-line-hack font-G-a9qp4vvmdw-n4" data-id="524ba8206aa8ab23044387f9b0b593af">\n<p>Improve your margins,<br>reduce overall costs and<br>increase efficiency.</p>\n</div>\n</div>', NULL, NULL, 1, 1, 6, 0, 0, NULL, 4, 'Inherit', 'Inherit', 1),
(13, 'PaduaHome\\Component\\Services', '2018-01-12 07:16:08', '2018-01-12 06:52:08', 'scale-your-business', 'Scale your business', NULL, '<p><span>Scale your business</span><br><span>faster with on-demand</span><br><span>services.</span></p>', NULL, NULL, 1, 1, 7, 0, 0, NULL, 4, 'Inherit', 'Inherit', 1),
(14, 'PaduaHome\\Component\\Services', '2018-01-12 07:16:14', '2018-01-12 06:52:36', 'local-expert-qualified', 'Local, expert, qualified', NULL, '<p><span>Local, expert, qualified</span><br><span>paraplanners who are an</span><br><span>extension of your team.</span></p>', NULL, NULL, 1, 1, 8, 0, 0, NULL, 4, 'Inherit', 'Inherit', 1),
(15, 'PaduaHome\\Component\\Banners', '2018-01-12 07:23:51', '2018-01-12 07:23:16', 'banner-1', 'Banner 1', NULL, NULL, NULL, NULL, 1, 1, 9, 0, 0, NULL, 2, 'Inherit', 'Inherit', 1),
(16, 'PaduaHome\\Component\\Banners', '2018-01-12 07:24:21', '2018-01-12 07:24:05', 'banner-2', 'Banner 2', NULL, NULL, NULL, NULL, 1, 1, 10, 0, 0, NULL, 2, 'Inherit', 'Inherit', 1),
(18, 'Page', '2018-01-12 07:41:45', '2018-01-12 07:40:57', 'paraplanning', 'PARAPLANNING', NULL, NULL, NULL, NULL, 1, 1, 2, 0, 0, NULL, 3, 'Inherit', 'Inherit', 0),
(19, 'Axllent\\Weblog\\Model\\Blog', '2018-01-17 08:06:09', '2018-01-16 09:49:17', 'our-blog', 'Blog', NULL, NULL, NULL, NULL, 0, 1, 10, 0, 0, NULL, 4, 'Inherit', 'Inherit', 0),
(20, 'Axllent\\Weblog\\Model\\BlogPost', '2018-01-16 10:33:46', '2018-01-16 09:50:53', 'suspendisse-consectetur-fringilla-luctus', 'Suspendisse consectetur fringilla luctus 2', NULL, '<p><span>Suspendisse consectetur fringilla luctus</span></p>', NULL, NULL, 0, 1, 1, 0, 0, NULL, 3, 'Inherit', 'Inherit', 19),
(21, 'Axllent\\Weblog\\Model\\BlogPost', '2018-01-16 10:33:38', '2018-01-16 10:31:58', 'suspendisse-consectetur-fringilla-luctus-2', 'Suspendisse consectetur fringilla luctus 1', NULL, '<p>Suspendisse consectetur fringilla luctus</p><p>&nbsp;</p>', NULL, NULL, 0, 1, 2, 0, 0, NULL, 5, 'Inherit', 'Inherit', 19),
(22, 'Axllent\\Weblog\\Model\\BlogPost', '2018-01-16 10:34:16', '2018-01-16 10:33:26', 'v', 'Suspendisse consectetur fringilla luctus 3', NULL, '<p><span>Suspendisse consectetur fringilla luctus</span></p>', NULL, NULL, 0, 1, 3, 0, 0, NULL, 3, 'Inherit', 'Inherit', 19),
(24, 'PaduaHome\\Component\\HomePageBoxes', '2018-01-17 07:28:50', '2018-01-16 14:15:18', 'outsourced-paraplanning', 'OUTSOURCED PARAPLANNING', NULL, '<div id="TextElement88e2d720862bb7baff0c307df73e0cab" class="ng-element el-text-2 empty-line-hack line-height-fix font-G-a9qp4vvmdw-n3" data-id="7c5b962c7d374f96589c8f6e11885dc5">\n<p>Intelligent, secure paraplanning that scales with your practice. Padua’s ROMA Online paraplanning software keeps you in control of the process. Work with our expert Paraplanners to ensure you deliver the highest quality outcomes for your clients. Think of them as an extension of your team.</p>\n</div>', NULL, NULL, 1, 1, 11, 0, 0, NULL, 5, 'Inherit', 'Inherit', 1),
(25, 'PaduaHome\\Component\\HomePageBoxes', '2018-01-17 07:28:55', '2018-01-16 14:16:04', 'outsourced-transition-management', 'OUTSOURCED TRANSITION MANAGEMENT', NULL, '<div id="TextElementb1e772fc3b4e8707fa71239c5117c263" class="ng-element el-text-2 empty-line-hack line-height-fix font-G-a9qp4vvmdw-n3" data-id="ebe43880a6bafb055a73bd85d17ae2ec">\n<p>The only, end-to-end Transition Service for moving large volumes of advsier\'s clients. Padua\'s TORINO transtition software provides total control and transparency, compliance oversight and security for fast and efficient transitioning of superannuation, pensions, investments or insurance.</p>\n</div>', NULL, NULL, 1, 1, 12, 0, 0, NULL, 5, 'Inherit', 'Inherit', 1),
(26, 'PaduaHome\\Component\\HomePageBoxes', '2018-01-16 14:20:29', '2018-01-16 14:19:48', 'image', 'Image', NULL, NULL, NULL, NULL, 1, 1, 13, 0, 0, NULL, 2, 'Inherit', 'Inherit', 1),
(27, 'PaduaHome\\Component\\HomePageBoxes', '2018-01-17 07:29:06', '2018-01-16 14:20:40', 'padua-technology', 'PADUA TECHNOLOGY', NULL, '<div id="TextElement93e231dd3e2506c57d3ba8f4feba3bd4" class="ng-element el-text-2 empty-line-hack line-height-fix font-G-a9qp4vvmdw-n3" data-id="613b09cb047faa80507e0b6ee8f0c238">\n<p>Padua\'s ROMA Paraplanning and TORINO Transition Management software is designed to help you produce the highest quality advice for your clients. Outsourcing advice generation to Padua means advisers, dealer groups and licensees can focus on clients and growing the business.</p>\n</div>', NULL, NULL, 1, 1, 14, 0, 0, NULL, 3, 'Inherit', 'Inherit', 1),
(29, 'Page', '2018-01-17 07:49:58', '2018-01-17 07:49:39', 'transition-management', ' TRANSITION MANAGEMENT', NULL, '<p>Coming soon...</p>', NULL, NULL, 1, 1, 3, 0, 0, NULL, 3, 'Inherit', 'Inherit', 0),
(30, 'Page', '2018-01-17 07:50:49', '2018-01-17 07:50:20', 'technology', 'TECHNOLOGY', NULL, '<p>Coming soon...</p>', NULL, NULL, 1, 1, 4, 0, 0, NULL, 5, 'Inherit', 'Inherit', 0),
(31, 'Page', '2018-01-17 07:53:09', '2018-01-17 07:51:04', 'careers-2', 'CAREERS', NULL, '<p>Coming soon...</p>', NULL, NULL, 1, 1, 6, 0, 0, NULL, 6, 'Inherit', 'Inherit', 0),
(32, 'Page', '2018-01-17 08:06:28', '2018-01-17 07:52:40', 'careers', 'Our Privacy Policy', NULL, '<p>Coming Soon</p>', NULL, NULL, 0, 1, 11, 0, 0, NULL, 5, 'Inherit', 'Inherit', 0);

-- --------------------------------------------------------

--
-- Table structure for table `SiteTree_EditorGroups`
--

CREATE TABLE `SiteTree_EditorGroups` (
  `ID` int(11) NOT NULL,
  `SiteTreeID` int(11) NOT NULL DEFAULT '0',
  `GroupID` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `SiteTree_ImageTracking`
--

CREATE TABLE `SiteTree_ImageTracking` (
  `ID` int(11) NOT NULL,
  `SiteTreeID` int(11) NOT NULL DEFAULT '0',
  `FileID` int(11) NOT NULL DEFAULT '0',
  `FieldName` varchar(255) CHARACTER SET utf8 DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `SiteTree_LinkTracking`
--

CREATE TABLE `SiteTree_LinkTracking` (
  `ID` int(11) NOT NULL,
  `SiteTreeID` int(11) NOT NULL DEFAULT '0',
  `ChildID` int(11) NOT NULL DEFAULT '0',
  `FieldName` varchar(255) CHARACTER SET utf8 DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `SiteTree_Live`
--

CREATE TABLE `SiteTree_Live` (
  `ID` int(11) NOT NULL,
  `ClassName` enum('SilverStripe\\CMS\\Model\\SiteTree','HomePage','Page','PaduaHome\\Component\\Banners','PaduaHome\\Component\\HomePageBoxes','PaduaHome\\Component\\Services','PaduaHome\\Component\\Testimonials','SilverStripe\\ErrorPage\\ErrorPage','Axllent\\Weblog\\Model\\Blog','Axllent\\Weblog\\Model\\BlogPost','SilverStripe\\CMS\\Model\\RedirectorPage','SilverStripe\\CMS\\Model\\VirtualPage') CHARACTER SET utf8 DEFAULT 'Page',
  `LastEdited` datetime DEFAULT NULL,
  `Created` datetime DEFAULT NULL,
  `URLSegment` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `Title` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `MenuTitle` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `Content` mediumtext CHARACTER SET utf8,
  `MetaDescription` mediumtext CHARACTER SET utf8,
  `ExtraMeta` mediumtext CHARACTER SET utf8,
  `ShowInMenus` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `ShowInSearch` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `Sort` int(11) NOT NULL DEFAULT '0',
  `HasBrokenFile` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `HasBrokenLink` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `ReportClass` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `Version` int(11) NOT NULL DEFAULT '0',
  `CanViewType` enum('Anyone','LoggedInUsers','OnlyTheseUsers','Inherit') CHARACTER SET utf8 DEFAULT 'Inherit',
  `CanEditType` enum('LoggedInUsers','OnlyTheseUsers','Inherit') CHARACTER SET utf8 DEFAULT 'Inherit',
  `ParentID` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `SiteTree_Live`
--

INSERT INTO `SiteTree_Live` (`ID`, `ClassName`, `LastEdited`, `Created`, `URLSegment`, `Title`, `MenuTitle`, `Content`, `MetaDescription`, `ExtraMeta`, `ShowInMenus`, `ShowInSearch`, `Sort`, `HasBrokenFile`, `HasBrokenLink`, `ReportClass`, `Version`, `CanViewType`, `CanEditType`, `ParentID`) VALUES
(1, 'Page', '2018-01-17 08:00:53', '2018-01-12 05:56:10', 'home', 'Home', NULL, '<p>Welcome to SilverStripe! This is the default homepage. You can edit this page by opening <a href="admin/">the CMS</a>.</p><p>You can now access the <a href="http://docs.silverstripe.org">developer documentation</a>, or begin the <a href="http://www.silverstripe.org/learn/lessons">SilverStripe lessons</a>.</p>', NULL, NULL, 0, 1, 1, 0, 0, NULL, 7, 'Inherit', 'Inherit', 0),
(2, 'Page', '2018-01-17 08:05:21', '2018-01-12 05:56:10', 'about-us', 'ABOUT', NULL, '<p>You can fill this page out with your own content, or delete it and create your own pages.</p>', NULL, NULL, 1, 1, 5, 0, 0, NULL, 3, 'Inherit', 'Inherit', 0),
(3, 'Page', '2018-01-17 08:07:08', '2018-01-12 05:56:10', 'contact-us', 'Contact', NULL, '<p>You can fill this page out with your own content, or delete it and create your own pages.</p>', NULL, NULL, 0, 1, 7, 0, 0, NULL, 4, 'Inherit', 'Inherit', 0),
(4, 'SilverStripe\\ErrorPage\\ErrorPage', '2018-01-12 05:56:11', '2018-01-12 05:56:11', 'page-not-found', 'Page not found', NULL, '<p>Sorry, it seems you were trying to access a page that doesn\'t exist.</p><p>Please check the spelling of the URL you were trying to access and try again.</p>', NULL, NULL, 0, 0, 8, 0, 0, NULL, 1, 'Inherit', 'Inherit', 0),
(5, 'SilverStripe\\ErrorPage\\ErrorPage', '2018-01-12 05:56:11', '2018-01-12 05:56:11', 'server-error', 'Server error', NULL, '<p>Sorry, there was a problem with handling your request.</p>', NULL, NULL, 0, 0, 9, 0, 0, NULL, 1, 'Inherit', 'Inherit', 0),
(7, 'PaduaHome\\Component\\Testimonials', '2018-01-12 07:21:15', '2018-01-12 06:11:00', 'first-view', 'First View', NULL, '<p><span>It’s amazing the difference in the quality and efficiency of our paraplanning since we brought on Padua. They are a seamless extension of our business - at a fraction of the cost of doing it all ourselves.</span></p>', NULL, NULL, 1, 1, 2, 0, 0, NULL, 8, 'Inherit', 'Inherit', 1),
(8, 'PaduaHome\\Component\\Testimonials', '2018-01-12 07:21:24', '2018-01-12 06:16:04', 'second-view', 'Second View', NULL, '<div class="col bg-light-sky padding-30">\n<p>Intelligent, secure paraplanning that scales with your practice. Padua’s ROMA Online paraplanning software keeps you in control of the process. Work with our expert Paraplanners to ensure you deliver the highest quality outcomes for your clients. Think of them as an extension of your team.</p>\n<a class="btn bg-blue ss-broken" href="http://localhost/paduafinancialgroup.com.au/"></a></div>', NULL, NULL, 1, 1, 3, 0, 1, NULL, 6, 'Inherit', 'Inherit', 1),
(9, 'PaduaHome\\Component\\Testimonials', '2018-01-12 07:21:34', '2018-01-12 06:16:58', 'third-view', 'Third View', NULL, '<p><span>Intelligent, secure paraplanning that scales with your practice. Padua’s ROMA Online paraplanning software keeps you in control of the process. Work with our expert Paraplanners to ensure you deliver the highest quality outcomes for your clients. Think of them as an extension of your team.</span></p>', NULL, NULL, 1, 1, 4, 0, 0, NULL, 6, 'Inherit', 'Inherit', 1),
(10, 'PaduaHome\\Component\\Testimonials', '2018-01-12 07:21:06', '2018-01-12 06:39:20', 'store-the-file-in-a-blob-field', 'Store the file in a BLOB field', NULL, '<p>Blobs are a special type database field that store arbitrary binary data, which makes them a great candidate for persisting files. Since it allows you to basically upload directly into the record, this approach has none of the syncing issues that you have with a filesystem, which makes it fairly reliable. The downside is that you can very quickly bloat your database, and it presents a poor separation of concerns. Your database can quickly become re-purposed into a de facto file server if you\'re not judicious about how much you\'re using it.</p>', NULL, NULL, 1, 1, 1, 0, 0, NULL, 4, 'Inherit', 'Inherit', 1),
(11, 'PaduaHome\\Component\\Services', '2018-01-12 07:15:52', '2018-01-12 06:49:25', 'optimise-your-time-and-engage-more-with-your-clients', 'Optimise your time', NULL, '<div class="el-group" data-id="b9965e97d5e59a0256fc3bf539014e6d">\n<div id="TextElementb5b25c224c8475c14e1ac9086b9f6eb0" class="ng-element el-text-2 empty-line-hack font-G-a9qp4vvmdw-n4" data-id="ea6b6f35cf31c782c73db3891822aa5d">\n<p>Optimise your&nbsp;time and engage more with your&nbsp;clients.</p>\n</div>\n</div>', NULL, NULL, 1, 1, 5, 0, 0, NULL, 4, 'Inherit', 'Inherit', 1),
(12, 'PaduaHome\\Component\\Services', '2018-01-12 07:16:00', '2018-01-12 06:51:38', 'improve-your-margins', 'Improve your margins', NULL, '<div class="el-group" data-id="3be56dcb3992f09380b6a847b6367da3">\n<div id="TextElementa79a4bb6f72e43aebbea004bcecae07f" class="ng-element el-text-2 empty-line-hack font-G-a9qp4vvmdw-n4" data-id="524ba8206aa8ab23044387f9b0b593af">\n<p>Improve your margins,<br>reduce overall costs and<br>increase efficiency.</p>\n</div>\n</div>', NULL, NULL, 1, 1, 6, 0, 0, NULL, 4, 'Inherit', 'Inherit', 1),
(13, 'PaduaHome\\Component\\Services', '2018-01-12 07:16:08', '2018-01-12 06:52:08', 'scale-your-business', 'Scale your business', NULL, '<p><span>Scale your business</span><br><span>faster with on-demand</span><br><span>services.</span></p>', NULL, NULL, 1, 1, 7, 0, 0, NULL, 4, 'Inherit', 'Inherit', 1),
(14, 'PaduaHome\\Component\\Services', '2018-01-12 07:16:14', '2018-01-12 06:52:36', 'local-expert-qualified', 'Local, expert, qualified', NULL, '<p><span>Local, expert, qualified</span><br><span>paraplanners who are an</span><br><span>extension of your team.</span></p>', NULL, NULL, 1, 1, 8, 0, 0, NULL, 4, 'Inherit', 'Inherit', 1),
(15, 'PaduaHome\\Component\\Banners', '2018-01-12 07:23:51', '2018-01-12 07:23:16', 'banner-1', 'Banner 1', NULL, NULL, NULL, NULL, 1, 1, 9, 0, 0, NULL, 2, 'Inherit', 'Inherit', 1),
(16, 'PaduaHome\\Component\\Banners', '2018-01-12 07:24:21', '2018-01-12 07:24:05', 'banner-2', 'Banner 2', NULL, NULL, NULL, NULL, 1, 1, 10, 0, 0, NULL, 2, 'Inherit', 'Inherit', 1),
(18, 'Page', '2018-01-12 07:41:45', '2018-01-12 07:40:57', 'paraplanning', 'PARAPLANNING', NULL, NULL, NULL, NULL, 1, 1, 2, 0, 0, NULL, 3, 'Inherit', 'Inherit', 0),
(19, 'Axllent\\Weblog\\Model\\Blog', '2018-01-17 08:06:09', '2018-01-16 09:49:17', 'our-blog', 'Blog', NULL, NULL, NULL, NULL, 0, 1, 10, 0, 0, NULL, 4, 'Inherit', 'Inherit', 0),
(20, 'Axllent\\Weblog\\Model\\BlogPost', '2018-01-16 10:33:46', '2018-01-16 09:50:53', 'suspendisse-consectetur-fringilla-luctus', 'Suspendisse consectetur fringilla luctus 2', NULL, '<p><span>Suspendisse consectetur fringilla luctus</span></p>', NULL, NULL, 0, 1, 1, 0, 0, NULL, 3, 'Inherit', 'Inherit', 19),
(21, 'Axllent\\Weblog\\Model\\BlogPost', '2018-01-16 10:33:38', '2018-01-16 10:31:58', 'suspendisse-consectetur-fringilla-luctus-2', 'Suspendisse consectetur fringilla luctus 1', NULL, '<p>Suspendisse consectetur fringilla luctus</p><p>&nbsp;</p>', NULL, NULL, 0, 1, 2, 0, 0, NULL, 5, 'Inherit', 'Inherit', 19),
(22, 'Axllent\\Weblog\\Model\\BlogPost', '2018-01-16 10:34:16', '2018-01-16 10:33:26', 'v', 'Suspendisse consectetur fringilla luctus 3', NULL, '<p><span>Suspendisse consectetur fringilla luctus</span></p>', NULL, NULL, 0, 1, 3, 0, 0, NULL, 3, 'Inherit', 'Inherit', 19),
(24, 'PaduaHome\\Component\\HomePageBoxes', '2018-01-17 06:09:25', '2018-01-16 14:15:18', 'outsourced-paraplanning', 'OUTSOURCED PARAPLANNING', NULL, '<div id="TextElement88e2d720862bb7baff0c307df73e0cab" class="ng-element el-text-2 empty-line-hack line-height-fix font-G-a9qp4vvmdw-n3" data-id="7c5b962c7d374f96589c8f6e11885dc5">\n<p>Intelligent, secure paraplanning that scales with your practice. Padua’s ROMA Online paraplanning software keeps you in control of the process. Work with our expert Paraplanners to ensure you deliver the highest quality outcomes for your clients. Think of them as an extension of your team.</p>\n</div>', NULL, NULL, 1, 1, 11, 0, 0, NULL, 5, 'Inherit', 'Inherit', 1),
(25, 'PaduaHome\\Component\\HomePageBoxes', '2018-01-17 07:28:55', '2018-01-16 14:16:04', 'outsourced-transition-management', 'OUTSOURCED TRANSITION MANAGEMENT', NULL, '<div id="TextElementb1e772fc3b4e8707fa71239c5117c263" class="ng-element el-text-2 empty-line-hack line-height-fix font-G-a9qp4vvmdw-n3" data-id="ebe43880a6bafb055a73bd85d17ae2ec">\n<p>The only, end-to-end Transition Service for moving large volumes of advsier\'s clients. Padua\'s TORINO transtition software provides total control and transparency, compliance oversight and security for fast and efficient transitioning of superannuation, pensions, investments or insurance.</p>\n</div>', NULL, NULL, 1, 1, 12, 0, 0, NULL, 5, 'Inherit', 'Inherit', 1),
(26, 'PaduaHome\\Component\\HomePageBoxes', '2018-01-16 14:20:29', '2018-01-16 14:19:48', 'image', 'Image', NULL, NULL, NULL, NULL, 1, 1, 13, 0, 0, NULL, 2, 'Inherit', 'Inherit', 1),
(27, 'PaduaHome\\Component\\HomePageBoxes', '2018-01-17 07:29:06', '2018-01-16 14:20:40', 'padua-technology', 'PADUA TECHNOLOGY', NULL, '<div id="TextElement93e231dd3e2506c57d3ba8f4feba3bd4" class="ng-element el-text-2 empty-line-hack line-height-fix font-G-a9qp4vvmdw-n3" data-id="613b09cb047faa80507e0b6ee8f0c238">\n<p>Padua\'s ROMA Paraplanning and TORINO Transition Management software is designed to help you produce the highest quality advice for your clients. Outsourcing advice generation to Padua means advisers, dealer groups and licensees can focus on clients and growing the business.</p>\n</div>', NULL, NULL, 1, 1, 14, 0, 0, NULL, 3, 'Inherit', 'Inherit', 1),
(29, 'Page', '2018-01-17 07:49:58', '2018-01-17 07:49:39', 'transition-management', ' TRANSITION MANAGEMENT', NULL, '<p>Coming soon...</p>', NULL, NULL, 1, 1, 3, 0, 0, NULL, 3, 'Inherit', 'Inherit', 0),
(30, 'Page', '2018-01-17 07:50:49', '2018-01-17 07:50:20', 'technology', 'TECHNOLOGY', NULL, '<p>Coming soon...</p>', NULL, NULL, 1, 1, 4, 0, 0, NULL, 5, 'Inherit', 'Inherit', 0),
(31, 'Page', '2018-01-17 07:53:09', '2018-01-17 07:51:04', 'careers-2', 'CAREERS', NULL, '<p>Coming soon...</p>', NULL, NULL, 1, 1, 6, 0, 0, NULL, 6, 'Inherit', 'Inherit', 0),
(32, 'Page', '2018-01-17 08:06:28', '2018-01-17 07:52:40', 'careers', 'Our Privacy Policy', NULL, '<p>Coming Soon</p>', NULL, NULL, 0, 1, 11, 0, 0, NULL, 5, 'Inherit', 'Inherit', 0);

-- --------------------------------------------------------

--
-- Table structure for table `SiteTree_Versions`
--

CREATE TABLE `SiteTree_Versions` (
  `ID` int(11) NOT NULL,
  `RecordID` int(11) NOT NULL DEFAULT '0',
  `Version` int(11) NOT NULL DEFAULT '0',
  `WasPublished` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `AuthorID` int(11) NOT NULL DEFAULT '0',
  `PublisherID` int(11) NOT NULL DEFAULT '0',
  `ClassName` enum('SilverStripe\\CMS\\Model\\SiteTree','HomePage','Page','PaduaHome\\Component\\Banners','PaduaHome\\Component\\HomePageBoxes','PaduaHome\\Component\\Services','PaduaHome\\Component\\Testimonials','SilverStripe\\ErrorPage\\ErrorPage','Axllent\\Weblog\\Model\\Blog','Axllent\\Weblog\\Model\\BlogPost','SilverStripe\\CMS\\Model\\RedirectorPage','SilverStripe\\CMS\\Model\\VirtualPage','','SilverStripe\\Lessons\\TestimonialHolder','SilverStripe\\Lessons\\TestimonialPage','SilverStripe\\Lessons\\ServicesPage') CHARACTER SET utf8 DEFAULT 'Page',
  `LastEdited` datetime DEFAULT NULL,
  `Created` datetime DEFAULT NULL,
  `URLSegment` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `Title` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `MenuTitle` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `Content` mediumtext CHARACTER SET utf8,
  `MetaDescription` mediumtext CHARACTER SET utf8,
  `ExtraMeta` mediumtext CHARACTER SET utf8,
  `ShowInMenus` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `ShowInSearch` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `Sort` int(11) NOT NULL DEFAULT '0',
  `HasBrokenFile` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `HasBrokenLink` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `ReportClass` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `CanViewType` enum('Anyone','LoggedInUsers','OnlyTheseUsers','Inherit') CHARACTER SET utf8 DEFAULT 'Inherit',
  `CanEditType` enum('LoggedInUsers','OnlyTheseUsers','Inherit') CHARACTER SET utf8 DEFAULT 'Inherit',
  `ParentID` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `SiteTree_Versions`
--

INSERT INTO `SiteTree_Versions` (`ID`, `RecordID`, `Version`, `WasPublished`, `AuthorID`, `PublisherID`, `ClassName`, `LastEdited`, `Created`, `URLSegment`, `Title`, `MenuTitle`, `Content`, `MetaDescription`, `ExtraMeta`, `ShowInMenus`, `ShowInSearch`, `Sort`, `HasBrokenFile`, `HasBrokenLink`, `ReportClass`, `CanViewType`, `CanEditType`, `ParentID`) VALUES
(1, 1, 1, 1, 0, 0, 'Page', '2018-01-12 05:56:10', '2018-01-12 05:56:10', 'home', 'Home', NULL, '<p>Welcome to SilverStripe! This is the default homepage. You can edit this page by opening <a href="admin/">the CMS</a>.</p><p>You can now access the <a href="http://docs.silverstripe.org">developer documentation</a>, or begin the <a href="http://www.silverstripe.org/learn/lessons">SilverStripe lessons</a>.</p>', NULL, NULL, 1, 1, 1, 0, 0, NULL, 'Inherit', 'Inherit', 0),
(2, 2, 1, 1, 0, 0, 'Page', '2018-01-12 05:56:10', '2018-01-12 05:56:10', 'about-us', 'About Us', NULL, '<p>You can fill this page out with your own content, or delete it and create your own pages.</p>', NULL, NULL, 1, 1, 2, 0, 0, NULL, 'Inherit', 'Inherit', 0),
(3, 3, 1, 1, 0, 0, 'Page', '2018-01-12 05:56:10', '2018-01-12 05:56:10', 'contact-us', 'Contact Us', NULL, '<p>You can fill this page out with your own content, or delete it and create your own pages.</p>', NULL, NULL, 1, 1, 3, 0, 0, NULL, 'Inherit', 'Inherit', 0),
(4, 4, 1, 1, 0, 0, 'SilverStripe\\ErrorPage\\ErrorPage', '2018-01-12 05:56:11', '2018-01-12 05:56:11', 'page-not-found', 'Page not found', NULL, '<p>Sorry, it seems you were trying to access a page that doesn\'t exist.</p><p>Please check the spelling of the URL you were trying to access and try again.</p>', NULL, NULL, 0, 0, 4, 0, 0, NULL, 'Inherit', 'Inherit', 0),
(5, 5, 1, 1, 0, 0, 'SilverStripe\\ErrorPage\\ErrorPage', '2018-01-12 05:56:11', '2018-01-12 05:56:11', 'server-error', 'Server error', NULL, '<p>Sorry, there was a problem with handling your request.</p>', NULL, NULL, 0, 0, 5, 0, 0, NULL, 'Inherit', 'Inherit', 0),
(6, 6, 1, 0, 1, 0, 'SilverStripe\\Lessons\\TestimonialHolder', '2018-01-12 06:10:36', '2018-01-12 06:10:36', 'new-testimonial-holder', 'New Testimonial Holder', NULL, NULL, NULL, NULL, 1, 1, 6, 0, 0, NULL, 'Inherit', 'Inherit', 0),
(7, 6, 2, 1, 1, 1, 'SilverStripe\\Lessons\\TestimonialHolder', '2018-01-12 06:10:49', '2018-01-12 06:10:36', 'testimonials', 'Testimonials', NULL, NULL, NULL, NULL, 1, 1, 6, 0, 0, NULL, 'Inherit', 'Inherit', 0),
(8, 7, 1, 0, 1, 0, 'SilverStripe\\Lessons\\TestimonialPage', '2018-01-12 06:11:00', '2018-01-12 06:11:00', 'new-testimonial-page', 'New Testimonial Page', NULL, NULL, NULL, NULL, 1, 1, 1, 0, 0, NULL, 'Inherit', 'Inherit', 6),
(9, 7, 2, 1, 1, 1, 'SilverStripe\\Lessons\\TestimonialPage', '2018-01-12 06:12:31', '2018-01-12 06:11:00', 'first-view', 'First View', NULL, '<p><span>FIt’s amazing the difference in the quality and efficiency of our paraplanning since we brought on Padua. They are a seamless extension of our business - at a fraction of the cost of doing it all ourselves.</span></p>', NULL, NULL, 1, 1, 1, 0, 0, NULL, 'Inherit', 'Inherit', 6),
(10, 7, 3, 1, 1, 1, 'SilverStripe\\Lessons\\TestimonialPage', '2018-01-12 06:15:28', '2018-01-12 06:11:00', 'first-view', 'First View', NULL, '<p><span>FIt’s amazing the difference in the quality and efficiency of our paraplanning since we brought on Padua. They are a seamless extension of our business - at a fraction of the cost of doing it all ourselves.</span></p>', NULL, NULL, 1, 1, 1, 0, 0, NULL, 'Inherit', 'Inherit', 6),
(11, 7, 4, 1, 1, 1, 'SilverStripe\\Lessons\\TestimonialPage', '2018-01-12 06:15:50', '2018-01-12 06:11:00', 'first-view', 'First View', NULL, '<p><span>It’s amazing the difference in the quality and efficiency of our paraplanning since we brought on Padua. They are a seamless extension of our business - at a fraction of the cost of doing it all ourselves.</span></p>', NULL, NULL, 1, 1, 1, 0, 0, NULL, 'Inherit', 'Inherit', 6),
(12, 8, 1, 0, 1, 0, 'SilverStripe\\Lessons\\TestimonialPage', '2018-01-12 06:16:04', '2018-01-12 06:16:04', 'new-testimonial-page', 'New Testimonial Page', NULL, NULL, NULL, NULL, 1, 1, 2, 0, 0, NULL, 'Inherit', 'Inherit', 6),
(13, 8, 2, 1, 1, 1, 'SilverStripe\\Lessons\\TestimonialPage', '2018-01-12 06:16:41', '2018-01-12 06:16:04', 'second-view', 'Second View', NULL, '<div class="col bg-light-sky padding-30">\n<p>Intelligent, secure paraplanning that scales with your practice. Padua’s ROMA Online paraplanning software keeps you in control of the process. Work with our expert Paraplanners to ensure you deliver the highest quality outcomes for your clients. Think of them as an extension of your team.</p>\n<a class="btn bg-blue ss-broken" href="http://localhost/paduafinancialgroup.com.au/"></a></div>', NULL, NULL, 1, 1, 2, 0, 1, NULL, 'Inherit', 'Inherit', 6),
(14, 9, 1, 0, 1, 0, 'SilverStripe\\Lessons\\TestimonialPage', '2018-01-12 06:16:58', '2018-01-12 06:16:58', 'new-testimonial-page', 'New Testimonial Page', NULL, NULL, NULL, NULL, 1, 1, 3, 0, 0, NULL, 'Inherit', 'Inherit', 6),
(15, 9, 2, 1, 1, 1, 'SilverStripe\\Lessons\\TestimonialPage', '2018-01-12 06:17:22', '2018-01-12 06:16:58', 'third-view', 'Third View', NULL, '<p><span>Intelligent, secure paraplanning that scales with your practice. Padua’s ROMA Online paraplanning software keeps you in control of the process. Work with our expert Paraplanners to ensure you deliver the highest quality outcomes for your clients. Think of them as an extension of your team.</span></p>', NULL, NULL, 1, 1, 3, 0, 0, NULL, 'Inherit', 'Inherit', 6),
(16, 10, 1, 0, 1, 0, 'SilverStripe\\Lessons\\TestimonialPage', '2018-01-12 06:39:20', '2018-01-12 06:39:20', 'new-testimonial-page', 'New Testimonial Page', NULL, NULL, NULL, NULL, 1, 1, 1, 0, 0, NULL, 'Inherit', 'Inherit', 1),
(17, 10, 2, 1, 1, 1, 'SilverStripe\\Lessons\\TestimonialPage', '2018-01-12 06:40:04', '2018-01-12 06:39:20', 'store-the-file-in-a-blob-field', 'Store the file in a BLOB field', NULL, '<p>Blobs are a special type database field that store arbitrary binary data, which makes them a great candidate for persisting files. Since it allows you to basically upload directly into the record, this approach has none of the syncing issues that you have with a filesystem, which makes it fairly reliable. The downside is that you can very quickly bloat your database, and it presents a poor separation of concerns. Your database can quickly become re-purposed into a de facto file server if you\'re not judicious about how much you\'re using it.</p>', NULL, NULL, 1, 1, 1, 0, 0, NULL, 'Inherit', 'Inherit', 1),
(18, 7, 5, 0, 1, 0, 'SilverStripe\\Lessons\\TestimonialPage', '2018-01-12 06:41:49', '2018-01-12 06:11:00', 'first-view', 'First View', NULL, '<p><span>It’s amazing the difference in the quality and efficiency of our paraplanning since we brought on Padua. They are a seamless extension of our business - at a fraction of the cost of doing it all ourselves.</span></p>', NULL, NULL, 1, 1, 1, 0, 0, NULL, 'Inherit', 'Inherit', 1),
(19, 7, 6, 1, 1, 1, 'SilverStripe\\Lessons\\TestimonialPage', '2018-01-12 06:41:49', '2018-01-12 06:11:00', 'first-view', 'First View', NULL, '<p><span>It’s amazing the difference in the quality and efficiency of our paraplanning since we brought on Padua. They are a seamless extension of our business - at a fraction of the cost of doing it all ourselves.</span></p>', NULL, NULL, 1, 1, 2, 0, 0, NULL, 'Inherit', 'Inherit', 1),
(20, 8, 3, 0, 1, 0, 'SilverStripe\\Lessons\\TestimonialPage', '2018-01-12 06:41:55', '2018-01-12 06:16:04', 'second-view', 'Second View', NULL, '<div class="col bg-light-sky padding-30">\n<p>Intelligent, secure paraplanning that scales with your practice. Padua’s ROMA Online paraplanning software keeps you in control of the process. Work with our expert Paraplanners to ensure you deliver the highest quality outcomes for your clients. Think of them as an extension of your team.</p>\n<a class="btn bg-blue ss-broken" href="http://localhost/paduafinancialgroup.com.au/"></a></div>', NULL, NULL, 1, 1, 2, 0, 1, NULL, 'Inherit', 'Inherit', 1),
(21, 8, 4, 1, 1, 1, 'SilverStripe\\Lessons\\TestimonialPage', '2018-01-12 06:41:55', '2018-01-12 06:16:04', 'second-view', 'Second View', NULL, '<div class="col bg-light-sky padding-30">\n<p>Intelligent, secure paraplanning that scales with your practice. Padua’s ROMA Online paraplanning software keeps you in control of the process. Work with our expert Paraplanners to ensure you deliver the highest quality outcomes for your clients. Think of them as an extension of your team.</p>\n<a class="btn bg-blue ss-broken" href="http://localhost/paduafinancialgroup.com.au/"></a></div>', NULL, NULL, 1, 1, 3, 0, 1, NULL, 'Inherit', 'Inherit', 1),
(22, 9, 3, 0, 1, 0, 'SilverStripe\\Lessons\\TestimonialPage', '2018-01-12 06:41:58', '2018-01-12 06:16:58', 'third-view', 'Third View', NULL, '<p><span>Intelligent, secure paraplanning that scales with your practice. Padua’s ROMA Online paraplanning software keeps you in control of the process. Work with our expert Paraplanners to ensure you deliver the highest quality outcomes for your clients. Think of them as an extension of your team.</span></p>', NULL, NULL, 1, 1, 3, 0, 0, NULL, 'Inherit', 'Inherit', 1),
(23, 9, 4, 1, 1, 1, 'SilverStripe\\Lessons\\TestimonialPage', '2018-01-12 06:41:58', '2018-01-12 06:16:58', 'third-view', 'Third View', NULL, '<p><span>Intelligent, secure paraplanning that scales with your practice. Padua’s ROMA Online paraplanning software keeps you in control of the process. Work with our expert Paraplanners to ensure you deliver the highest quality outcomes for your clients. Think of them as an extension of your team.</span></p>', NULL, NULL, 1, 1, 4, 0, 0, NULL, 'Inherit', 'Inherit', 1),
(24, 11, 1, 0, 1, 0, 'SilverStripe\\Lessons\\ServicesPage', '2018-01-12 06:49:25', '2018-01-12 06:49:25', 'new-services-page', 'New Services Page', NULL, NULL, NULL, NULL, 1, 1, 5, 0, 0, NULL, 'Inherit', 'Inherit', 1),
(25, 11, 2, 1, 1, 1, 'SilverStripe\\Lessons\\ServicesPage', '2018-01-12 06:50:47', '2018-01-12 06:49:25', 'optimise-your-time-and-engage-more-with-your-clients', 'Optimise your time', NULL, '<div class="el-group" data-id="b9965e97d5e59a0256fc3bf539014e6d">\n<div id="TextElementb5b25c224c8475c14e1ac9086b9f6eb0" class="ng-element el-text-2 empty-line-hack font-G-a9qp4vvmdw-n4" data-id="ea6b6f35cf31c782c73db3891822aa5d">\n<p>Optimise your&nbsp;time and engage more with your&nbsp;clients.</p>\n</div>\n</div>', NULL, NULL, 1, 1, 5, 0, 0, NULL, 'Inherit', 'Inherit', 1),
(26, 12, 1, 0, 1, 0, 'SilverStripe\\Lessons\\ServicesPage', '2018-01-12 06:51:38', '2018-01-12 06:51:38', 'new-services-page', 'New Services Page', NULL, NULL, NULL, NULL, 1, 1, 6, 0, 0, NULL, 'Inherit', 'Inherit', 1),
(27, 12, 2, 1, 1, 1, 'SilverStripe\\Lessons\\ServicesPage', '2018-01-12 06:51:58', '2018-01-12 06:51:38', 'improve-your-margins', 'Improve your margins', NULL, '<div class="el-group" data-id="3be56dcb3992f09380b6a847b6367da3">\n<div id="TextElementa79a4bb6f72e43aebbea004bcecae07f" class="ng-element el-text-2 empty-line-hack font-G-a9qp4vvmdw-n4" data-id="524ba8206aa8ab23044387f9b0b593af">\n<p>Improve your margins,<br>reduce overall costs and<br>increase efficiency.</p>\n</div>\n</div>', NULL, NULL, 1, 1, 6, 0, 0, NULL, 'Inherit', 'Inherit', 1),
(28, 13, 1, 0, 1, 0, 'SilverStripe\\Lessons\\ServicesPage', '2018-01-12 06:52:08', '2018-01-12 06:52:08', 'new-services-page', 'New Services Page', NULL, NULL, NULL, NULL, 1, 1, 7, 0, 0, NULL, 'Inherit', 'Inherit', 1),
(29, 13, 2, 1, 1, 1, 'SilverStripe\\Lessons\\ServicesPage', '2018-01-12 06:52:23', '2018-01-12 06:52:08', 'scale-your-business', 'Scale your business', NULL, '<p><span>Scale your business</span><br><span>faster with on-demand</span><br><span>services.</span></p>', NULL, NULL, 1, 1, 7, 0, 0, NULL, 'Inherit', 'Inherit', 1),
(30, 14, 1, 0, 1, 0, 'SilverStripe\\Lessons\\ServicesPage', '2018-01-12 06:52:36', '2018-01-12 06:52:36', 'new-services-page', 'New Services Page', NULL, NULL, NULL, NULL, 1, 1, 8, 0, 0, NULL, 'Inherit', 'Inherit', 1),
(31, 14, 2, 1, 1, 1, 'SilverStripe\\Lessons\\ServicesPage', '2018-01-12 06:52:48', '2018-01-12 06:52:36', 'local-expert-qualified', 'Local, expert, qualified', NULL, '<p><span>Local, expert, qualified</span><br><span>paraplanners who are an</span><br><span>extension of your team.</span></p>', NULL, NULL, 1, 1, 8, 0, 0, NULL, 'Inherit', 'Inherit', 1),
(32, 11, 3, 1, 1, 1, 'PaduaHome\\Component\\Services', '2018-01-12 07:15:05', '2018-01-12 06:49:25', 'optimise-your-time-and-engage-more-with-your-clients', 'Optimise your time', NULL, '<div class="el-group" data-id="b9965e97d5e59a0256fc3bf539014e6d">\n<div id="TextElementb5b25c224c8475c14e1ac9086b9f6eb0" class="ng-element el-text-2 empty-line-hack font-G-a9qp4vvmdw-n4" data-id="ea6b6f35cf31c782c73db3891822aa5d">\n<p>Optimise your&nbsp;time and engage more with your&nbsp;clients.</p>\n</div>\n</div>', NULL, NULL, 1, 1, 5, 0, 0, NULL, 'Inherit', 'Inherit', 1),
(33, 12, 3, 1, 1, 1, 'PaduaHome\\Component\\Services', '2018-01-12 07:15:27', '2018-01-12 06:51:38', 'improve-your-margins', 'Improve your margins', NULL, '<div class="el-group" data-id="3be56dcb3992f09380b6a847b6367da3">\n<div id="TextElementa79a4bb6f72e43aebbea004bcecae07f" class="ng-element el-text-2 empty-line-hack font-G-a9qp4vvmdw-n4" data-id="524ba8206aa8ab23044387f9b0b593af">\n<p>Improve your margins,<br>reduce overall costs and<br>increase efficiency.</p>\n</div>\n</div>', NULL, NULL, 1, 1, 6, 0, 0, NULL, 'Inherit', 'Inherit', 1),
(34, 13, 3, 1, 1, 1, 'PaduaHome\\Component\\Services', '2018-01-12 07:15:35', '2018-01-12 06:52:08', 'scale-your-business', 'Scale your business', NULL, '<p><span>Scale your business</span><br><span>faster with on-demand</span><br><span>services.</span></p>', NULL, NULL, 1, 1, 7, 0, 0, NULL, 'Inherit', 'Inherit', 1),
(35, 14, 3, 1, 1, 1, 'PaduaHome\\Component\\Services', '2018-01-12 07:15:43', '2018-01-12 06:52:36', 'local-expert-qualified', 'Local, expert, qualified', NULL, '<p><span>Local, expert, qualified</span><br><span>paraplanners who are an</span><br><span>extension of your team.</span></p>', NULL, NULL, 1, 1, 8, 0, 0, NULL, 'Inherit', 'Inherit', 1),
(36, 11, 4, 1, 1, 1, 'PaduaHome\\Component\\Services', '2018-01-12 07:15:52', '2018-01-12 06:49:25', 'optimise-your-time-and-engage-more-with-your-clients', 'Optimise your time', NULL, '<div class="el-group" data-id="b9965e97d5e59a0256fc3bf539014e6d">\n<div id="TextElementb5b25c224c8475c14e1ac9086b9f6eb0" class="ng-element el-text-2 empty-line-hack font-G-a9qp4vvmdw-n4" data-id="ea6b6f35cf31c782c73db3891822aa5d">\n<p>Optimise your&nbsp;time and engage more with your&nbsp;clients.</p>\n</div>\n</div>', NULL, NULL, 1, 1, 5, 0, 0, NULL, 'Inherit', 'Inherit', 1),
(37, 12, 4, 1, 1, 1, 'PaduaHome\\Component\\Services', '2018-01-12 07:16:00', '2018-01-12 06:51:38', 'improve-your-margins', 'Improve your margins', NULL, '<div class="el-group" data-id="3be56dcb3992f09380b6a847b6367da3">\n<div id="TextElementa79a4bb6f72e43aebbea004bcecae07f" class="ng-element el-text-2 empty-line-hack font-G-a9qp4vvmdw-n4" data-id="524ba8206aa8ab23044387f9b0b593af">\n<p>Improve your margins,<br>reduce overall costs and<br>increase efficiency.</p>\n</div>\n</div>', NULL, NULL, 1, 1, 6, 0, 0, NULL, 'Inherit', 'Inherit', 1),
(38, 13, 4, 1, 1, 1, 'PaduaHome\\Component\\Services', '2018-01-12 07:16:07', '2018-01-12 06:52:08', 'scale-your-business', 'Scale your business', NULL, '<p><span>Scale your business</span><br><span>faster with on-demand</span><br><span>services.</span></p>', NULL, NULL, 1, 1, 7, 0, 0, NULL, 'Inherit', 'Inherit', 1),
(39, 14, 4, 1, 1, 1, 'PaduaHome\\Component\\Services', '2018-01-12 07:16:14', '2018-01-12 06:52:36', 'local-expert-qualified', 'Local, expert, qualified', NULL, '<p><span>Local, expert, qualified</span><br><span>paraplanners who are an</span><br><span>extension of your team.</span></p>', NULL, NULL, 1, 1, 8, 0, 0, NULL, 'Inherit', 'Inherit', 1),
(40, 10, 3, 1, 1, 1, 'PaduaHome\\Component\\Testimonials', '2018-01-12 07:20:26', '2018-01-12 06:39:20', 'store-the-file-in-a-blob-field', 'Store the file in a BLOB field', NULL, '<p>Blobs are a special type database field that store arbitrary binary data, which makes them a great candidate for persisting files. Since it allows you to basically upload directly into the record, this approach has none of the syncing issues that you have with a filesystem, which makes it fairly reliable. The downside is that you can very quickly bloat your database, and it presents a poor separation of concerns. Your database can quickly become re-purposed into a de facto file server if you\'re not judicious about how much you\'re using it.</p>', NULL, NULL, 1, 1, 1, 0, 0, NULL, 'Inherit', 'Inherit', 1),
(41, 7, 7, 1, 1, 1, 'PaduaHome\\Component\\Testimonials', '2018-01-12 07:20:41', '2018-01-12 06:11:00', 'first-view', 'First View', NULL, '<p><span>It’s amazing the difference in the quality and efficiency of our paraplanning since we brought on Padua. They are a seamless extension of our business - at a fraction of the cost of doing it all ourselves.</span></p>', NULL, NULL, 1, 1, 2, 0, 0, NULL, 'Inherit', 'Inherit', 1),
(42, 8, 5, 1, 1, 1, 'PaduaHome\\Component\\Testimonials', '2018-01-12 07:20:51', '2018-01-12 06:16:04', 'second-view', 'Second View', NULL, '<div class="col bg-light-sky padding-30">\n<p>Intelligent, secure paraplanning that scales with your practice. Padua’s ROMA Online paraplanning software keeps you in control of the process. Work with our expert Paraplanners to ensure you deliver the highest quality outcomes for your clients. Think of them as an extension of your team.</p>\n<a class="btn bg-blue ss-broken" href="http://localhost/paduafinancialgroup.com.au/"></a></div>', NULL, NULL, 1, 1, 3, 0, 1, NULL, 'Inherit', 'Inherit', 1),
(43, 9, 5, 1, 1, 1, 'PaduaHome\\Component\\Testimonials', '2018-01-12 07:20:58', '2018-01-12 06:16:58', 'third-view', 'Third View', NULL, '<p><span>Intelligent, secure paraplanning that scales with your practice. Padua’s ROMA Online paraplanning software keeps you in control of the process. Work with our expert Paraplanners to ensure you deliver the highest quality outcomes for your clients. Think of them as an extension of your team.</span></p>', NULL, NULL, 1, 1, 4, 0, 0, NULL, 'Inherit', 'Inherit', 1),
(44, 10, 4, 1, 1, 1, 'PaduaHome\\Component\\Testimonials', '2018-01-12 07:21:05', '2018-01-12 06:39:20', 'store-the-file-in-a-blob-field', 'Store the file in a BLOB field', NULL, '<p>Blobs are a special type database field that store arbitrary binary data, which makes them a great candidate for persisting files. Since it allows you to basically upload directly into the record, this approach has none of the syncing issues that you have with a filesystem, which makes it fairly reliable. The downside is that you can very quickly bloat your database, and it presents a poor separation of concerns. Your database can quickly become re-purposed into a de facto file server if you\'re not judicious about how much you\'re using it.</p>', NULL, NULL, 1, 1, 1, 0, 0, NULL, 'Inherit', 'Inherit', 1),
(45, 7, 8, 1, 1, 1, 'PaduaHome\\Component\\Testimonials', '2018-01-12 07:21:15', '2018-01-12 06:11:00', 'first-view', 'First View', NULL, '<p><span>It’s amazing the difference in the quality and efficiency of our paraplanning since we brought on Padua. They are a seamless extension of our business - at a fraction of the cost of doing it all ourselves.</span></p>', NULL, NULL, 1, 1, 2, 0, 0, NULL, 'Inherit', 'Inherit', 1),
(46, 8, 6, 1, 1, 1, 'PaduaHome\\Component\\Testimonials', '2018-01-12 07:21:24', '2018-01-12 06:16:04', 'second-view', 'Second View', NULL, '<div class="col bg-light-sky padding-30">\n<p>Intelligent, secure paraplanning that scales with your practice. Padua’s ROMA Online paraplanning software keeps you in control of the process. Work with our expert Paraplanners to ensure you deliver the highest quality outcomes for your clients. Think of them as an extension of your team.</p>\n<a class="btn bg-blue ss-broken" href="http://localhost/paduafinancialgroup.com.au/"></a></div>', NULL, NULL, 1, 1, 3, 0, 1, NULL, 'Inherit', 'Inherit', 1),
(47, 9, 6, 1, 1, 1, 'PaduaHome\\Component\\Testimonials', '2018-01-12 07:21:33', '2018-01-12 06:16:58', 'third-view', 'Third View', NULL, '<p><span>Intelligent, secure paraplanning that scales with your practice. Padua’s ROMA Online paraplanning software keeps you in control of the process. Work with our expert Paraplanners to ensure you deliver the highest quality outcomes for your clients. Think of them as an extension of your team.</span></p>', NULL, NULL, 1, 1, 4, 0, 0, NULL, 'Inherit', 'Inherit', 1),
(48, 15, 1, 0, 1, 0, 'PaduaHome\\Component\\Banners', '2018-01-12 07:23:16', '2018-01-12 07:23:16', 'new-banners', 'New Banners', NULL, NULL, NULL, NULL, 1, 1, 9, 0, 0, NULL, 'Inherit', 'Inherit', 1),
(49, 15, 2, 1, 1, 1, 'PaduaHome\\Component\\Banners', '2018-01-12 07:23:51', '2018-01-12 07:23:16', 'banner-1', 'Banner 1', NULL, NULL, NULL, NULL, 1, 1, 9, 0, 0, NULL, 'Inherit', 'Inherit', 1),
(50, 16, 1, 0, 1, 0, 'PaduaHome\\Component\\Banners', '2018-01-12 07:24:05', '2018-01-12 07:24:05', 'new-banners', 'New Banners', NULL, NULL, NULL, NULL, 1, 1, 10, 0, 0, NULL, 'Inherit', 'Inherit', 1),
(51, 16, 2, 1, 1, 1, 'PaduaHome\\Component\\Banners', '2018-01-12 07:24:21', '2018-01-12 07:24:05', 'banner-2', 'Banner 2', NULL, NULL, NULL, NULL, 1, 1, 10, 0, 0, NULL, 'Inherit', 'Inherit', 1),
(52, 17, 1, 0, 1, 0, 'Page', '2018-01-12 07:40:21', '2018-01-12 07:40:21', 'new-page', 'New Page', NULL, NULL, NULL, NULL, 1, 1, 1, 0, 0, NULL, 'Inherit', 'Inherit', 9),
(53, 18, 1, 0, 1, 0, 'Page', '2018-01-12 07:40:57', '2018-01-12 07:40:57', 'new-page', 'New Page', NULL, NULL, NULL, NULL, 1, 1, 6, 0, 0, NULL, 'Inherit', 'Inherit', 0),
(54, 18, 2, 1, 1, 1, 'Page', '2018-01-12 07:41:27', '2018-01-12 07:40:57', 'paraplanning', 'PARAPLANNING', NULL, NULL, NULL, NULL, 1, 1, 6, 0, 0, NULL, 'Inherit', 'Inherit', 0),
(55, 18, 3, 1, 1, 1, 'Page', '2018-01-12 07:41:39', '2018-01-12 07:40:57', 'paraplanning', 'PARAPLANNING', NULL, NULL, NULL, NULL, 1, 1, 2, 0, 0, NULL, 'Inherit', 'Inherit', 0),
(56, 19, 1, 0, 1, 0, 'Axllent\\Weblog\\Model\\Blog', '2018-01-16 09:49:17', '2018-01-16 09:49:17', 'new-blog', 'New Blog', NULL, NULL, NULL, NULL, 1, 1, 7, 0, 0, NULL, 'Inherit', 'Inherit', 0),
(57, 19, 2, 1, 1, 1, 'Axllent\\Weblog\\Model\\Blog', '2018-01-16 09:49:51', '2018-01-16 09:49:17', 'our-blog', 'Our blog', NULL, NULL, NULL, NULL, 1, 1, 7, 0, 0, NULL, 'Inherit', 'Inherit', 0),
(58, 20, 1, 0, 1, 0, 'Axllent\\Weblog\\Model\\BlogPost', '2018-01-16 09:50:53', '2018-01-16 09:50:53', 'new-blog-post', 'New Blog Post', NULL, NULL, NULL, NULL, 0, 1, 1, 0, 0, NULL, 'Inherit', 'Inherit', 19),
(59, 20, 2, 1, 1, 1, 'Axllent\\Weblog\\Model\\BlogPost', '2018-01-16 09:51:23', '2018-01-16 09:50:53', 'suspendisse-consectetur-fringilla-luctus', 'Suspendisse consectetur fringilla luctus', NULL, '<p><span>Suspendisse consectetur fringilla luctus</span></p>', NULL, NULL, 0, 1, 1, 0, 0, NULL, 'Inherit', 'Inherit', 19),
(60, 21, 1, 0, 1, 0, 'Axllent\\Weblog\\Model\\BlogPost', '2018-01-16 10:31:58', '2018-01-16 10:31:58', 'new-blog-post', 'New Blog Post', NULL, NULL, NULL, NULL, 0, 1, 2, 0, 0, NULL, 'Inherit', 'Inherit', 19),
(61, 21, 2, 0, 1, 0, 'Axllent\\Weblog\\Model\\BlogPost', '2018-01-16 10:32:36', '2018-01-16 10:31:58', 'suspendisse-consectetur-fringilla-luctus-2', 'Suspendisse consectetur fringilla luctus', NULL, '<p>Suspendisse consectetur fringilla luctus</p><p>&nbsp;</p>', NULL, NULL, 0, 1, 2, 0, 0, NULL, 'Inherit', 'Inherit', 19),
(62, 21, 3, 1, 1, 1, 'Axllent\\Weblog\\Model\\BlogPost', '2018-01-16 10:32:36', '2018-01-16 10:31:58', 'suspendisse-consectetur-fringilla-luctus-2', 'Suspendisse consectetur fringilla luctus', NULL, '<p>Suspendisse consectetur fringilla luctus</p><p>&nbsp;</p>', NULL, NULL, 0, 1, 2, 0, 0, NULL, 'Inherit', 'Inherit', 19),
(63, 21, 4, 1, 1, 1, 'Axllent\\Weblog\\Model\\BlogPost', '2018-01-16 10:33:11', '2018-01-16 10:31:58', 'suspendisse-consectetur-fringilla-luctus-2', 'Suspendisse consectetur fringilla luctus', NULL, '<p>Suspendisse consectetur fringilla luctus</p><p>&nbsp;</p>', NULL, NULL, 0, 1, 2, 0, 0, NULL, 'Inherit', 'Inherit', 19),
(64, 22, 1, 0, 1, 0, 'Axllent\\Weblog\\Model\\BlogPost', '2018-01-16 10:33:26', '2018-01-16 10:33:26', 'new-blog-post', 'New Blog Post', NULL, NULL, NULL, NULL, 0, 1, 3, 0, 0, NULL, 'Inherit', 'Inherit', 19),
(65, 21, 5, 1, 1, 1, 'Axllent\\Weblog\\Model\\BlogPost', '2018-01-16 10:33:38', '2018-01-16 10:31:58', 'suspendisse-consectetur-fringilla-luctus-2', 'Suspendisse consectetur fringilla luctus 1', NULL, '<p>Suspendisse consectetur fringilla luctus</p><p>&nbsp;</p>', NULL, NULL, 0, 1, 2, 0, 0, NULL, 'Inherit', 'Inherit', 19),
(66, 20, 3, 1, 1, 1, 'Axllent\\Weblog\\Model\\BlogPost', '2018-01-16 10:33:46', '2018-01-16 09:50:53', 'suspendisse-consectetur-fringilla-luctus', 'Suspendisse consectetur fringilla luctus 2', NULL, '<p><span>Suspendisse consectetur fringilla luctus</span></p>', NULL, NULL, 0, 1, 1, 0, 0, NULL, 'Inherit', 'Inherit', 19),
(67, 22, 2, 0, 1, 0, 'Axllent\\Weblog\\Model\\BlogPost', '2018-01-16 10:34:15', '2018-01-16 10:33:26', 'v', 'Suspendisse consectetur fringilla luctus 3', NULL, '<p><span>Suspendisse consectetur fringilla luctus</span></p>', NULL, NULL, 0, 1, 3, 0, 0, NULL, 'Inherit', 'Inherit', 19),
(68, 22, 3, 1, 1, 1, 'Axllent\\Weblog\\Model\\BlogPost', '2018-01-16 10:34:16', '2018-01-16 10:33:26', 'v', 'Suspendisse consectetur fringilla luctus 3', NULL, '<p><span>Suspendisse consectetur fringilla luctus</span></p>', NULL, NULL, 0, 1, 3, 0, 0, NULL, 'Inherit', 'Inherit', 19),
(69, 1, 2, 1, 1, 1, '', '2018-01-16 13:52:08', '2018-01-12 05:56:10', 'home', 'Home', NULL, '<p>Welcome to SilverStripe! This is the default homepage. You can edit this page by opening <a href="admin/">the CMS</a>.</p><p>You can now access the <a href="http://docs.silverstripe.org">developer documentation</a>, or begin the <a href="http://www.silverstripe.org/learn/lessons">SilverStripe lessons</a>.</p>', NULL, NULL, 1, 1, 1, 0, 0, NULL, 'Inherit', 'Inherit', 0),
(70, 1, 3, 1, 1, 1, '', '2018-01-16 13:52:17', '2018-01-12 05:56:10', 'home', 'Home', NULL, '<p>Welcome to SilverStripe! This is the default homepage. You can edit this page by opening <a href="admin/">the CMS</a>.</p><p>You can now access the <a href="http://docs.silverstripe.org">developer documentation</a>, or begin the <a href="http://www.silverstripe.org/learn/lessons">SilverStripe lessons</a>.</p>', NULL, NULL, 1, 1, 1, 0, 0, NULL, 'Inherit', 'Inherit', 0),
(71, 1, 4, 1, 1, 1, '', '2018-01-16 13:52:36', '2018-01-12 05:56:10', 'home', 'Home', NULL, '<p>Welcome to SilverStripe! This is the default homepage. You can edit this page by opening <a href="admin/">the CMS</a>.</p><p>You can now access the <a href="http://docs.silverstripe.org">developer documentation</a>, or begin the <a href="http://www.silverstripe.org/learn/lessons">SilverStripe lessons</a>.</p>', NULL, NULL, 1, 1, 1, 0, 0, NULL, 'Inherit', 'Inherit', 0),
(72, 1, 5, 1, 1, 1, 'Page', '2018-01-16 13:52:46', '2018-01-12 05:56:10', 'home', 'Home', NULL, '<p>Welcome to SilverStripe! This is the default homepage. You can edit this page by opening <a href="admin/">the CMS</a>.</p><p>You can now access the <a href="http://docs.silverstripe.org">developer documentation</a>, or begin the <a href="http://www.silverstripe.org/learn/lessons">SilverStripe lessons</a>.</p>', NULL, NULL, 1, 1, 1, 0, 0, NULL, 'Inherit', 'Inherit', 0),
(73, 23, 1, 0, 1, 0, '', '2018-01-16 13:53:00', '2018-01-16 13:53:00', 'new-home', 'New Home', NULL, NULL, NULL, NULL, 1, 1, 8, 0, 0, NULL, 'Inherit', 'Inherit', 0),
(74, 23, 2, 1, 1, 1, '', '2018-01-16 13:53:11', '2018-01-16 13:53:00', 'new-home', 'Home', NULL, NULL, NULL, NULL, 1, 1, 8, 0, 0, NULL, 'Inherit', 'Inherit', 0),
(75, 23, 3, 1, 1, 1, '', '2018-01-16 13:53:18', '2018-01-16 13:53:00', 'home-2', 'Home', NULL, NULL, NULL, NULL, 1, 1, 8, 0, 0, NULL, 'Inherit', 'Inherit', 0),
(76, 23, 4, 1, 1, 1, '', '2018-01-16 13:54:39', '2018-01-16 13:53:00', 'home-2', 'Home', NULL, NULL, NULL, NULL, 1, 1, 8, 0, 0, NULL, 'Inherit', 'Inherit', 0),
(77, 23, 5, 1, 1, 1, '', '2018-01-16 13:54:54', '2018-01-16 13:53:00', 'home-2', 'Home', NULL, NULL, NULL, NULL, 1, 1, 8, 0, 0, NULL, 'Anyone', 'Inherit', 0),
(78, 24, 1, 0, 1, 0, 'PaduaHome\\Component\\HomePageBoxes', '2018-01-16 14:15:18', '2018-01-16 14:15:18', 'new-home-page-boxes', 'New Home Page Boxes', NULL, NULL, NULL, NULL, 1, 1, 11, 0, 0, NULL, 'Inherit', 'Inherit', 1),
(79, 24, 2, 1, 1, 1, 'PaduaHome\\Component\\HomePageBoxes', '2018-01-16 14:15:52', '2018-01-16 14:15:18', 'outsourced-paraplanning', 'OUTSOURCED PARAPLANNING', NULL, '<div id="TextElement88e2d720862bb7baff0c307df73e0cab" class="ng-element el-text-2 empty-line-hack line-height-fix font-G-a9qp4vvmdw-n3" data-id="7c5b962c7d374f96589c8f6e11885dc5">\n<p>Intelligent, secure paraplanning that scales with your practice. Padua’s ROMA Online paraplanning software keeps you in control of the process. Work with our expert Paraplanners to ensure you deliver the highest quality outcomes for your clients. Think of them as an extension of your team.</p>\n</div><div id="TextElementbb02cca9a0678343893364dcbd698df5" class="ng-element el-text-2 empty-line-hack font-G-a9qp4vvmdw-n7" data-id="27e1bdab9c67a5f89d566ffcc4d91a27"></div>', NULL, NULL, 1, 1, 11, 0, 0, NULL, 'Inherit', 'Inherit', 1),
(80, 25, 1, 0, 1, 0, 'PaduaHome\\Component\\HomePageBoxes', '2018-01-16 14:16:04', '2018-01-16 14:16:04', 'new-home-page-boxes', 'New Home Page Boxes', NULL, NULL, NULL, NULL, 1, 1, 12, 0, 0, NULL, 'Inherit', 'Inherit', 1),
(81, 25, 2, 1, 1, 1, 'PaduaHome\\Component\\HomePageBoxes', '2018-01-16 14:16:26', '2018-01-16 14:16:04', 'outsourced-transition-management', 'OUTSOURCED TRANSITION MANAGEMENT', NULL, '<div id="TextElementb1e772fc3b4e8707fa71239c5117c263" class="ng-element el-text-2 empty-line-hack line-height-fix font-G-a9qp4vvmdw-n3" data-id="ebe43880a6bafb055a73bd85d17ae2ec">\n<p>The only, end-to-end Transition Service for moving large volumes of advsier\'s clients. Padua\'s TORINO transtition software provides total control and transparency, compliance oversight and security for fast and efficient transitioning of superannuation, pensions, investments or insurance.</p>\n</div>', NULL, NULL, 1, 1, 12, 0, 0, NULL, 'Inherit', 'Inherit', 1),
(82, 24, 3, 1, 1, 1, 'PaduaHome\\Component\\HomePageBoxes', '2018-01-16 14:17:18', '2018-01-16 14:15:18', 'outsourced-paraplanning', 'OUTSOURCED PARAPLANNING', NULL, '<div id="TextElement88e2d720862bb7baff0c307df73e0cab" class="ng-element el-text-2 empty-line-hack line-height-fix font-G-a9qp4vvmdw-n3" data-id="7c5b962c7d374f96589c8f6e11885dc5">\n<p>Intelligent, secure paraplanning that scales with your practice. Padua’s ROMA Online paraplanning software keeps you in control of the process. Work with our expert Paraplanners to ensure you deliver the highest quality outcomes for your clients. Think of them as an extension of your team.</p>\n</div>', NULL, NULL, 1, 1, 11, 0, 0, NULL, 'Inherit', 'Inherit', 1),
(83, 24, 4, 1, 1, 1, 'PaduaHome\\Component\\HomePageBoxes', '2018-01-16 14:19:10', '2018-01-16 14:15:18', 'outsourced-paraplanning', 'OUTSOURCED PARAPLANNING', NULL, '<div id="TextElement88e2d720862bb7baff0c307df73e0cab" class="ng-element el-text-2 empty-line-hack line-height-fix font-G-a9qp4vvmdw-n3" data-id="7c5b962c7d374f96589c8f6e11885dc5">\n<p>Intelligent, secure paraplanning that scales with your practice. Padua’s ROMA Online paraplanning software keeps you in control of the process. Work with our expert Paraplanners to ensure you deliver the highest quality outcomes for your clients. Think of them as an extension of your team.</p>\n</div>', NULL, NULL, 1, 1, 11, 0, 0, NULL, 'Inherit', 'Inherit', 1),
(84, 25, 3, 1, 1, 1, 'PaduaHome\\Component\\HomePageBoxes', '2018-01-16 14:19:20', '2018-01-16 14:16:04', 'outsourced-transition-management', 'OUTSOURCED TRANSITION MANAGEMENT', NULL, '<div id="TextElementb1e772fc3b4e8707fa71239c5117c263" class="ng-element el-text-2 empty-line-hack line-height-fix font-G-a9qp4vvmdw-n3" data-id="ebe43880a6bafb055a73bd85d17ae2ec">\n<p>The only, end-to-end Transition Service for moving large volumes of advsier\'s clients. Padua\'s TORINO transtition software provides total control and transparency, compliance oversight and security for fast and efficient transitioning of superannuation, pensions, investments or insurance.</p>\n</div>', NULL, NULL, 1, 1, 12, 0, 0, NULL, 'Inherit', 'Inherit', 1),
(85, 25, 4, 1, 1, 1, 'PaduaHome\\Component\\HomePageBoxes', '2018-01-16 14:19:32', '2018-01-16 14:16:04', 'outsourced-transition-management', 'OUTSOURCED TRANSITION MANAGEMENT', NULL, '<div id="TextElementb1e772fc3b4e8707fa71239c5117c263" class="ng-element el-text-2 empty-line-hack line-height-fix font-G-a9qp4vvmdw-n3" data-id="ebe43880a6bafb055a73bd85d17ae2ec">\n<p>The only, end-to-end Transition Service for moving large volumes of advsier\'s clients. Padua\'s TORINO transtition software provides total control and transparency, compliance oversight and security for fast and efficient transitioning of superannuation, pensions, investments or insurance.</p>\n</div>', NULL, NULL, 1, 1, 12, 0, 0, NULL, 'Inherit', 'Inherit', 1),
(86, 26, 1, 0, 1, 0, 'PaduaHome\\Component\\HomePageBoxes', '2018-01-16 14:19:48', '2018-01-16 14:19:48', 'new-home-page-boxes', 'New Home Page Boxes', NULL, NULL, NULL, NULL, 1, 1, 13, 0, 0, NULL, 'Inherit', 'Inherit', 1),
(87, 26, 2, 1, 1, 1, 'PaduaHome\\Component\\HomePageBoxes', '2018-01-16 14:20:28', '2018-01-16 14:19:48', 'image', 'Image', NULL, NULL, NULL, NULL, 1, 1, 13, 0, 0, NULL, 'Inherit', 'Inherit', 1),
(88, 27, 1, 0, 1, 0, 'PaduaHome\\Component\\HomePageBoxes', '2018-01-16 14:20:40', '2018-01-16 14:20:40', 'new-home-page-boxes', 'New Home Page Boxes', NULL, NULL, NULL, NULL, 1, 1, 14, 0, 0, NULL, 'Inherit', 'Inherit', 1),
(89, 27, 2, 1, 1, 1, 'PaduaHome\\Component\\HomePageBoxes', '2018-01-16 14:21:06', '2018-01-16 14:20:40', 'padua-technology', 'PADUA TECHNOLOGY', NULL, '<div id="TextElement93e231dd3e2506c57d3ba8f4feba3bd4" class="ng-element el-text-2 empty-line-hack line-height-fix font-G-a9qp4vvmdw-n3" data-id="613b09cb047faa80507e0b6ee8f0c238">\n<p>Padua\'s ROMA Paraplanning and TORINO Transition Management software is designed to help you produce the highest quality advice for your clients. Outsourcing advice generation to Padua means advisers, dealer groups and licensees can focus on clients and growing the business.</p>\n</div>', NULL, NULL, 1, 1, 14, 0, 0, NULL, 'Inherit', 'Inherit', 1),
(90, 28, 1, 0, 1, 0, '', '2018-01-17 06:04:54', '2018-01-17 06:04:54', 'new-home-page', 'New Home Page', NULL, NULL, NULL, NULL, 1, 1, 8, 0, 0, NULL, 'Inherit', 'Inherit', 0),
(91, 28, 2, 1, 1, 1, '', '2018-01-17 06:05:49', '2018-01-17 06:04:54', 'new-home-page', 'Home Page', NULL, NULL, NULL, NULL, 1, 1, 8, 0, 0, NULL, 'Inherit', 'Inherit', 0),
(92, 24, 5, 1, 1, 1, 'PaduaHome\\Component\\HomePageBoxes', '2018-01-17 06:09:25', '2018-01-16 14:15:18', 'outsourced-paraplanning', 'OUTSOURCED PARAPLANNING', NULL, '<div id="TextElement88e2d720862bb7baff0c307df73e0cab" class="ng-element el-text-2 empty-line-hack line-height-fix font-G-a9qp4vvmdw-n3" data-id="7c5b962c7d374f96589c8f6e11885dc5">\n<p>Intelligent, secure paraplanning that scales with your practice. Padua’s ROMA Online paraplanning software keeps you in control of the process. Work with our expert Paraplanners to ensure you deliver the highest quality outcomes for your clients. Think of them as an extension of your team.</p>\n</div>', NULL, NULL, 1, 1, 11, 0, 0, NULL, 'Inherit', 'Inherit', 1),
(93, 25, 5, 1, 1, 1, 'PaduaHome\\Component\\HomePageBoxes', '2018-01-17 07:28:55', '2018-01-16 14:16:04', 'outsourced-transition-management', 'OUTSOURCED TRANSITION MANAGEMENT', NULL, '<div id="TextElementb1e772fc3b4e8707fa71239c5117c263" class="ng-element el-text-2 empty-line-hack line-height-fix font-G-a9qp4vvmdw-n3" data-id="ebe43880a6bafb055a73bd85d17ae2ec">\n<p>The only, end-to-end Transition Service for moving large volumes of advsier\'s clients. Padua\'s TORINO transtition software provides total control and transparency, compliance oversight and security for fast and efficient transitioning of superannuation, pensions, investments or insurance.</p>\n</div>', NULL, NULL, 1, 1, 12, 0, 0, NULL, 'Inherit', 'Inherit', 1),
(94, 27, 3, 1, 1, 1, 'PaduaHome\\Component\\HomePageBoxes', '2018-01-17 07:29:06', '2018-01-16 14:20:40', 'padua-technology', 'PADUA TECHNOLOGY', NULL, '<div id="TextElement93e231dd3e2506c57d3ba8f4feba3bd4" class="ng-element el-text-2 empty-line-hack line-height-fix font-G-a9qp4vvmdw-n3" data-id="613b09cb047faa80507e0b6ee8f0c238">\n<p>Padua\'s ROMA Paraplanning and TORINO Transition Management software is designed to help you produce the highest quality advice for your clients. Outsourcing advice generation to Padua means advisers, dealer groups and licensees can focus on clients and growing the business.</p>\n</div>', NULL, NULL, 1, 1, 14, 0, 0, NULL, 'Inherit', 'Inherit', 1),
(95, 29, 1, 0, 1, 0, 'Page', '2018-01-17 07:49:39', '2018-01-17 07:49:39', 'new-page', 'New Page', NULL, NULL, NULL, NULL, 1, 1, 8, 0, 0, NULL, 'Inherit', 'Inherit', 0),
(96, 29, 2, 1, 1, 1, 'Page', '2018-01-17 07:49:51', '2018-01-17 07:49:39', 'transition-management', ' TRANSITION MANAGEMENT', NULL, '<p>Coming soon...</p>', NULL, NULL, 1, 1, 8, 0, 0, NULL, 'Inherit', 'Inherit', 0),
(97, 29, 3, 1, 1, 1, 'Page', '2018-01-17 07:49:56', '2018-01-17 07:49:39', 'transition-management', ' TRANSITION MANAGEMENT', NULL, '<p>Coming soon...</p>', NULL, NULL, 1, 1, 3, 0, 0, NULL, 'Inherit', 'Inherit', 0),
(98, 30, 1, 0, 1, 0, 'Page', '2018-01-17 07:50:20', '2018-01-17 07:50:20', 'new-page', 'New Page', NULL, NULL, NULL, NULL, 1, 1, 1, 0, 0, NULL, 'Inherit', 'Inherit', 29),
(99, 30, 2, 1, 1, 1, 'Page', '2018-01-17 07:50:36', '2018-01-17 07:50:20', 'technology', 'TECHNOLOGY', NULL, '<p>Coming soon...</p>', NULL, NULL, 1, 1, 1, 0, 0, NULL, 'Inherit', 'Inherit', 29),
(100, 30, 3, 0, 1, 0, 'Page', '2018-01-17 07:50:43', '2018-01-17 07:50:20', 'technology', 'TECHNOLOGY', NULL, '<p>Coming soon...</p>', NULL, NULL, 1, 1, 1, 0, 0, NULL, 'Inherit', 'Inherit', 0),
(101, 30, 4, 0, 1, 0, 'Page', '2018-01-17 07:50:43', '2018-01-17 07:50:20', 'technology', 'TECHNOLOGY', NULL, '<p>Coming soon...</p>', NULL, NULL, 1, 1, 5, 0, 0, NULL, 'Inherit', 'Inherit', 0),
(102, 30, 5, 1, 1, 1, 'Page', '2018-01-17 07:50:47', '2018-01-17 07:50:20', 'technology', 'TECHNOLOGY', NULL, '<p>Coming soon...</p>', NULL, NULL, 1, 1, 4, 0, 0, NULL, 'Inherit', 'Inherit', 0),
(103, 2, 2, 1, 1, 1, 'Page', '2018-01-17 07:50:57', '2018-01-12 05:56:10', 'about-us', 'ABOUT', NULL, '<p>You can fill this page out with your own content, or delete it and create your own pages.</p>', NULL, NULL, 1, 1, 5, 0, 0, NULL, 'Inherit', 'Inherit', 0),
(104, 31, 1, 0, 1, 0, 'Page', '2018-01-17 07:51:04', '2018-01-17 07:51:04', 'new-page', 'New Page', NULL, NULL, NULL, NULL, 1, 1, 1, 0, 0, NULL, 'Inherit', 'Inherit', 2),
(105, 31, 2, 1, 1, 1, 'Page', '2018-01-17 07:51:13', '2018-01-17 07:51:04', 'careers', 'CAREERS', NULL, '<p>Coming soon...</p>', NULL, NULL, 1, 1, 1, 0, 0, NULL, 'Inherit', 'Inherit', 2),
(106, 19, 3, 1, 1, 1, 'Axllent\\Weblog\\Model\\Blog', '2018-01-17 07:51:47', '2018-01-16 09:49:17', 'our-blog', 'Our blog', NULL, NULL, NULL, NULL, 0, 1, 9, 0, 0, NULL, 'Inherit', 'Inherit', 0),
(107, 3, 2, 1, 1, 1, 'Page', '2018-01-17 07:52:00', '2018-01-12 05:56:10', 'contact-us', 'Contact Us', NULL, '<p>You can fill this page out with your own content, or delete it and create your own pages.</p>', NULL, NULL, 0, 1, 6, 0, 0, NULL, 'Inherit', 'Inherit', 0),
(108, 1, 6, 1, 1, 1, 'Page', '2018-01-17 07:52:12', '2018-01-12 05:56:10', 'home', 'Home', NULL, '<p>Welcome to SilverStripe! This is the default homepage. You can edit this page by opening <a href="admin/">the CMS</a>.</p><p>You can now access the <a href="http://docs.silverstripe.org">developer documentation</a>, or begin the <a href="http://www.silverstripe.org/learn/lessons">SilverStripe lessons</a>.</p>', NULL, NULL, 0, 1, 1, 0, 0, NULL, 'Inherit', 'Inherit', 0),
(109, 32, 1, 0, 1, 0, 'Page', '2018-01-17 07:52:40', '2018-01-17 07:52:40', 'new-page', 'New Page', NULL, NULL, NULL, NULL, 1, 1, 10, 0, 0, NULL, 'Inherit', 'Inherit', 0),
(110, 32, 2, 1, 1, 1, 'Page', '2018-01-17 07:52:52', '2018-01-17 07:52:40', 'careers', 'CAREERS', NULL, '<p>Coming Soon</p>', NULL, NULL, 1, 1, 10, 0, 0, NULL, 'Inherit', 'Inherit', 0),
(111, 31, 3, 0, 1, 0, 'Page', '2018-01-17 07:53:04', '2018-01-17 07:51:04', 'careers-2', 'CAREERS', NULL, '<p>Coming soon...</p>', NULL, NULL, 1, 1, 1, 0, 0, NULL, 'Inherit', 'Inherit', 0),
(112, 31, 4, 0, 1, 0, 'Page', '2018-01-17 07:53:05', '2018-01-17 07:51:04', 'careers-2', 'CAREERS', NULL, '<p>Coming soon...</p>', NULL, NULL, 1, 1, 7, 0, 0, NULL, 'Inherit', 'Inherit', 0),
(113, 31, 5, 0, 1, 0, 'Page', '2018-01-17 07:53:07', '2018-01-17 07:51:04', 'careers-2', 'CAREERS', NULL, '<p>Coming soon...</p>', NULL, NULL, 1, 1, 6, 0, 0, NULL, 'Inherit', 'Inherit', 0),
(114, 31, 6, 1, 1, 1, 'Page', '2018-01-17 07:53:09', '2018-01-17 07:51:04', 'careers-2', 'CAREERS', NULL, '<p>Coming soon...</p>', NULL, NULL, 1, 1, 6, 0, 0, NULL, 'Inherit', 'Inherit', 0),
(115, 32, 3, 1, 1, 1, 'Page', '2018-01-17 07:53:23', '2018-01-17 07:52:40', 'careers', 'CAREERS NOT USED', NULL, '<p>Coming Soon</p>', NULL, NULL, 1, 1, 11, 0, 0, NULL, 'Inherit', 'Inherit', 0),
(116, 32, 4, 1, 1, 1, 'Page', '2018-01-17 07:53:29', '2018-01-17 07:52:40', 'careers', 'CAREERS NOT USED', NULL, '<p>Coming Soon</p>', NULL, NULL, 0, 1, 11, 0, 0, NULL, 'Inherit', 'Inherit', 0),
(117, 1, 7, 1, 1, 1, 'Page', '2018-01-17 08:00:53', '2018-01-12 05:56:10', 'home', 'Home', NULL, '<p>Welcome to SilverStripe! This is the default homepage. You can edit this page by opening <a href="admin/">the CMS</a>.</p><p>You can now access the <a href="http://docs.silverstripe.org">developer documentation</a>, or begin the <a href="http://www.silverstripe.org/learn/lessons">SilverStripe lessons</a>.</p>', NULL, NULL, 0, 1, 1, 0, 0, NULL, 'Inherit', 'Inherit', 0),
(118, 2, 3, 1, 1, 1, 'Page', '2018-01-17 08:05:21', '2018-01-12 05:56:10', 'about-us', 'ABOUT', NULL, '<p>You can fill this page out with your own content, or delete it and create your own pages.</p>', NULL, NULL, 1, 1, 5, 0, 0, NULL, 'Inherit', 'Inherit', 0),
(119, 3, 3, 1, 1, 1, 'Page', '2018-01-17 08:05:41', '2018-01-12 05:56:10', 'contact-us', 'Contact Us', NULL, '<p>You can fill this page out with your own content, or delete it and create your own pages.</p>', NULL, NULL, 0, 1, 7, 0, 0, NULL, 'Inherit', 'Inherit', 0),
(120, 19, 4, 1, 1, 1, 'Axllent\\Weblog\\Model\\Blog', '2018-01-17 08:06:09', '2018-01-16 09:49:17', 'our-blog', 'Blog', NULL, NULL, NULL, NULL, 0, 1, 10, 0, 0, NULL, 'Inherit', 'Inherit', 0),
(121, 32, 5, 1, 1, 1, 'Page', '2018-01-17 08:06:28', '2018-01-17 07:52:40', 'careers', 'Our Privacy Policy', NULL, '<p>Coming Soon</p>', NULL, NULL, 0, 1, 11, 0, 0, NULL, 'Inherit', 'Inherit', 0),
(122, 3, 4, 1, 1, 1, 'Page', '2018-01-17 08:07:08', '2018-01-12 05:56:10', 'contact-us', 'Contact', NULL, '<p>You can fill this page out with your own content, or delete it and create your own pages.</p>', NULL, NULL, 0, 1, 7, 0, 0, NULL, 'Inherit', 'Inherit', 0);

-- --------------------------------------------------------

--
-- Table structure for table `SiteTree_ViewerGroups`
--

CREATE TABLE `SiteTree_ViewerGroups` (
  `ID` int(11) NOT NULL,
  `SiteTreeID` int(11) NOT NULL DEFAULT '0',
  `GroupID` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `testimonialholder`
--

CREATE TABLE `testimonialholder` (
  `ID` int(11) NOT NULL,
  `Title` varchar(255) CHARACTER SET utf8 DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `testimonialholder_Live`
--

CREATE TABLE `testimonialholder_Live` (
  `ID` int(11) NOT NULL,
  `Title` varchar(255) CHARACTER SET utf8 DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `testimonialholder_Versions`
--

CREATE TABLE `testimonialholder_Versions` (
  `ID` int(11) NOT NULL,
  `RecordID` int(11) NOT NULL DEFAULT '0',
  `Version` int(11) NOT NULL DEFAULT '0',
  `Title` varchar(255) CHARACTER SET utf8 DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `testimonialholder_Versions`
--

INSERT INTO `testimonialholder_Versions` (`ID`, `RecordID`, `Version`, `Title`) VALUES
(1, 6, 1, 'New Testimonial Holder'),
(2, 6, 2, 'Testimonials');

-- --------------------------------------------------------

--
-- Table structure for table `testimonialpage`
--

CREATE TABLE `testimonialpage` (
  `ID` int(11) NOT NULL,
  `PhotoID` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `testimonialpage`
--

INSERT INTO `testimonialpage` (`ID`, `PhotoID`) VALUES
(7, 2),
(8, 3),
(9, 4),
(10, 5);

-- --------------------------------------------------------

--
-- Table structure for table `testimonialpage_Live`
--

CREATE TABLE `testimonialpage_Live` (
  `ID` int(11) NOT NULL,
  `PhotoID` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `testimonialpage_Live`
--

INSERT INTO `testimonialpage_Live` (`ID`, `PhotoID`) VALUES
(7, 2),
(8, 3),
(9, 4),
(10, 5);

-- --------------------------------------------------------

--
-- Table structure for table `testimonialpage_Versions`
--

CREATE TABLE `testimonialpage_Versions` (
  `ID` int(11) NOT NULL,
  `RecordID` int(11) NOT NULL DEFAULT '0',
  `Version` int(11) NOT NULL DEFAULT '0',
  `PhotoID` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `testimonialpage_Versions`
--

INSERT INTO `testimonialpage_Versions` (`ID`, `RecordID`, `Version`, `PhotoID`) VALUES
(1, 7, 1, 0),
(2, 7, 2, 0),
(3, 7, 3, 2),
(4, 7, 4, 2),
(5, 8, 1, 0),
(6, 8, 2, 3),
(7, 9, 1, 0),
(8, 9, 2, 4),
(9, 10, 1, 0),
(10, 10, 2, 5),
(11, 7, 5, 2),
(12, 7, 6, 2),
(13, 8, 3, 3),
(14, 8, 4, 3),
(15, 9, 3, 4),
(16, 9, 4, 4);

-- --------------------------------------------------------

--
-- Table structure for table `testimonials`
--

CREATE TABLE `testimonials` (
  `ID` int(11) NOT NULL,
  `PhotoID` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `testimonials`
--

INSERT INTO `testimonials` (`ID`, `PhotoID`) VALUES
(10, 14),
(7, 15),
(8, 16),
(9, 17);

-- --------------------------------------------------------

--
-- Table structure for table `testimonials_Live`
--

CREATE TABLE `testimonials_Live` (
  `ID` int(11) NOT NULL,
  `PhotoID` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `testimonials_Live`
--

INSERT INTO `testimonials_Live` (`ID`, `PhotoID`) VALUES
(10, 14),
(7, 15),
(8, 16),
(9, 17);

-- --------------------------------------------------------

--
-- Table structure for table `testimonials_Versions`
--

CREATE TABLE `testimonials_Versions` (
  `ID` int(11) NOT NULL,
  `RecordID` int(11) NOT NULL DEFAULT '0',
  `Version` int(11) NOT NULL DEFAULT '0',
  `PhotoID` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `testimonials_Versions`
--

INSERT INTO `testimonials_Versions` (`ID`, `RecordID`, `Version`, `PhotoID`) VALUES
(1, 10, 3, 0),
(2, 7, 7, 0),
(3, 8, 5, 0),
(4, 9, 5, 0),
(5, 10, 4, 14),
(6, 7, 8, 15),
(7, 8, 6, 16),
(8, 9, 6, 17);

-- --------------------------------------------------------

--
-- Table structure for table `VirtualPage`
--

CREATE TABLE `VirtualPage` (
  `ID` int(11) NOT NULL,
  `VersionID` int(11) NOT NULL DEFAULT '0',
  `CopyContentFromID` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `VirtualPage_Live`
--

CREATE TABLE `VirtualPage_Live` (
  `ID` int(11) NOT NULL,
  `VersionID` int(11) NOT NULL DEFAULT '0',
  `CopyContentFromID` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `VirtualPage_Versions`
--

CREATE TABLE `VirtualPage_Versions` (
  `ID` int(11) NOT NULL,
  `RecordID` int(11) NOT NULL DEFAULT '0',
  `Version` int(11) NOT NULL DEFAULT '0',
  `VersionID` int(11) NOT NULL DEFAULT '0',
  `CopyContentFromID` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `banners`
--
ALTER TABLE `banners`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `PhotoID` (`PhotoID`);

--
-- Indexes for table `banners_Live`
--
ALTER TABLE `banners_Live`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `PhotoID` (`PhotoID`);

--
-- Indexes for table `banners_Versions`
--
ALTER TABLE `banners_Versions`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `RecordID_Version` (`RecordID`,`Version`),
  ADD KEY `RecordID` (`RecordID`),
  ADD KEY `Version` (`Version`),
  ADD KEY `PhotoID` (`PhotoID`);

--
-- Indexes for table `Blog`
--
ALTER TABLE `Blog`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `BlogCategory`
--
ALTER TABLE `BlogCategory`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `ClassName` (`ClassName`),
  ADD KEY `BlogID` (`BlogID`);

--
-- Indexes for table `BlogPost`
--
ALTER TABLE `BlogPost`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `FeaturedImageID` (`FeaturedImageID`);

--
-- Indexes for table `BlogPost_Categories`
--
ALTER TABLE `BlogPost_Categories`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `BlogPostID` (`BlogPostID`),
  ADD KEY `BlogCategoryID` (`BlogCategoryID`);

--
-- Indexes for table `BlogPost_Live`
--
ALTER TABLE `BlogPost_Live`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `FeaturedImageID` (`FeaturedImageID`);

--
-- Indexes for table `BlogPost_Versions`
--
ALTER TABLE `BlogPost_Versions`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `RecordID_Version` (`RecordID`,`Version`),
  ADD KEY `RecordID` (`RecordID`),
  ADD KEY `Version` (`Version`),
  ADD KEY `FeaturedImageID` (`FeaturedImageID`);

--
-- Indexes for table `Blog_Live`
--
ALTER TABLE `Blog_Live`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `Blog_Versions`
--
ALTER TABLE `Blog_Versions`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `RecordID_Version` (`RecordID`,`Version`),
  ADD KEY `RecordID` (`RecordID`),
  ADD KEY `Version` (`Version`);

--
-- Indexes for table `ChangeSet`
--
ALTER TABLE `ChangeSet`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `ClassName` (`ClassName`),
  ADD KEY `OwnerID` (`OwnerID`),
  ADD KEY `PublisherID` (`PublisherID`);

--
-- Indexes for table `ChangeSetItem`
--
ALTER TABLE `ChangeSetItem`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `ObjectUniquePerChangeSet` (`ObjectID`,`ObjectClass`,`ChangeSetID`),
  ADD KEY `ClassName` (`ClassName`),
  ADD KEY `ChangeSetID` (`ChangeSetID`),
  ADD KEY `Object` (`ObjectID`,`ObjectClass`);

--
-- Indexes for table `ChangeSetItem_ReferencedBy`
--
ALTER TABLE `ChangeSetItem_ReferencedBy`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `ChangeSetItemID` (`ChangeSetItemID`),
  ADD KEY `ChildID` (`ChildID`);

--
-- Indexes for table `ErrorPage`
--
ALTER TABLE `ErrorPage`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `ErrorPage_Live`
--
ALTER TABLE `ErrorPage_Live`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `ErrorPage_Versions`
--
ALTER TABLE `ErrorPage_Versions`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `RecordID_Version` (`RecordID`,`Version`),
  ADD KEY `RecordID` (`RecordID`),
  ADD KEY `Version` (`Version`);

--
-- Indexes for table `File`
--
ALTER TABLE `File`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `ClassName` (`ClassName`),
  ADD KEY `ParentID` (`ParentID`),
  ADD KEY `OwnerID` (`OwnerID`);

--
-- Indexes for table `File_EditorGroups`
--
ALTER TABLE `File_EditorGroups`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `FileID` (`FileID`),
  ADD KEY `GroupID` (`GroupID`);

--
-- Indexes for table `File_Live`
--
ALTER TABLE `File_Live`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `ClassName` (`ClassName`),
  ADD KEY `ParentID` (`ParentID`),
  ADD KEY `OwnerID` (`OwnerID`);

--
-- Indexes for table `File_Versions`
--
ALTER TABLE `File_Versions`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `RecordID_Version` (`RecordID`,`Version`),
  ADD KEY `RecordID` (`RecordID`),
  ADD KEY `Version` (`Version`),
  ADD KEY `AuthorID` (`AuthorID`),
  ADD KEY `PublisherID` (`PublisherID`),
  ADD KEY `ClassName` (`ClassName`),
  ADD KEY `ParentID` (`ParentID`),
  ADD KEY `OwnerID` (`OwnerID`);

--
-- Indexes for table `File_ViewerGroups`
--
ALTER TABLE `File_ViewerGroups`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `FileID` (`FileID`),
  ADD KEY `GroupID` (`GroupID`);

--
-- Indexes for table `Group`
--
ALTER TABLE `Group`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `ClassName` (`ClassName`),
  ADD KEY `ParentID` (`ParentID`);

--
-- Indexes for table `Group_Members`
--
ALTER TABLE `Group_Members`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `GroupID` (`GroupID`),
  ADD KEY `MemberID` (`MemberID`);

--
-- Indexes for table `Group_Roles`
--
ALTER TABLE `Group_Roles`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `GroupID` (`GroupID`),
  ADD KEY `PermissionRoleID` (`PermissionRoleID`);

--
-- Indexes for table `homepageboxes`
--
ALTER TABLE `homepageboxes`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `PhotoID` (`PhotoID`),
  ADD KEY `read_moreID` (`read_moreID`),
  ADD KEY `css_classID` (`css_classID`);

--
-- Indexes for table `homepageboxes_Live`
--
ALTER TABLE `homepageboxes_Live`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `PhotoID` (`PhotoID`),
  ADD KEY `read_moreID` (`read_moreID`),
  ADD KEY `css_classID` (`css_classID`);

--
-- Indexes for table `homepageboxes_Versions`
--
ALTER TABLE `homepageboxes_Versions`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `RecordID_Version` (`RecordID`,`Version`),
  ADD KEY `RecordID` (`RecordID`),
  ADD KEY `Version` (`Version`),
  ADD KEY `PhotoID` (`PhotoID`),
  ADD KEY `read_moreID` (`read_moreID`),
  ADD KEY `css_classID` (`css_classID`);

--
-- Indexes for table `LoginAttempt`
--
ALTER TABLE `LoginAttempt`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `ClassName` (`ClassName`),
  ADD KEY `MemberID` (`MemberID`);

--
-- Indexes for table `Member`
--
ALTER TABLE `Member`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `ClassName` (`ClassName`),
  ADD KEY `Email` (`Email`);

--
-- Indexes for table `MemberPassword`
--
ALTER TABLE `MemberPassword`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `ClassName` (`ClassName`),
  ADD KEY `MemberID` (`MemberID`);

--
-- Indexes for table `Page`
--
ALTER TABLE `Page`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `Page_Live`
--
ALTER TABLE `Page_Live`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `Page_Versions`
--
ALTER TABLE `Page_Versions`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `RecordID_Version` (`RecordID`,`Version`),
  ADD KEY `RecordID` (`RecordID`),
  ADD KEY `Version` (`Version`);

--
-- Indexes for table `Permission`
--
ALTER TABLE `Permission`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `ClassName` (`ClassName`),
  ADD KEY `GroupID` (`GroupID`),
  ADD KEY `Code` (`Code`);

--
-- Indexes for table `PermissionRole`
--
ALTER TABLE `PermissionRole`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `ClassName` (`ClassName`);

--
-- Indexes for table `PermissionRoleCode`
--
ALTER TABLE `PermissionRoleCode`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `ClassName` (`ClassName`),
  ADD KEY `RoleID` (`RoleID`);

--
-- Indexes for table `RedirectorPage`
--
ALTER TABLE `RedirectorPage`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `LinkToID` (`LinkToID`);

--
-- Indexes for table `RedirectorPage_Live`
--
ALTER TABLE `RedirectorPage_Live`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `LinkToID` (`LinkToID`);

--
-- Indexes for table `RedirectorPage_Versions`
--
ALTER TABLE `RedirectorPage_Versions`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `RecordID_Version` (`RecordID`,`Version`),
  ADD KEY `RecordID` (`RecordID`),
  ADD KEY `Version` (`Version`),
  ADD KEY `LinkToID` (`LinkToID`);

--
-- Indexes for table `RememberLoginHash`
--
ALTER TABLE `RememberLoginHash`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `ClassName` (`ClassName`),
  ADD KEY `MemberID` (`MemberID`),
  ADD KEY `DeviceID` (`DeviceID`),
  ADD KEY `Hash` (`Hash`);

--
-- Indexes for table `services`
--
ALTER TABLE `services`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `PhotoID` (`PhotoID`);

--
-- Indexes for table `services_Live`
--
ALTER TABLE `services_Live`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `PhotoID` (`PhotoID`);

--
-- Indexes for table `services_Versions`
--
ALTER TABLE `services_Versions`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `RecordID_Version` (`RecordID`,`Version`),
  ADD KEY `RecordID` (`RecordID`),
  ADD KEY `Version` (`Version`),
  ADD KEY `PhotoID` (`PhotoID`);

--
-- Indexes for table `SiteConfig`
--
ALTER TABLE `SiteConfig`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `ClassName` (`ClassName`);

--
-- Indexes for table `SiteConfig_CreateTopLevelGroups`
--
ALTER TABLE `SiteConfig_CreateTopLevelGroups`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `SiteConfigID` (`SiteConfigID`),
  ADD KEY `GroupID` (`GroupID`);

--
-- Indexes for table `SiteConfig_EditorGroups`
--
ALTER TABLE `SiteConfig_EditorGroups`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `SiteConfigID` (`SiteConfigID`),
  ADD KEY `GroupID` (`GroupID`);

--
-- Indexes for table `SiteConfig_ViewerGroups`
--
ALTER TABLE `SiteConfig_ViewerGroups`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `SiteConfigID` (`SiteConfigID`),
  ADD KEY `GroupID` (`GroupID`);

--
-- Indexes for table `SiteTree`
--
ALTER TABLE `SiteTree`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `ClassName` (`ClassName`),
  ADD KEY `ParentID` (`ParentID`),
  ADD KEY `URLSegment` (`URLSegment`);

--
-- Indexes for table `SiteTree_EditorGroups`
--
ALTER TABLE `SiteTree_EditorGroups`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `SiteTreeID` (`SiteTreeID`),
  ADD KEY `GroupID` (`GroupID`);

--
-- Indexes for table `SiteTree_ImageTracking`
--
ALTER TABLE `SiteTree_ImageTracking`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `SiteTreeID` (`SiteTreeID`),
  ADD KEY `FileID` (`FileID`);

--
-- Indexes for table `SiteTree_LinkTracking`
--
ALTER TABLE `SiteTree_LinkTracking`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `SiteTreeID` (`SiteTreeID`),
  ADD KEY `ChildID` (`ChildID`);

--
-- Indexes for table `SiteTree_Live`
--
ALTER TABLE `SiteTree_Live`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `ClassName` (`ClassName`),
  ADD KEY `ParentID` (`ParentID`),
  ADD KEY `URLSegment` (`URLSegment`);

--
-- Indexes for table `SiteTree_Versions`
--
ALTER TABLE `SiteTree_Versions`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `RecordID_Version` (`RecordID`,`Version`),
  ADD KEY `RecordID` (`RecordID`),
  ADD KEY `Version` (`Version`),
  ADD KEY `AuthorID` (`AuthorID`),
  ADD KEY `PublisherID` (`PublisherID`),
  ADD KEY `ClassName` (`ClassName`),
  ADD KEY `ParentID` (`ParentID`),
  ADD KEY `URLSegment` (`URLSegment`);

--
-- Indexes for table `SiteTree_ViewerGroups`
--
ALTER TABLE `SiteTree_ViewerGroups`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `SiteTreeID` (`SiteTreeID`),
  ADD KEY `GroupID` (`GroupID`);

--
-- Indexes for table `testimonialholder`
--
ALTER TABLE `testimonialholder`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `testimonialholder_Live`
--
ALTER TABLE `testimonialholder_Live`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `testimonialholder_Versions`
--
ALTER TABLE `testimonialholder_Versions`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `RecordID_Version` (`RecordID`,`Version`),
  ADD KEY `RecordID` (`RecordID`),
  ADD KEY `Version` (`Version`);

--
-- Indexes for table `testimonialpage`
--
ALTER TABLE `testimonialpage`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `PhotoID` (`PhotoID`);

--
-- Indexes for table `testimonialpage_Live`
--
ALTER TABLE `testimonialpage_Live`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `PhotoID` (`PhotoID`);

--
-- Indexes for table `testimonialpage_Versions`
--
ALTER TABLE `testimonialpage_Versions`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `RecordID_Version` (`RecordID`,`Version`),
  ADD KEY `RecordID` (`RecordID`),
  ADD KEY `Version` (`Version`),
  ADD KEY `PhotoID` (`PhotoID`);

--
-- Indexes for table `testimonials`
--
ALTER TABLE `testimonials`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `PhotoID` (`PhotoID`);

--
-- Indexes for table `testimonials_Live`
--
ALTER TABLE `testimonials_Live`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `PhotoID` (`PhotoID`);

--
-- Indexes for table `testimonials_Versions`
--
ALTER TABLE `testimonials_Versions`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `RecordID_Version` (`RecordID`,`Version`),
  ADD KEY `RecordID` (`RecordID`),
  ADD KEY `Version` (`Version`),
  ADD KEY `PhotoID` (`PhotoID`);

--
-- Indexes for table `VirtualPage`
--
ALTER TABLE `VirtualPage`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `CopyContentFromID` (`CopyContentFromID`);

--
-- Indexes for table `VirtualPage_Live`
--
ALTER TABLE `VirtualPage_Live`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `CopyContentFromID` (`CopyContentFromID`);

--
-- Indexes for table `VirtualPage_Versions`
--
ALTER TABLE `VirtualPage_Versions`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `RecordID_Version` (`RecordID`,`Version`),
  ADD KEY `RecordID` (`RecordID`),
  ADD KEY `Version` (`Version`),
  ADD KEY `CopyContentFromID` (`CopyContentFromID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `banners`
--
ALTER TABLE `banners`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT for table `banners_Live`
--
ALTER TABLE `banners_Live`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT for table `banners_Versions`
--
ALTER TABLE `banners_Versions`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `Blog`
--
ALTER TABLE `Blog`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
--
-- AUTO_INCREMENT for table `BlogCategory`
--
ALTER TABLE `BlogCategory`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `BlogPost`
--
ALTER TABLE `BlogPost`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
--
-- AUTO_INCREMENT for table `BlogPost_Categories`
--
ALTER TABLE `BlogPost_Categories`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `BlogPost_Live`
--
ALTER TABLE `BlogPost_Live`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
--
-- AUTO_INCREMENT for table `BlogPost_Versions`
--
ALTER TABLE `BlogPost_Versions`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `Blog_Live`
--
ALTER TABLE `Blog_Live`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
--
-- AUTO_INCREMENT for table `Blog_Versions`
--
ALTER TABLE `Blog_Versions`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `ChangeSet`
--
ALTER TABLE `ChangeSet`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=86;
--
-- AUTO_INCREMENT for table `ChangeSetItem`
--
ALTER TABLE `ChangeSetItem`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=113;
--
-- AUTO_INCREMENT for table `ChangeSetItem_ReferencedBy`
--
ALTER TABLE `ChangeSetItem_ReferencedBy`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;
--
-- AUTO_INCREMENT for table `ErrorPage`
--
ALTER TABLE `ErrorPage`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `ErrorPage_Live`
--
ALTER TABLE `ErrorPage_Live`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `ErrorPage_Versions`
--
ALTER TABLE `ErrorPage_Versions`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `File`
--
ALTER TABLE `File`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
--
-- AUTO_INCREMENT for table `File_EditorGroups`
--
ALTER TABLE `File_EditorGroups`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `File_Live`
--
ALTER TABLE `File_Live`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
--
-- AUTO_INCREMENT for table `File_Versions`
--
ALTER TABLE `File_Versions`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
--
-- AUTO_INCREMENT for table `File_ViewerGroups`
--
ALTER TABLE `File_ViewerGroups`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `Group`
--
ALTER TABLE `Group`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `Group_Members`
--
ALTER TABLE `Group_Members`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `Group_Roles`
--
ALTER TABLE `Group_Roles`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `homepageboxes`
--
ALTER TABLE `homepageboxes`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;
--
-- AUTO_INCREMENT for table `homepageboxes_Live`
--
ALTER TABLE `homepageboxes_Live`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;
--
-- AUTO_INCREMENT for table `homepageboxes_Versions`
--
ALTER TABLE `homepageboxes_Versions`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT for table `LoginAttempt`
--
ALTER TABLE `LoginAttempt`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `Member`
--
ALTER TABLE `Member`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `MemberPassword`
--
ALTER TABLE `MemberPassword`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `Page`
--
ALTER TABLE `Page`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;
--
-- AUTO_INCREMENT for table `Page_Live`
--
ALTER TABLE `Page_Live`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;
--
-- AUTO_INCREMENT for table `Page_Versions`
--
ALTER TABLE `Page_Versions`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `Permission`
--
ALTER TABLE `Permission`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `PermissionRole`
--
ALTER TABLE `PermissionRole`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `PermissionRoleCode`
--
ALTER TABLE `PermissionRoleCode`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `RedirectorPage`
--
ALTER TABLE `RedirectorPage`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `RedirectorPage_Live`
--
ALTER TABLE `RedirectorPage_Live`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `RedirectorPage_Versions`
--
ALTER TABLE `RedirectorPage_Versions`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `RememberLoginHash`
--
ALTER TABLE `RememberLoginHash`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `services`
--
ALTER TABLE `services`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `services_Live`
--
ALTER TABLE `services_Live`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `services_Versions`
--
ALTER TABLE `services_Versions`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT for table `SiteConfig`
--
ALTER TABLE `SiteConfig`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `SiteConfig_CreateTopLevelGroups`
--
ALTER TABLE `SiteConfig_CreateTopLevelGroups`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `SiteConfig_EditorGroups`
--
ALTER TABLE `SiteConfig_EditorGroups`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `SiteConfig_ViewerGroups`
--
ALTER TABLE `SiteConfig_ViewerGroups`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `SiteTree`
--
ALTER TABLE `SiteTree`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;
--
-- AUTO_INCREMENT for table `SiteTree_EditorGroups`
--
ALTER TABLE `SiteTree_EditorGroups`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `SiteTree_ImageTracking`
--
ALTER TABLE `SiteTree_ImageTracking`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `SiteTree_LinkTracking`
--
ALTER TABLE `SiteTree_LinkTracking`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `SiteTree_Live`
--
ALTER TABLE `SiteTree_Live`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;
--
-- AUTO_INCREMENT for table `SiteTree_Versions`
--
ALTER TABLE `SiteTree_Versions`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=123;
--
-- AUTO_INCREMENT for table `SiteTree_ViewerGroups`
--
ALTER TABLE `SiteTree_ViewerGroups`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `testimonialholder`
--
ALTER TABLE `testimonialholder`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `testimonialholder_Live`
--
ALTER TABLE `testimonialholder_Live`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `testimonialholder_Versions`
--
ALTER TABLE `testimonialholder_Versions`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `testimonialpage`
--
ALTER TABLE `testimonialpage`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `testimonialpage_Live`
--
ALTER TABLE `testimonialpage_Live`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `testimonialpage_Versions`
--
ALTER TABLE `testimonialpage_Versions`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT for table `testimonials`
--
ALTER TABLE `testimonials`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `testimonials_Live`
--
ALTER TABLE `testimonials_Live`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `testimonials_Versions`
--
ALTER TABLE `testimonials_Versions`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `VirtualPage`
--
ALTER TABLE `VirtualPage`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `VirtualPage_Live`
--
ALTER TABLE `VirtualPage_Live`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `VirtualPage_Versions`
--
ALTER TABLE `VirtualPage_Versions`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
